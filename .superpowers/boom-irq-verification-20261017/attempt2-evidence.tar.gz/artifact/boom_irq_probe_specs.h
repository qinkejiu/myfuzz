inline std::vector<BoomProbe> boom_probe_specs() {return {
{"meip","TOP.BoomTile.core.csr_io_interrupts_meip",1},
{"rob_exception","TOP.BoomTile.core.rob_io_com_xcpt_valid",1},
{"rob_cause","TOP.BoomTile.core.rob_io_com_xcpt_bits_cause",64},
{"csr_exception","TOP.BoomTile.core.csr_io_exception",1},
{"csr_cause","TOP.BoomTile.core.csr_io_cause",64},
{"csr_pc","TOP.BoomTile.core.csr_io_pc",40},
{"csr_evec","TOP.BoomTile.core.csr_io_evec",40},
{"mie","TOP.BoomTile.core.csr.reg_mie",64},
{"global_mie","TOP.BoomTile.core.csr.reg_mstatus_mie",1},
{"privilege","TOP.BoomTile.core.csr.reg_mstatus_prv",2},
{"mtvec","TOP.BoomTile.core.csr.reg_mtvec",32},
{"mcause","TOP.BoomTile.core.csr.reg_mcause",64},
{"mepc","TOP.BoomTile.core.csr.reg_mepc",40},
{"system_return","TOP.BoomTile.core.csr.insn_ret",1},
{"csr_addr","TOP.BoomTile.core.csr.io_rw_addr",12},
{"csr_cmd","TOP.BoomTile.core.csr.io_rw_cmd",3}
};}
