#!/bin/bash
set -uo pipefail
cd /root/fanzehui/boom-verification-20261017/project
source /root/fanzehui/system-20261016/environment.sh
export PYTHONPATH=/root/fanzehui/system-20261016/pythonlib:$PWD/src:$PWD
python3 -u - <<'PY'
import hashlib,json
from pathlib import Path
base=Path('/root/fanzehui/boom-verification-20261017')
document=json.loads((base/'current-source-files.json').read_text())
errors=[name for name,expected in document['files'].items() if hashlib.sha256((base/'project'/name).read_bytes()).hexdigest()!=expected]
report={'checked_files':len(document['files']),'mismatches':errors,'pass':not errors}
(base/'state/source-hash-check.json').write_text(json.dumps(report,indent=2)+'\n')
assert not errors, errors
from myfuzz.local_harness.boom_cpu_session import build_boom_session
(base/'state/stage').write_text('waiting-or-building-native\n')
artifact = build_boom_session(Path.cwd(), base/'native', heavy_lock=Path('/root/fanzehui/system-20261016/project/.superpowers/heavy-worker.lock'))
(base/'state/stage').write_text('native-build-complete\n')
print(json.dumps({'build':'pass','artifact':artifact['schema_version']}),flush=True)
PY
build_status=$?
printf '%s\n' "$build_status" > /root/fanzehui/boom-verification-20261017/state/build.exit
if test "$build_status" -ne 0; then exit "$build_status"; fi
printf '%s\n' waiting-or-running-standard-gate > /root/fanzehui/boom-verification-20261017/state/stage
flock /root/fanzehui/system-20261016/project/.superpowers/heavy-worker.lock python3 -u -m myfuzz.scenario.boom_gpio_verification --repo "$PWD" --cpu-output /root/fanzehui/boom-verification-20261017/native --cache-dir /root/fanzehui/boom-verification-20261017/cache --output /root/fanzehui/boom-verification-20261017/gate --edges 1200
gate_status=$?
printf '%s\n' "$gate_status" > /root/fanzehui/boom-verification-20261017/state/gate.exit
printf '%s\n' native-gate-finished > /root/fanzehui/boom-verification-20261017/state/stage
if test "$gate_status" -ne 0; then exit "$gate_status"; fi
# Preserve the existing one-shot behavior using its pinned pre-existing binary.
# The current generator must reproduce its driver/manager/source identities.
flock /root/fanzehui/system-20261016/project/.superpowers/heavy-worker.lock python3 -u - <<'PY'
import json,shutil
from pathlib import Path
from myfuzz.local_harness.tilelink_coherent_cpu_session import generate,run_gates,digest
base=Path('/root/fanzehui/boom-verification-20261017')
old=Path('/root/fanzehui/system-20261016/project/.superpowers/boom-generated/run')
prior=json.loads((old/'gate.json').read_text())
artifact=generate(Path.cwd(),base/'one-shot')
for key in ('source_revision','driver_sha256','manager_sha256'):
    assert artifact[key]==prior['artifact'][key],key
assert digest(old/'obj/VBoomTile')==prior['executable_sha256']
(base/'one-shot/obj').mkdir()
shutil.copy2(old/'obj/VBoomTile',base/'one-shot/obj/VBoomTile')
report=run_gates(base/'one-shot',artifact)
(base/'one-shot/binary-provenance.json').write_text(json.dumps({'method':'authenticated prior one-shot binary, current generator reproduced driver/manager/source identities','prior_gate_sha256':digest(old/'gate.json'),'binary_sha256':digest(base/'one-shot/obj/VBoomTile')},indent=2)+'\n')
print(json.dumps({'one_shot_fresh_matching':report['two_fresh_matching'],'one_shot_fault_control':report['fault_read_control']}),flush=True)
PY
baseline_status=$?
printf '%s\n' "$baseline_status" > /root/fanzehui/boom-verification-20261017/state/one-shot.exit
printf '%s\n' all-native-gates-finished > /root/fanzehui/boom-verification-20261017/state/stage
exit "$baseline_status"
