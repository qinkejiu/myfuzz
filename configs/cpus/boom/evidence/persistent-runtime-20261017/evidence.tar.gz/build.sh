#!/bin/bash
set -uo pipefail
cd /root/fanzehui/boom-verification-20261017/project
source /root/fanzehui/system-20261016/environment.sh
export PYTHONPATH=/root/fanzehui/system-20261016/pythonlib:$PWD/src:$PWD
python3 -u - <<'PY'
import json
from pathlib import Path
from myfuzz.local_harness.boom_cpu_session import build_boom_session
base = Path('/root/fanzehui/boom-verification-20261017')
(base/'state/stage').write_text('waiting-or-building-native\n')
artifact = build_boom_session(Path.cwd(), base/'native', heavy_lock=Path('/root/fanzehui/system-20261016/project/.superpowers/heavy-worker.lock'))
(base/'state/stage').write_text('native-build-complete\n')
print(json.dumps({'build':'pass','artifact':artifact['schema_version']}))
PY
status=$?
printf '%s\n' "$status" > /root/fanzehui/boom-verification-20261017/state/build.exit
exit "$status"
