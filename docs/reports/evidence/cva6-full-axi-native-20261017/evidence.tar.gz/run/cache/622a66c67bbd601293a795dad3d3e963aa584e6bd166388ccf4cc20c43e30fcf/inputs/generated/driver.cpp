#include "Vlocal_runtime_cva6.h"
#include "verilated.h"
#include "local_driver_v1.h"



#include <iostream>
#include <map>
#include <string>
#include <vector>

#ifndef MYFUZZ_ARTIFACT_DIGEST
#error MYFUZZ_ARTIFACT_DIGEST must identify the final generated artifact
#endif
#define MYFUZZ_STRINGIFY_IMPL(value) #value
#define MYFUZZ_STRINGIFY(value) MYFUZZ_STRINGIFY_IMPL(value)

using Model = Vlocal_runtime_cva6;
using namespace myfuzz::local_driver_v1;
using JsonObject = std::map<std::string, std::string>;
static std::uint64_t local_ticks = 0;




static std::string quote(const std::string &value) {
  return "\"" + value + "\"";
}
static std::string object(const JsonObject &values) {
  std::string answer = "{";
  for (const auto &entry : values) {
    if (answer.size() > 1) answer += ',';
    answer += quote(entry.first) + ':' + entry.second;
  }
  return answer + '}';
}
static std::string array(const std::vector<std::string> &values) {
  std::string answer = "[";
  for (const auto &value : values) {
    if (answer.size() > 1) answer += ',';
    answer += value;
  }
  return answer + ']';
}
template <typename Wide>
static std::string wide_hex(const Wide &value, unsigned width) {
  const char *digits = "0123456789abcdef";
  std::string answer((width + 3) / 4, '0');
  for (unsigned nibble = 0; nibble < answer.size(); ++nibble) {
    const unsigned bit = 4 * nibble;
    const unsigned remaining = width - bit;
    const unsigned mask = remaining < 4 ? (1u << remaining) - 1 : 15;
    answer[answer.size() - nibble - 1] = digits[(value[bit / 32] >> (bit % 32)) & mask];
  }
  return answer;
}
static std::string backend_snapshot(const Model &dut) {
  return object({
    {"axi_awid", std::to_string(static_cast<std::uint64_t>(dut.axi_awid))},
    {"axi_awaddr", std::to_string(static_cast<std::uint64_t>(dut.axi_awaddr))},
    {"axi_awlen", std::to_string(static_cast<std::uint64_t>(dut.axi_awlen))},
    {"axi_awsize", std::to_string(static_cast<std::uint64_t>(dut.axi_awsize))},
    {"axi_awburst", std::to_string(static_cast<std::uint64_t>(dut.axi_awburst))},
    {"axi_awlock", std::to_string(static_cast<std::uint64_t>(dut.axi_awlock))},
    {"axi_awcache", std::to_string(static_cast<std::uint64_t>(dut.axi_awcache))},
    {"axi_awprot", std::to_string(static_cast<std::uint64_t>(dut.axi_awprot))},
    {"axi_awqos", std::to_string(static_cast<std::uint64_t>(dut.axi_awqos))},
    {"axi_awregion", std::to_string(static_cast<std::uint64_t>(dut.axi_awregion))},
    {"axi_awatop", std::to_string(static_cast<std::uint64_t>(dut.axi_awatop))},
    {"axi_awuser", std::to_string(static_cast<std::uint64_t>(dut.axi_awuser))},
    {"axi_awvalid", std::to_string(static_cast<std::uint64_t>(dut.axi_awvalid))},
    {"axi_wdata", std::to_string(static_cast<std::uint64_t>(dut.axi_wdata))},
    {"axi_wstrb", std::to_string(static_cast<std::uint64_t>(dut.axi_wstrb))},
    {"axi_wlast", std::to_string(static_cast<std::uint64_t>(dut.axi_wlast))},
    {"axi_wuser", std::to_string(static_cast<std::uint64_t>(dut.axi_wuser))},
    {"axi_wvalid", std::to_string(static_cast<std::uint64_t>(dut.axi_wvalid))},
    {"axi_bready", std::to_string(static_cast<std::uint64_t>(dut.axi_bready))},
    {"axi_arid", std::to_string(static_cast<std::uint64_t>(dut.axi_arid))},
    {"axi_araddr", std::to_string(static_cast<std::uint64_t>(dut.axi_araddr))},
    {"axi_arlen", std::to_string(static_cast<std::uint64_t>(dut.axi_arlen))},
    {"axi_arsize", std::to_string(static_cast<std::uint64_t>(dut.axi_arsize))},
    {"axi_arburst", std::to_string(static_cast<std::uint64_t>(dut.axi_arburst))},
    {"axi_arlock", std::to_string(static_cast<std::uint64_t>(dut.axi_arlock))},
    {"axi_arcache", std::to_string(static_cast<std::uint64_t>(dut.axi_arcache))},
    {"axi_arprot", std::to_string(static_cast<std::uint64_t>(dut.axi_arprot))},
    {"axi_arqos", std::to_string(static_cast<std::uint64_t>(dut.axi_arqos))},
    {"axi_arregion", std::to_string(static_cast<std::uint64_t>(dut.axi_arregion))},
    {"axi_aruser", std::to_string(static_cast<std::uint64_t>(dut.axi_aruser))},
    {"axi_arvalid", std::to_string(static_cast<std::uint64_t>(dut.axi_arvalid))},
    {"axi_rready", std::to_string(static_cast<std::uint64_t>(dut.axi_rready))},
    {"axi_awready", std::to_string(static_cast<std::uint64_t>(dut.axi_awready))},
    {"axi_arready", std::to_string(static_cast<std::uint64_t>(dut.axi_arready))},
    {"axi_wready", std::to_string(static_cast<std::uint64_t>(dut.axi_wready))},
    {"axi_bvalid", std::to_string(static_cast<std::uint64_t>(dut.axi_bvalid))},
    {"axi_bid", std::to_string(static_cast<std::uint64_t>(dut.axi_bid))},
    {"axi_bresp", std::to_string(static_cast<std::uint64_t>(dut.axi_bresp))},
    {"axi_buser", std::to_string(static_cast<std::uint64_t>(dut.axi_buser))},
    {"axi_rvalid", std::to_string(static_cast<std::uint64_t>(dut.axi_rvalid))},
    {"axi_rid", std::to_string(static_cast<std::uint64_t>(dut.axi_rid))},
    {"axi_rdata", std::to_string(static_cast<std::uint64_t>(dut.axi_rdata))},
    {"axi_rresp", std::to_string(static_cast<std::uint64_t>(dut.axi_rresp))},
    {"axi_rlast", std::to_string(static_cast<std::uint64_t>(dut.axi_rlast))},
    {"axi_ruser", std::to_string(static_cast<std::uint64_t>(dut.axi_ruser))}
  });
}
static std::string snapshot(const Model &dut) {
  JsonObject values = {
    {"backend", backend_snapshot(dut)},
    {"physical", object({
    {"rt_lh_p_2_448_0", quote(wide_hex(dut.rt_lh_p_2_448_0, 449))},
    {"rt_lh_p_7_0_0", std::to_string(static_cast<std::uint64_t>(dut.rt_lh_p_7_0_0))},
    {"rt_lh_p_12_0_0", std::to_string(static_cast<std::uint64_t>(dut.rt_lh_p_12_0_0))}
    })}
  };
  return object(values);
}

static void tick(Model &dut, std::vector<std::string> *samples) {

  dut.clk = 0;
  dut.eval();



  const auto pre = samples ? snapshot(dut) : "";
  dut.clk = 1;
  dut.eval();


  ++local_ticks;


  const auto post = samples ? snapshot(dut) : "";
  dut.clk = 0;
  dut.eval();
  if (samples) samples->push_back(object({{"local_tick", std::to_string(local_ticks)},
                                       {"pre", pre}, {"post", post}}));
}
static std::string encode_hex(const std::string &value) {
  if (value.size() > kMaxPayloadJsonBytes) throw std::length_error("payload_bound");
  const char *digits = "0123456789abcdef";
  std::string answer;
  answer.reserve(2 * value.size());
  for (const unsigned char byte : value) {
    answer += digits[byte >> 4];
    answer += digits[byte & 15];
  }
  return answer;
}
// A bounded reader never materializes an arbitrarily long input line. Oversize
// input is drained through newline, then rejected before replay admission.
static bool read_command(std::string &line, bool &oversize) {
  line.clear(); oversize = false;
  char byte;
  while (std::cin.get(byte)) {
    if (byte == '\n') return true;
    if (line.size() < kMaxCommandBytes) line += byte;
    else oversize = true;
  }
  return !line.empty() || oversize;
}
int main(int argc, char **argv) {
  Verilated::commandArgs(argc, argv);
  Model dut;
  dut.clk = 0;
  dut.reset = 0;
  dut.rt_lh_p_7_0_0 = 0;
  dut.rt_lh_p_12_0_0 = 0;
  dut.axi_awready = 0;
  dut.axi_arready = 0;
  dut.axi_wready = 0;
  dut.axi_bvalid = 0;
  dut.axi_bid = 0;
  dut.axi_bresp = 0;
  dut.axi_buser = 0;
  dut.axi_rvalid = 0;
  dut.axi_rid = 0;
  dut.axi_rdata = 0;
  dut.axi_rresp = 0;
  dut.axi_rlast = 0;
  dut.axi_ruser = 0;
  // Evaluate inactive reset first to create a real asynchronous assertion edge.
  dut.reset = 0;
  dut.eval();
  dut.reset = 1;
  dut.eval();
  std::uint64_t asserted_ticks = 0, released_ticks = 0;
  for (unsigned i = 0; i < 16; ++i) {
    tick(dut, nullptr);
    ++asserted_ticks;
  }
  dut.reset = 0;
  dut.eval();
  for (unsigned i = 0; i < 20; ++i) {
    tick(dut, nullptr);
    ++released_ticks;
  }


  local_ticks = 0;
  std::cout << "READY local_driver.v1 " << MYFUZZ_STRINGIFY(MYFUZZ_ARTIFACT_DIGEST)
            << " " << hex_integer(asserted_ticks) << " " << hex_integer(released_ticks) << std::endl;
  BoundedReplay replay(67108864, kMaxReplyBytes);
  std::string line;
  bool oversize;
  while (read_command(line, oversize)) {
    if (!oversize && line == "END") break;
    if (oversize) {
      std::cout << error_reply("-", 0, local_ticks, "command_too_long", "wire_bound") << std::endl;
      continue;
    }
    if (line.rfind("ACK ", 0) == 0) {
      const auto ack = parse_ack(line);
      if (!ack.ok) {
        std::cout << error_reply(ack.execution, ack.sequence, local_ticks,
                                 ack.code, ack.detail) << std::endl;
      } else {
        const auto failure = replay.retire(ack.execution, ack.sequence);
        if (failure.empty())
          std::cout << "ACKED " << ack.execution << ' ' << hex_integer(ack.sequence)
                    << ' ' << hex_integer(local_ticks) << std::endl;
        else
          std::cout << error_reply(ack.execution, ack.sequence, local_ticks,
                                   failure, "ack_rejected") << std::endl;
      }
      continue;
    }
    const auto parsed = parse_command(line);
    if (!parsed.ok) {
      std::cout << error_reply(parsed.command.execution, parsed.command.sequence,
          local_ticks, parsed.code, parsed.detail) << std::endl;
      continue;
    }
    const auto &command = parsed.command;
    if (command.operation != "STEP_CVA6_AXI4") {
      std::cout << error_reply(command.execution, command.sequence, local_ticks,
                              "invalid_operation", "wrong_runtime_kind") << std::endl;
      continue;
    }
    const auto admission = replay.accept(command, local_ticks, 10986);
    if (admission.decision != Decision::Fresh) {
      std::cout << admission.reply << std::endl;
      continue;
    }
    const auto before = local_ticks;
    std::vector<std::string> samples;
    std::string pre_backend, terminal;
    std::uint32_t rdata = 0, error = 0;
    try {
      dut.rt_lh_p_7_0_0 = command.fields[0];
      dut.rt_lh_p_12_0_0 = command.fields[1];
      dut.axi_awready = command.fields[2];
      dut.axi_wready = command.fields[3];
      dut.axi_bvalid = command.fields[4];
      dut.axi_bid = command.fields[5];
      dut.axi_bresp = command.fields[6];
      dut.axi_buser = command.fields[7];
      dut.axi_arready = command.fields[8];
      dut.axi_rvalid = command.fields[9];
      dut.axi_rid = command.fields[10];
      dut.axi_rdata = command.fields[11];
      dut.axi_rlast = command.fields[12];
      dut.axi_rresp = command.fields[13];
      dut.axi_ruser = command.fields[14];
      dut.eval();
      pre_backend = backend_snapshot(dut);
      tick(dut, &samples);

      if (terminal.empty()) {
        const auto payload = object({
          {"schema_version", quote("local_driver_result.v1")}, {"kind", quote("cva6_packed_axi4_cpu")},
          {"samples", array(samples)}, {"observations", snapshot(dut)},
          {"pre_backend", pre_backend}, {"rdata", std::to_string(rdata)},
          {"error", std::to_string(error)}
        });
        terminal = "RESULT " + command.execution + ' ' + hex_integer(command.sequence) + ' ' +
            hex_integer(before) + ' ' + hex_integer(local_ticks) + ' ' + encode_hex(payload);
      }
      replay.finish(command.sequence, terminal);
      std::cout << terminal << std::endl;
    } catch (const std::exception &) {
      const auto failure = error_reply(command.execution, command.sequence, local_ticks,
                                       "uncertain_effect", "driver_execution_failed");
      // Best effort receipt; incomplete replay still prevents another execution.
      try { replay.finish(command.sequence, failure); } catch (const std::exception &) {}
      std::cout << failure << std::endl;
      break;
    }
  }
  dut.final();
  return 0;
}
