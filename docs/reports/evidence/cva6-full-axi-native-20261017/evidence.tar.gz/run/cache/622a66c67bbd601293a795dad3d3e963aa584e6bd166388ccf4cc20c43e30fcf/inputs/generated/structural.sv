module local_cva6 (
  input logic clk,
  input logic reset,
  output logic [448:0] lh_p_2_448_0,
  input logic [0:0] lh_p_7_0_0,
  output logic [3:0] lh_p_8_469_466,
  output logic [63:0] lh_p_8_465_402,
  output logic [7:0] lh_p_8_401_394,
  output logic [2:0] lh_p_8_393_391,
  output logic [1:0] lh_p_8_390_389,
  output logic [0:0] lh_p_8_388_388,
  output logic [3:0] lh_p_8_387_384,
  output logic [2:0] lh_p_8_383_381,
  output logic [3:0] lh_p_8_380_377,
  output logic [3:0] lh_p_8_376_373,
  output logic [5:0] lh_p_8_372_367,
  output logic [63:0] lh_p_8_366_303,
  output logic [0:0] lh_p_8_302_302,
  output logic [63:0] lh_p_8_301_238,
  output logic [7:0] lh_p_8_237_230,
  output logic [0:0] lh_p_8_229_229,
  output logic [63:0] lh_p_8_228_165,
  output logic [0:0] lh_p_8_164_164,
  output logic [0:0] lh_p_8_163_163,
  output logic [3:0] lh_p_8_162_159,
  output logic [63:0] lh_p_8_158_95,
  output logic [7:0] lh_p_8_94_87,
  output logic [2:0] lh_p_8_86_84,
  output logic [1:0] lh_p_8_83_82,
  output logic [0:0] lh_p_8_81_81,
  output logic [3:0] lh_p_8_80_77,
  output logic [2:0] lh_p_8_76_74,
  output logic [3:0] lh_p_8_73_70,
  output logic [3:0] lh_p_8_69_66,
  output logic [63:0] lh_p_8_65_2,
  output logic [0:0] lh_p_8_1_1,
  output logic [0:0] lh_p_8_0_0,
  input logic [0:0] lh_p_9_209_209,
  input logic [0:0] lh_p_9_208_208,
  input logic [0:0] lh_p_9_207_207,
  input logic [0:0] lh_p_9_206_206,
  input logic [3:0] lh_p_9_205_202,
  input logic [1:0] lh_p_9_201_200,
  input logic [63:0] lh_p_9_199_136,
  input logic [0:0] lh_p_9_135_135,
  input logic [3:0] lh_p_9_134_131,
  input logic [63:0] lh_p_9_130_67,
  input logic [1:0] lh_p_9_66_65,
  input logic [0:0] lh_p_9_64_64,
  input logic [63:0] lh_p_9_63_0,
  input logic [0:0] lh_p_12_0_0
);
  logic [63:0] dut_p_0;
  assign dut_p_0[63:0] = 64'd65536;
  logic [0:0] dut_p_1;
  assign dut_p_1[0:0] = clk;
  logic [448:0] dut_p_2;
  assign lh_p_2_448_0 = dut_p_2[448:0];
  logic [177:0] dut_p_3;
  assign dut_p_3[177:0] = 178'd0;
  logic [0:0] dut_p_4;
  assign dut_p_4[0:0] = 1'd0;
  logic [63:0] dut_p_5;
  assign dut_p_5[63:0] = 64'd0;
  logic [0:0] dut_p_6;
  assign dut_p_6[0:0] = 1'd0;
  logic [1:0] dut_p_7;
  assign dut_p_7[1:1] = 1'd0;
  assign dut_p_7[0:0] = lh_p_7_0_0;
  logic [469:0] dut_p_8;
  assign lh_p_8_469_466 = dut_p_8[469:466];
  assign lh_p_8_465_402 = dut_p_8[465:402];
  assign lh_p_8_401_394 = dut_p_8[401:394];
  assign lh_p_8_393_391 = dut_p_8[393:391];
  assign lh_p_8_390_389 = dut_p_8[390:389];
  assign lh_p_8_388_388 = dut_p_8[388:388];
  assign lh_p_8_387_384 = dut_p_8[387:384];
  assign lh_p_8_383_381 = dut_p_8[383:381];
  assign lh_p_8_380_377 = dut_p_8[380:377];
  assign lh_p_8_376_373 = dut_p_8[376:373];
  assign lh_p_8_372_367 = dut_p_8[372:367];
  assign lh_p_8_366_303 = dut_p_8[366:303];
  assign lh_p_8_302_302 = dut_p_8[302:302];
  assign lh_p_8_301_238 = dut_p_8[301:238];
  assign lh_p_8_237_230 = dut_p_8[237:230];
  assign lh_p_8_229_229 = dut_p_8[229:229];
  assign lh_p_8_228_165 = dut_p_8[228:165];
  assign lh_p_8_164_164 = dut_p_8[164:164];
  assign lh_p_8_163_163 = dut_p_8[163:163];
  assign lh_p_8_162_159 = dut_p_8[162:159];
  assign lh_p_8_158_95 = dut_p_8[158:95];
  assign lh_p_8_94_87 = dut_p_8[94:87];
  assign lh_p_8_86_84 = dut_p_8[86:84];
  assign lh_p_8_83_82 = dut_p_8[83:82];
  assign lh_p_8_81_81 = dut_p_8[81:81];
  assign lh_p_8_80_77 = dut_p_8[80:77];
  assign lh_p_8_76_74 = dut_p_8[76:74];
  assign lh_p_8_73_70 = dut_p_8[73:70];
  assign lh_p_8_69_66 = dut_p_8[69:66];
  assign lh_p_8_65_2 = dut_p_8[65:2];
  assign lh_p_8_1_1 = dut_p_8[1:1];
  assign lh_p_8_0_0 = dut_p_8[0:0];
  logic [209:0] dut_p_9;
  assign dut_p_9[209:209] = lh_p_9_209_209;
  assign dut_p_9[208:208] = lh_p_9_208_208;
  assign dut_p_9[207:207] = lh_p_9_207_207;
  assign dut_p_9[206:206] = lh_p_9_206_206;
  assign dut_p_9[205:202] = lh_p_9_205_202;
  assign dut_p_9[201:200] = lh_p_9_201_200;
  assign dut_p_9[199:136] = lh_p_9_199_136;
  assign dut_p_9[135:135] = lh_p_9_135_135;
  assign dut_p_9[134:131] = lh_p_9_134_131;
  assign dut_p_9[130:67] = lh_p_9_130_67;
  assign dut_p_9[66:65] = lh_p_9_66_65;
  assign dut_p_9[64:64] = lh_p_9_64_64;
  assign dut_p_9[63:0] = lh_p_9_63_0;
  logic [0:0] dut_p_10;
  assign dut_p_10[0:0] = ~reset;
  logic [6973:0] dut_p_11;
  logic [0:0] dut_p_12;
  assign dut_p_12[0:0] = lh_p_12_0_0;
  cva6 u_dut (
    .boot_addr_i(dut_p_0),
    .clk_i(dut_p_1),
    .cvxif_req_o(dut_p_2),
    .cvxif_resp_i(dut_p_3),
    .debug_req_i(dut_p_4),
    .hart_id_i(dut_p_5),
    .ipi_i(dut_p_6),
    .irq_i(dut_p_7),
    .noc_req_o(dut_p_8),
    .noc_resp_i(dut_p_9),
    .rst_ni(dut_p_10),
    .rvfi_probes_o(dut_p_11),
    .time_irq_i(dut_p_12)
  );
endmodule
