module local_runtime_cva6 (
  input logic [0:0] clk,
  input logic [0:0] reset,
  output logic [448:0] rt_lh_p_2_448_0,
  input logic [0:0] rt_lh_p_7_0_0,
  input logic [0:0] rt_lh_p_12_0_0,
  output logic [3:0] axi_awid,
  output logic [63:0] axi_awaddr,
  output logic [7:0] axi_awlen,
  output logic [2:0] axi_awsize,
  output logic [1:0] axi_awburst,
  output logic [0:0] axi_awlock,
  output logic [3:0] axi_awcache,
  output logic [2:0] axi_awprot,
  output logic [3:0] axi_awqos,
  output logic [3:0] axi_awregion,
  output logic [5:0] axi_awatop,
  output logic [63:0] axi_awuser,
  output logic [0:0] axi_awvalid,
  output logic [63:0] axi_wdata,
  output logic [7:0] axi_wstrb,
  output logic [0:0] axi_wlast,
  output logic [63:0] axi_wuser,
  output logic [0:0] axi_wvalid,
  output logic [0:0] axi_bready,
  output logic [3:0] axi_arid,
  output logic [63:0] axi_araddr,
  output logic [7:0] axi_arlen,
  output logic [2:0] axi_arsize,
  output logic [1:0] axi_arburst,
  output logic [0:0] axi_arlock,
  output logic [3:0] axi_arcache,
  output logic [2:0] axi_arprot,
  output logic [3:0] axi_arqos,
  output logic [3:0] axi_arregion,
  output logic [63:0] axi_aruser,
  output logic [0:0] axi_arvalid,
  output logic [0:0] axi_rready,
  input logic [0:0] axi_awready,
  input logic [0:0] axi_arready,
  input logic [0:0] axi_wready,
  input logic [0:0] axi_bvalid,
  input logic [3:0] axi_bid,
  input logic [1:0] axi_bresp,
  input logic [63:0] axi_buser,
  input logic [0:0] axi_rvalid,
  input logic [3:0] axi_rid,
  input logic [63:0] axi_rdata,
  input logic [1:0] axi_rresp,
  input logic [0:0] axi_rlast,
  input logic [63:0] axi_ruser
);
  logic [3:0] link_lh_p_8_469_466;
  logic [63:0] link_lh_p_8_465_402;
  logic [7:0] link_lh_p_8_401_394;
  logic [2:0] link_lh_p_8_393_391;
  logic [1:0] link_lh_p_8_390_389;
  logic [0:0] link_lh_p_8_388_388;
  logic [3:0] link_lh_p_8_387_384;
  logic [2:0] link_lh_p_8_383_381;
  logic [3:0] link_lh_p_8_380_377;
  logic [3:0] link_lh_p_8_376_373;
  logic [5:0] link_lh_p_8_372_367;
  logic [63:0] link_lh_p_8_366_303;
  logic [0:0] link_lh_p_8_302_302;
  logic [63:0] link_lh_p_8_301_238;
  logic [7:0] link_lh_p_8_237_230;
  logic [0:0] link_lh_p_8_229_229;
  logic [63:0] link_lh_p_8_228_165;
  logic [0:0] link_lh_p_8_164_164;
  logic [0:0] link_lh_p_8_163_163;
  logic [3:0] link_lh_p_8_162_159;
  logic [63:0] link_lh_p_8_158_95;
  logic [7:0] link_lh_p_8_94_87;
  logic [2:0] link_lh_p_8_86_84;
  logic [1:0] link_lh_p_8_83_82;
  logic [0:0] link_lh_p_8_81_81;
  logic [3:0] link_lh_p_8_80_77;
  logic [2:0] link_lh_p_8_76_74;
  logic [3:0] link_lh_p_8_73_70;
  logic [3:0] link_lh_p_8_69_66;
  logic [63:0] link_lh_p_8_65_2;
  logic [0:0] link_lh_p_8_1_1;
  logic [0:0] link_lh_p_8_0_0;
  logic [0:0] link_lh_p_9_209_209;
  logic [0:0] link_lh_p_9_208_208;
  logic [0:0] link_lh_p_9_207_207;
  logic [0:0] link_lh_p_9_206_206;
  logic [3:0] link_lh_p_9_205_202;
  logic [1:0] link_lh_p_9_201_200;
  logic [63:0] link_lh_p_9_199_136;
  logic [0:0] link_lh_p_9_135_135;
  logic [3:0] link_lh_p_9_134_131;
  logic [63:0] link_lh_p_9_130_67;
  logic [1:0] link_lh_p_9_66_65;
  logic [0:0] link_lh_p_9_64_64;
  logic [63:0] link_lh_p_9_63_0;
  assign axi_awid = link_lh_p_8_469_466;
  assign axi_awaddr = link_lh_p_8_465_402;
  assign axi_awlen = link_lh_p_8_401_394;
  assign axi_awsize = link_lh_p_8_393_391;
  assign axi_awburst = link_lh_p_8_390_389;
  assign axi_awlock = link_lh_p_8_388_388;
  assign axi_awcache = link_lh_p_8_387_384;
  assign axi_awprot = link_lh_p_8_383_381;
  assign axi_awqos = link_lh_p_8_380_377;
  assign axi_awregion = link_lh_p_8_376_373;
  assign axi_awatop = link_lh_p_8_372_367;
  assign axi_awuser = link_lh_p_8_366_303;
  assign axi_awvalid = link_lh_p_8_302_302;
  assign axi_wdata = link_lh_p_8_301_238;
  assign axi_wstrb = link_lh_p_8_237_230;
  assign axi_wlast = link_lh_p_8_229_229;
  assign axi_wuser = link_lh_p_8_228_165;
  assign axi_wvalid = link_lh_p_8_164_164;
  assign axi_bready = link_lh_p_8_163_163;
  assign axi_arid = link_lh_p_8_162_159;
  assign axi_araddr = link_lh_p_8_158_95;
  assign axi_arlen = link_lh_p_8_94_87;
  assign axi_arsize = link_lh_p_8_86_84;
  assign axi_arburst = link_lh_p_8_83_82;
  assign axi_arlock = link_lh_p_8_81_81;
  assign axi_arcache = link_lh_p_8_80_77;
  assign axi_arprot = link_lh_p_8_76_74;
  assign axi_arqos = link_lh_p_8_73_70;
  assign axi_arregion = link_lh_p_8_69_66;
  assign axi_aruser = link_lh_p_8_65_2;
  assign axi_arvalid = link_lh_p_8_1_1;
  assign axi_rready = link_lh_p_8_0_0;
  assign link_lh_p_9_209_209 = axi_awready;
  assign link_lh_p_9_208_208 = axi_arready;
  assign link_lh_p_9_207_207 = axi_wready;
  assign link_lh_p_9_206_206 = axi_bvalid;
  assign link_lh_p_9_205_202 = axi_bid;
  assign link_lh_p_9_201_200 = axi_bresp;
  assign link_lh_p_9_199_136 = axi_buser;
  assign link_lh_p_9_135_135 = axi_rvalid;
  assign link_lh_p_9_134_131 = axi_rid;
  assign link_lh_p_9_130_67 = axi_rdata;
  assign link_lh_p_9_66_65 = axi_rresp;
  assign link_lh_p_9_64_64 = axi_rlast;
  assign link_lh_p_9_63_0 = axi_ruser;
  local_cva6 u_component (
    .clk(clk),
    .reset(reset),
    .lh_p_2_448_0(rt_lh_p_2_448_0),
    .lh_p_7_0_0(rt_lh_p_7_0_0),
    .lh_p_8_469_466(link_lh_p_8_469_466),
    .lh_p_8_465_402(link_lh_p_8_465_402),
    .lh_p_8_401_394(link_lh_p_8_401_394),
    .lh_p_8_393_391(link_lh_p_8_393_391),
    .lh_p_8_390_389(link_lh_p_8_390_389),
    .lh_p_8_388_388(link_lh_p_8_388_388),
    .lh_p_8_387_384(link_lh_p_8_387_384),
    .lh_p_8_383_381(link_lh_p_8_383_381),
    .lh_p_8_380_377(link_lh_p_8_380_377),
    .lh_p_8_376_373(link_lh_p_8_376_373),
    .lh_p_8_372_367(link_lh_p_8_372_367),
    .lh_p_8_366_303(link_lh_p_8_366_303),
    .lh_p_8_302_302(link_lh_p_8_302_302),
    .lh_p_8_301_238(link_lh_p_8_301_238),
    .lh_p_8_237_230(link_lh_p_8_237_230),
    .lh_p_8_229_229(link_lh_p_8_229_229),
    .lh_p_8_228_165(link_lh_p_8_228_165),
    .lh_p_8_164_164(link_lh_p_8_164_164),
    .lh_p_8_163_163(link_lh_p_8_163_163),
    .lh_p_8_162_159(link_lh_p_8_162_159),
    .lh_p_8_158_95(link_lh_p_8_158_95),
    .lh_p_8_94_87(link_lh_p_8_94_87),
    .lh_p_8_86_84(link_lh_p_8_86_84),
    .lh_p_8_83_82(link_lh_p_8_83_82),
    .lh_p_8_81_81(link_lh_p_8_81_81),
    .lh_p_8_80_77(link_lh_p_8_80_77),
    .lh_p_8_76_74(link_lh_p_8_76_74),
    .lh_p_8_73_70(link_lh_p_8_73_70),
    .lh_p_8_69_66(link_lh_p_8_69_66),
    .lh_p_8_65_2(link_lh_p_8_65_2),
    .lh_p_8_1_1(link_lh_p_8_1_1),
    .lh_p_8_0_0(link_lh_p_8_0_0),
    .lh_p_9_209_209(link_lh_p_9_209_209),
    .lh_p_9_208_208(link_lh_p_9_208_208),
    .lh_p_9_207_207(link_lh_p_9_207_207),
    .lh_p_9_206_206(link_lh_p_9_206_206),
    .lh_p_9_205_202(link_lh_p_9_205_202),
    .lh_p_9_201_200(link_lh_p_9_201_200),
    .lh_p_9_199_136(link_lh_p_9_199_136),
    .lh_p_9_135_135(link_lh_p_9_135_135),
    .lh_p_9_134_131(link_lh_p_9_134_131),
    .lh_p_9_130_67(link_lh_p_9_130_67),
    .lh_p_9_66_65(link_lh_p_9_66_65),
    .lh_p_9_64_64(link_lh_p_9_64_64),
    .lh_p_9_63_0(link_lh_p_9_63_0),
    .lh_p_12_0_0(rt_lh_p_12_0_0)
  );
  
endmodule
