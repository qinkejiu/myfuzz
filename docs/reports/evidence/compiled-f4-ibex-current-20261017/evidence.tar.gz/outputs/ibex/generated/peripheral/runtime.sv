module local_runtime_peripheral (
  input logic [0:0] clk,
  input logic [0:0] reset,
  output logic [31:0] rt_lh_p_11_31_0,
  input logic [31:0] rt_lh_p_12_31_0,
  output logic [31:0] rt_lh_p_13_31_0,
  output logic [31:0] rt_lh_p_14_31_0,
  output logic [127:0] rt_lh_p_15_127_0,
  output logic [0:0] rt_lh_p_16_0_0,
  output logic [11:0] probe_gpio_apb_addr,
  output logic [0:0] probe_gpio_psel,
  output logic [0:0] probe_gpio_penable,
  output logic [0:0] probe_gpio_pwrite,
  output logic [31:0] probe_gpio_pwdata,
  output logic [31:0] probe_gpio_prdata,
  output logic [0:0] probe_gpio_pready,
  output logic [0:0] probe_gpio_pslverr,
  output logic [4:0] probe_gpio_decoded_word,
  output logic [0:0] probe_gpio_write,
  output logic [63:0] probe_gpio_write_out,
  output logic [63:0] probe_gpio_write_inten,
  output logic [63:0] probe_gpio_write_gpioen,
  output logic [63:0] probe_gpio_write_inttype,
  output logic [31:0] probe_gpio_out,
  output logic [31:0] probe_gpio_dir,
  output logic [31:0] probe_gpio_gpioen,
  output logic [31:0] probe_gpio_inten,
  output logic [63:0] probe_gpio_inttype,
  output logic [31:0] probe_gpio_sync0,
  output logic [31:0] probe_gpio_sync1,
  output logic [31:0] probe_gpio_padin_latch,
  output logic [15:0] probe_gpio_input_clock_enable,
  output logic [31:0] probe_gpio_rise,
  output logic [31:0] probe_gpio_fall,
  output logic [31:0] probe_gpio_irq_trigger_mask,
  output logic [31:0] probe_gpio_status,
  output logic [0:0] probe_gpio_native_irq,
  output logic [11:0] trace_paddr,
  output logic [0:0] trace_psel,
  output logic [0:0] trace_penable,
  output logic [0:0] trace_pwrite,
  output logic [31:0] trace_pwdata,
  output logic [0:0] trace_pready,
  output logic [31:0] trace_prdata,
  output logic [0:0] trace_pslverr,
  input logic [0:0] gpio_req_valid,
  output logic [0:0] gpio_req_ready,
  input logic [0:0] gpio_req_write,
  input logic [31:0] gpio_req_addr,
  input logic [31:0] gpio_req_wdata,
  input logic [3:0] gpio_req_be,
  output logic [0:0] gpio_rsp_valid,
  input logic [0:0] gpio_rsp_ready,
  output logic [31:0] gpio_rsp_rdata,
  output logic [0:0] gpio_rsp_error
);
  logic [11:0] link_lh_p_2_11_0;
  logic [0:0] link_lh_p_3_0_0;
  logic [31:0] link_lh_p_4_31_0;
  logic [0:0] link_lh_p_5_0_0;
  logic [0:0] link_lh_p_6_0_0;
  logic [0:0] link_lh_p_7_0_0;
  logic [31:0] link_lh_p_8_31_0;
  logic [0:0] link_lh_p_9_0_0;
  logic [31:0] apb_paddr;
  logic [3:0] unused_pstrb;
  assign probe_gpio_apb_addr = u_component.u_dut.PADDR;
  assign probe_gpio_psel = u_component.u_dut.PSEL;
  assign probe_gpio_penable = u_component.u_dut.PENABLE;
  assign probe_gpio_pwrite = u_component.u_dut.PWRITE;
  assign probe_gpio_pwdata = u_component.u_dut.PWDATA;
  assign probe_gpio_prdata = u_component.u_dut.PRDATA;
  assign probe_gpio_pready = u_component.u_dut.PREADY;
  assign probe_gpio_pslverr = u_component.u_dut.PSLVERR;
  assign probe_gpio_decoded_word = u_component.u_dut.s_apb_addr;
  assign probe_gpio_write = u_component.u_dut.s_write;
  assign probe_gpio_write_out = u_component.u_dut.s_write_out;
  assign probe_gpio_write_inten = u_component.u_dut.s_write_inten;
  assign probe_gpio_write_gpioen = u_component.u_dut.s_write_gpen;
  assign probe_gpio_write_inttype = u_component.u_dut.s_write_inttype;
  assign probe_gpio_out = u_component.u_dut.r_gpio_out;
  assign probe_gpio_dir = u_component.u_dut.r_gpio_dir;
  assign probe_gpio_gpioen = u_component.u_dut.r_gpio_en;
  assign probe_gpio_inten = u_component.u_dut.r_gpio_inten;
  assign probe_gpio_inttype = u_component.u_dut.r_gpio_inttype;
  assign probe_gpio_sync0 = u_component.u_dut.r_gpio_sync0;
  assign probe_gpio_sync1 = u_component.u_dut.r_gpio_sync1;
  assign probe_gpio_padin_latch = u_component.u_dut.r_gpio_in;
  assign probe_gpio_input_clock_enable = u_component.u_dut.s_clk_en;
  assign probe_gpio_rise = u_component.u_dut.s_gpio_rise;
  assign probe_gpio_fall = u_component.u_dut.s_gpio_fall;
  assign probe_gpio_irq_trigger_mask = u_component.u_dut.s_is_int_all;
  assign probe_gpio_status = u_component.u_dut.r_status;
  assign probe_gpio_native_irq = u_component.u_dut.s_rise_int;
  assign trace_paddr = link_lh_p_2_11_0;
  assign trace_psel = link_lh_p_6_0_0;
  assign trace_penable = link_lh_p_3_0_0;
  assign trace_pwrite = link_lh_p_9_0_0;
  assign trace_pwdata = link_lh_p_8_31_0;
  assign trace_pready = link_lh_p_5_0_0;
  assign trace_prdata = link_lh_p_4_31_0;
  assign trace_pslverr = link_lh_p_7_0_0;
  assign link_lh_p_2_11_0 = apb_paddr[11:0];
  local_peripheral u_component (
    .clk(clk),
    .reset(reset),
    .lh_p_2_11_0(link_lh_p_2_11_0),
    .lh_p_3_0_0(link_lh_p_3_0_0),
    .lh_p_4_31_0(link_lh_p_4_31_0),
    .lh_p_5_0_0(link_lh_p_5_0_0),
    .lh_p_6_0_0(link_lh_p_6_0_0),
    .lh_p_7_0_0(link_lh_p_7_0_0),
    .lh_p_8_31_0(link_lh_p_8_31_0),
    .lh_p_9_0_0(link_lh_p_9_0_0),
    .lh_p_11_31_0(rt_lh_p_11_31_0),
    .lh_p_12_31_0(rt_lh_p_12_31_0),
    .lh_p_13_31_0(rt_lh_p_13_31_0),
    .lh_p_14_31_0(rt_lh_p_14_31_0),
    .lh_p_15_127_0(rt_lh_p_15_127_0),
    .lh_p_16_0_0(rt_lh_p_16_0_0)
  );
  beat_to_apb #(
    .ADDRESS_WIDTH(32), .DATA_WIDTH(32), .HAS_PSTRB(0),
    .SUPPORTS_PARTIAL_WRITE(0), .HAS_PSLVERR(1),
    .MAX_WAIT_CYCLES(16), .WINDOW_BASE(32'd0), .WINDOW_SIZE(4096)
  ) u_adapter_gpio (
    .clk(clk),
    .reset(reset),
    .req_valid(gpio_req_valid),
    .req_ready(gpio_req_ready),
    .write(gpio_req_write),
    .addr(gpio_req_addr),
    .wdata(gpio_req_wdata),
    .be(gpio_req_be),
    .rsp_valid(gpio_rsp_valid),
    .rsp_ready(gpio_rsp_ready),
    .rdata(gpio_rsp_rdata),
    .error(gpio_rsp_error),
    .paddr(apb_paddr),
    .pstrb(unused_pstrb),
    .penable(link_lh_p_3_0_0),
    .prdata(link_lh_p_4_31_0),
    .pready(link_lh_p_5_0_0),
    .psel(link_lh_p_6_0_0),
    .pslverr(link_lh_p_7_0_0),
    .pwdata(link_lh_p_8_31_0),
    .pwrite(link_lh_p_9_0_0)
  );
endmodule
