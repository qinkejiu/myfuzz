module local_processor (
  input logic clk,
  input logic reset,
  output logic [0:0] lh_p_2_0_0,
  output logic [127:0] lh_p_3_127_0,
  output logic [31:0] lh_p_4_31_0,
  output logic [3:0] lh_p_5_3_0,
  input logic [0:0] lh_p_6_0_0,
  input logic [0:0] lh_p_7_0_0,
  input logic [31:0] lh_p_8_31_0,
  output logic [0:0] lh_p_9_0_0,
  input logic [0:0] lh_p_10_0_0,
  output logic [31:0] lh_p_11_31_0,
  output logic [0:0] lh_p_12_0_0,
  output logic [0:0] lh_p_13_0_0,
  output logic [31:0] lh_p_19_31_0,
  input logic [0:0] lh_p_20_0_0,
  input logic [0:0] lh_p_21_0_0,
  input logic [31:0] lh_p_22_31_0,
  output logic [0:0] lh_p_23_0_0,
  input logic [0:0] lh_p_24_0_0,
  input logic [0:0] lh_p_25_0_0,
  output logic [0:0] lh_p_32_0_0,
  output logic [63:0] lh_p_33_63_0,
  output logic [31:0] lh_p_34_31_0,
  output logic [0:0] lh_p_35_0_0,
  output logic [0:0] lh_p_36_0_0,
  output logic [31:0] lh_p_37_31_0,
  output logic [0:0] lh_p_38_0_0,
  output logic [1:0] lh_p_39_1_0,
  output logic [31:0] lh_p_40_31_0,
  output logic [31:0] lh_p_41_31_0,
  output logic [3:0] lh_p_42_3_0,
  output logic [31:0] lh_p_43_31_0,
  output logic [3:0] lh_p_44_3_0,
  output logic [1:0] lh_p_45_1_0,
  output logic [63:0] lh_p_46_63_0,
  output logic [31:0] lh_p_47_31_0,
  output logic [31:0] lh_p_48_31_0,
  output logic [4:0] lh_p_49_4_0,
  output logic [31:0] lh_p_50_31_0,
  output logic [4:0] lh_p_51_4_0,
  output logic [31:0] lh_p_52_31_0,
  output logic [4:0] lh_p_53_4_0,
  output logic [31:0] lh_p_54_31_0,
  output logic [4:0] lh_p_55_4_0,
  output logic [31:0] lh_p_56_31_0,
  output logic [0:0] lh_p_57_0_0,
  output logic [0:0] lh_p_58_0_0,
  output logic [36:0] lh_p_60_36_0,
  output logic [0:0] lh_p_61_0_0,
  output logic [67:0] lh_p_63_67_0,
  output logic [0:0] lh_p_65_0_0,
  output logic [134:0] lh_p_66_134_0,
  output logic [0:0] lh_p_68_0_0
);
  logic [31:0] dut_p_0;
  assign dut_p_0[31:0] = 32'd65536;
  logic [0:0] dut_p_1;
  assign dut_p_1[0:0] = clk;
  logic [0:0] dut_p_2;
  assign lh_p_2_0_0 = dut_p_2[0:0];
  logic [127:0] dut_p_3;
  assign lh_p_3_127_0 = dut_p_3[127:0];
  logic [31:0] dut_p_4;
  assign lh_p_4_31_0 = dut_p_4[31:0];
  logic [3:0] dut_p_5;
  assign lh_p_5_3_0 = dut_p_5[3:0];
  logic [0:0] dut_p_6;
  assign dut_p_6[0:0] = lh_p_6_0_0;
  logic [0:0] dut_p_7;
  assign dut_p_7[0:0] = lh_p_7_0_0;
  logic [31:0] dut_p_8;
  assign dut_p_8[31:0] = lh_p_8_31_0;
  logic [0:0] dut_p_9;
  assign lh_p_9_0_0 = dut_p_9[0:0];
  logic [0:0] dut_p_10;
  assign dut_p_10[0:0] = lh_p_10_0_0;
  logic [31:0] dut_p_11;
  assign lh_p_11_31_0 = dut_p_11[31:0];
  logic [0:0] dut_p_12;
  assign lh_p_12_0_0 = dut_p_12[0:0];
  logic [0:0] dut_p_13;
  assign lh_p_13_0_0 = dut_p_13[0:0];
  logic [0:0] dut_p_14;
  assign dut_p_14[0:0] = 1'd0;
  logic [31:0] dut_p_15;
  assign dut_p_15[31:0] = 32'd0;
  logic [31:0] dut_p_16;
  assign dut_p_16[31:0] = 32'd0;
  logic [0:0] dut_p_17;
  assign dut_p_17[0:0] = 1'd1;
  logic [31:0] dut_p_18;
  assign dut_p_18[31:0] = 32'd0;
  logic [31:0] dut_p_19;
  assign lh_p_19_31_0 = dut_p_19[31:0];
  logic [0:0] dut_p_20;
  assign dut_p_20[0:0] = lh_p_20_0_0;
  logic [0:0] dut_p_21;
  assign dut_p_21[0:0] = lh_p_21_0_0;
  logic [31:0] dut_p_22;
  assign dut_p_22[31:0] = lh_p_22_31_0;
  logic [0:0] dut_p_23;
  assign lh_p_23_0_0 = dut_p_23[0:0];
  logic [0:0] dut_p_24;
  assign dut_p_24[0:0] = lh_p_24_0_0;
  logic [0:0] dut_p_25;
  assign dut_p_25[0:0] = lh_p_25_0_0;
  logic [15:0] dut_p_26;
  assign dut_p_26[15:0] = 16'd0;
  logic [0:0] dut_p_27;
  assign dut_p_27[0:0] = 1'd0;
  logic [0:0] dut_p_28;
  assign dut_p_28[0:0] = 1'd0;
  logic [0:0] dut_p_29;
  assign dut_p_29[0:0] = 1'd0;
  logic [9:0] dut_p_30;
  assign dut_p_30[9:0] = 10'd0;
  logic [0:0] dut_p_31;
  assign dut_p_31[0:0] = ~reset;
  logic [0:0] dut_p_32;
  assign lh_p_32_0_0 = dut_p_32[0:0];
  logic [63:0] dut_p_33;
  assign lh_p_33_63_0 = dut_p_33[63:0];
  logic [31:0] dut_p_34;
  assign lh_p_34_31_0 = dut_p_34[31:0];
  logic [0:0] dut_p_35;
  assign lh_p_35_0_0 = dut_p_35[0:0];
  logic [0:0] dut_p_36;
  assign lh_p_36_0_0 = dut_p_36[0:0];
  logic [31:0] dut_p_37;
  assign lh_p_37_31_0 = dut_p_37[31:0];
  logic [0:0] dut_p_38;
  assign lh_p_38_0_0 = dut_p_38[0:0];
  logic [1:0] dut_p_39;
  assign lh_p_39_1_0 = dut_p_39[1:0];
  logic [31:0] dut_p_40;
  assign lh_p_40_31_0 = dut_p_40[31:0];
  logic [31:0] dut_p_41;
  assign lh_p_41_31_0 = dut_p_41[31:0];
  logic [3:0] dut_p_42;
  assign lh_p_42_3_0 = dut_p_42[3:0];
  logic [31:0] dut_p_43;
  assign lh_p_43_31_0 = dut_p_43[31:0];
  logic [3:0] dut_p_44;
  assign lh_p_44_3_0 = dut_p_44[3:0];
  logic [1:0] dut_p_45;
  assign lh_p_45_1_0 = dut_p_45[1:0];
  logic [63:0] dut_p_46;
  assign lh_p_46_63_0 = dut_p_46[63:0];
  logic [31:0] dut_p_47;
  assign lh_p_47_31_0 = dut_p_47[31:0];
  logic [31:0] dut_p_48;
  assign lh_p_48_31_0 = dut_p_48[31:0];
  logic [4:0] dut_p_49;
  assign lh_p_49_4_0 = dut_p_49[4:0];
  logic [31:0] dut_p_50;
  assign lh_p_50_31_0 = dut_p_50[31:0];
  logic [4:0] dut_p_51;
  assign lh_p_51_4_0 = dut_p_51[4:0];
  logic [31:0] dut_p_52;
  assign lh_p_52_31_0 = dut_p_52[31:0];
  logic [4:0] dut_p_53;
  assign lh_p_53_4_0 = dut_p_53[4:0];
  logic [31:0] dut_p_54;
  assign lh_p_54_31_0 = dut_p_54[31:0];
  logic [4:0] dut_p_55;
  assign lh_p_55_4_0 = dut_p_55[4:0];
  logic [31:0] dut_p_56;
  assign lh_p_56_31_0 = dut_p_56[31:0];
  logic [0:0] dut_p_57;
  assign lh_p_57_0_0 = dut_p_57[0:0];
  logic [0:0] dut_p_58;
  assign lh_p_58_0_0 = dut_p_58[0:0];
  logic [0:0] dut_p_59;
  assign dut_p_59[0:0] = 1'd0;
  logic [36:0] dut_p_60;
  assign lh_p_60_36_0 = dut_p_60[36:0];
  logic [0:0] dut_p_61;
  assign lh_p_61_0_0 = dut_p_61[0:0];
  logic [0:0] dut_p_62;
  assign dut_p_62[0:0] = 1'd0;
  logic [67:0] dut_p_63;
  assign lh_p_63_67_0 = dut_p_63[67:0];
  logic [4:0] dut_p_64;
  assign dut_p_64[4:0] = 5'd0;
  logic [0:0] dut_p_65;
  assign lh_p_65_0_0 = dut_p_65[0:0];
  logic [134:0] dut_p_66;
  assign lh_p_66_134_0 = dut_p_66[134:0];
  logic [73:0] dut_p_67;
  assign dut_p_67[73:0] = 74'd0;
  logic [0:0] dut_p_68;
  assign lh_p_68_0_0 = dut_p_68[0:0];
  logic [0:0] dut_p_69;
  assign dut_p_69[0:0] = 1'd0;
  cve2_top #(
    .MHPMCounterNum(10),
    .MHPMCounterWidth(40),
    .RV32E(0),
    .RV32M(cve2_pkg::rv32m_e'(2)),
    .XInterface(0)
  ) u_dut (
    .boot_addr_i(dut_p_0),
    .clk_i(dut_p_1),
    .core_sleep_o(dut_p_2),
    .crash_dump_o(dut_p_3),
    .data_addr_o(dut_p_4),
    .data_be_o(dut_p_5),
    .data_err_i(dut_p_6),
    .data_gnt_i(dut_p_7),
    .data_rdata_i(dut_p_8),
    .data_req_o(dut_p_9),
    .data_rvalid_i(dut_p_10),
    .data_wdata_o(dut_p_11),
    .data_we_o(dut_p_12),
    .debug_halted_o(dut_p_13),
    .debug_req_i(dut_p_14),
    .dm_exception_addr_i(dut_p_15),
    .dm_halt_addr_i(dut_p_16),
    .fetch_enable_i(dut_p_17),
    .hart_id_i(dut_p_18),
    .instr_addr_o(dut_p_19),
    .instr_err_i(dut_p_20),
    .instr_gnt_i(dut_p_21),
    .instr_rdata_i(dut_p_22),
    .instr_req_o(dut_p_23),
    .instr_rvalid_i(dut_p_24),
    .irq_external_i(dut_p_25),
    .irq_fast_i(dut_p_26),
    .irq_nm_i(dut_p_27),
    .irq_software_i(dut_p_28),
    .irq_timer_i(dut_p_29),
    .ram_cfg_i(dut_p_30),
    .rst_ni(dut_p_31),
    .rvfi_ext_debug_req(dut_p_32),
    .rvfi_ext_mcycle(dut_p_33),
    .rvfi_ext_mip(dut_p_34),
    .rvfi_ext_nmi(dut_p_35),
    .rvfi_halt(dut_p_36),
    .rvfi_insn(dut_p_37),
    .rvfi_intr(dut_p_38),
    .rvfi_ixl(dut_p_39),
    .rvfi_mem_addr(dut_p_40),
    .rvfi_mem_rdata(dut_p_41),
    .rvfi_mem_rmask(dut_p_42),
    .rvfi_mem_wdata(dut_p_43),
    .rvfi_mem_wmask(dut_p_44),
    .rvfi_mode(dut_p_45),
    .rvfi_order(dut_p_46),
    .rvfi_pc_rdata(dut_p_47),
    .rvfi_pc_wdata(dut_p_48),
    .rvfi_rd_addr(dut_p_49),
    .rvfi_rd_wdata(dut_p_50),
    .rvfi_rs1_addr(dut_p_51),
    .rvfi_rs1_rdata(dut_p_52),
    .rvfi_rs2_addr(dut_p_53),
    .rvfi_rs2_rdata(dut_p_54),
    .rvfi_rs3_addr(dut_p_55),
    .rvfi_rs3_rdata(dut_p_56),
    .rvfi_trap(dut_p_57),
    .rvfi_valid(dut_p_58),
    .test_en_i(dut_p_59),
    .x_commit_o(dut_p_60),
    .x_commit_valid_o(dut_p_61),
    .x_issue_ready_i(dut_p_62),
    .x_issue_req_o(dut_p_63),
    .x_issue_resp_i(dut_p_64),
    .x_issue_valid_o(dut_p_65),
    .x_register_o(dut_p_66),
    .x_result_i(dut_p_67),
    .x_result_ready_o(dut_p_68),
    .x_result_valid_i(dut_p_69)
  );
endmodule
