"""Pure prepared-source validation. No constructor, tool query or native run."""
import gzip,hashlib,json,os,sys,subprocess
from pathlib import Path
BASE=Path('/root/fanzehui/cvw-ahb-observer-20261017-attempt1')
PROJECT=BASE/'project';CONTROL=BASE/'control'
sys.path[:0]=[str(PROJECT/'src'),str(PROJECT),'/root/fanzehui/system-20261016/pythonlib']
import cvw_ahb_gate_control as c
from scripts import verify_cvw_ahb_startup as gate
import myfuzz.local_harness.build  # establish original producer baselines
assert Path(c.__file__).resolve()==CONTROL/'cvw_ahb_gate_control.py'
assert Path(gate.__file__).resolve()==PROJECT/'scripts/verify_cvw_ahb_startup.py'
actual_popen=subprocess.Popen;calls=[]
expected_heads={str(PROJECT):'dc14fa398adac70f60048a91195eedd60e531866',str(PROJECT/'third_party/cvw_upstream_reference'):'2f2ddfd4c3c7f5d3a655e4488831d9277673105a',str(PROJECT/'third_party/caliptra_upstream_reference'):'49370266d12cb0c4a8f71b3a0ff7e54ba7d4866e'}
def guard(argv,*args,**kwargs):
 argv=list(argv)
 if not (len(argv)==5 and argv[0]=='git' and argv[1]=='-C' and argv[2] in expected_heads and argv[3:]==['rev-parse','HEAD']):
  raise AssertionError('pure preparation cannot execute '+repr(argv))
 calls.append(argv);return actual_popen(argv,*args,**kwargs)
subprocess.Popen=guard
c.validate_environment(BASE,os.environ)
for name in ['operation.claim.json','controller.claim.json','child.started.json','controller.terminal.json','operation.terminal.json','child.stdout','child.stderr']:
 path=CONTROL/name
 assert not path.exists() and not path.is_symlink(),name
assert not (BASE/'run').exists()
manifest=json.loads((CONTROL/'control-manifest.json').read_bytes())
for name,row in manifest.items():
 path=CONTROL/name;assert not path.is_symlink()
 assert c.sha(path.read_bytes())==row['sha256'] and path.stat().st_mode&0o777==row['mode'],name
control_before=c.source_map(CONTROL)
expected_raw=(CONTROL/'source-map.json').read_bytes()
assert c.sha(expected_raw)=='75244d6c7b7e6490ece1c70c20d3e143f9791804dd8f2a247f6e4d088af0dce9'
expected=json.loads(expected_raw);c.validate_git_metadata(PROJECT);c.verify_source_map(PROJECT,expected)
before=c.source_map(PROJECT)
freeze_raw=(CONTROL/'source-freeze.json').read_bytes()
assert c.sha(freeze_raw)=='c02134412a742eccde99746af5487f81c2f77f09a7cf20250ce37f2077762e8f'
freeze=json.loads(freeze_raw);gate.verify_freeze(PROJECT,freeze)
readset_receipt=json.loads((CONTROL/'copied-profile-readsets.json').read_bytes())
readsets={}
for profile,expected_rows in readset_receipt['readsets'].items():
 readsets[profile]=c.profile_read_set(PROJECT,profile);assert readsets[profile]==expected_rows
heads={}
for directory,expected_head in expected_heads.items():
 heads[directory]=subprocess.check_output(['git','-C',directory,'rev-parse','HEAD'],cwd=PROJECT,text=True).strip()
 assert heads[directory]==expected_head
paths=['/root/fanzehui/system-20261016/bin/c++','/root/fanzehui/myfuzz/.tools/verilator-5.051-e413e67/bin/verilator']
tools_before=c.tool_file_map(paths)
after=c.source_map(PROJECT);tools_after=c.tool_file_map(paths);control_after=c.source_map(CONTROL)
assert before==after==expected and tools_before==tools_after and control_before==control_after
ready=dict(schema_version='cvw_ahb_startup_remote_prepared.v1',grade='pure_source_copy_hash_import_only',
 prepared_pid=os.getpid(),native_run=False,model_run=False,build_run=False,frontend_run=False,constructor_called=False,tool_version_query=False,
 base=str(BASE),source_files=len(before),source_bytes=sum(row.get('bytes',0) for row in before.values()),
 source_map_sha256=c.sha(expected_raw),source_freeze_sha256=c.sha(freeze_raw),host_files=len(freeze['files']),
 git_heads=heads,git_self_contained=True,no_hardlinks=True,no_external_links=True,
 source_before_after_equal=True,control_before_after_equal=True,tools_before_after_equal=True,
 control_before=control_before,control_after=control_after,
 control_maps_exclude_only_this_new_ready_receipt=True,
 source_map_artifact='source-map.json',profile_readsets=readsets,tools=tools_before,
 environment_dependency_only={'AR':'/usr/bin/x86_64-linux-gnu-ar','file_not_read':True},
 external_commands=calls,operation_state='unused',canonical_heavy_lock='/root/fanzehui/system-20261016/project/.superpowers/heavy-worker.lock',
 source_authority=False,retirement_verified=False)
c.claim_state(CONTROL/'ready.json',ready)
print(json.dumps({'ready_sha256':c.sha((CONTROL/'ready.json').read_bytes()),'source_files':len(before),'host_files':len(freeze['files']),'git_heads':heads,'tools':tools_before,'native_run':False,'operation_state':'unused'},sort_keys=True))
