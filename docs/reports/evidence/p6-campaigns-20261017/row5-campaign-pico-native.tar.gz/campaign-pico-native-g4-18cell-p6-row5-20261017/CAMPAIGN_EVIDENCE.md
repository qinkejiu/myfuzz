# P6 row 5 (PicoRV32 native x PULP APB3 GPIO) campaign run record

This file is written from the saved `campaign_report.json`; it repeats
only fields that file contains. The independent audit recomputes every
count, verdict and identity from the per-cell artifacts:

```
PYTHONPATH=src python3 -m pytest \
    tests/integration/test_picorv32_native_campaign_saved_run_audit.py -q
```

## Status

* `gate_status`: `complete`
* cells complete: 18/18
* `effective_search_seconds`: 2862.573474041006
* `campaign_run_identity_sha256`: `f34b30b3fe9374bf41df702fc3976d6bc48a1c40d32a3c20c978149202eed790`
* provider/fixture/input/client identity: `pico_native_campaign_source_identity.json`

## What it is

18 G4 cells (3 strategies x 2 directions x 3 seeds) over the pinned
PicoRV32 native ready/valid memory CPU and the pinned PULP APB3 GPIO.
Bound cells route the CPU device window to the real GPIO with queued
`DataflowRouter.enqueue` delivery on the device's own step; independent
cells answer the same window from a declared local shadow and claim no
cross-component chain. Both directions declare the CPU program immediate
and the external GPIO pin byte. Each direction runs two ordered rounds
and commits `A ^ B` and `(A ^ B) + B` to RAM.

## What it does not prove

* No IRQ/handler path: the pinned native profile has no interrupt
  endpoint and `ENABLE_IRQ=0`; nothing is synthesised.
* No cross-case persistent RTL or RAM state: the campaign uses fresh
  genomes, so each case starts both harnesses and rebuilds RAM from the
  genome images. Cases share the search, decoder, corpus and feedback.
* No controlled-error inspection: this bundle injects no fault.
* The dependency-guided hint is not a proof that every source was
  *known* to be productive in advance; the receipts record selection and
  trace-proven consumption, which is what the audit checks.

## How it was produced

```
PYTHONPATH=src python3 scripts/run_scenario_campaign.py \
    --manifest configs/scenario/pico_native_gpio_campaign_seed.json \
    --baseline-manifest configs/scenario/pico_native_gpio_campaign_baseline.json \
    --seconds 150.0 --seed 20260927 \
    --output runs/scenario/campaign-pico-native-g4-18cell-p6-row5-20261017 \
    --provider myfuzz.integration.picorv32_native_scenario_campaign:PicoNativeGpioBoundProvider
PYTHONPATH=src python3 -m myfuzz.integration.picorv32_native_scenario_campaign \
    runs/scenario/campaign-pico-native-g4-18cell-p6-row5-20261017
```
