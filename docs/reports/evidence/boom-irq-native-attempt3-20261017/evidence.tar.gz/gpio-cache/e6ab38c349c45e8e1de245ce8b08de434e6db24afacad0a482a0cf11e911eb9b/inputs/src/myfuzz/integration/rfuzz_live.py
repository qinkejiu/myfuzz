"""Run the official RFuzz mutator against a generated persistent RTL simulator."""
import ctypes
from collections.abc import Mapping, Sequence
import hashlib
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import time
from myfuzz.contracts import canonical_bytes
from myfuzz.composition.soc_peer_replay import (
    PeerRawReplayError,
    decode_peer_raw_events,
    peer_event_hash,
)
from .rfuzz_fifo import FifoEndpoint
from .rfuzz_shmem import process_pair
from .rfuzz_simulator import RtlSimulator
from .campaign import CampaignError, read_process_group_rss_bytes

MAX_FAILURE_CASES = 1024
MAX_FAILURE_BYTES = 64 * 1024 * 1024
MAX_PROJECTION_REJECTIONS = 1024
MAX_PROJECTION_REJECTION_BYTES = 64 * 1024 * 1024
ISOLATED_DRAIN_LIMIT_SECONDS = 420


def _drain_limit_seconds(artifact):
    """Bound completion of an in-flight official RFuzz batch after SIGINT."""
    # The pinned client can hand over a batch of up to 21,845 inputs. CPU
    # campaigns restart the simulator for every testcase, so measured batches
    # need longer than the ordinary live-run drain allowance.
    return ISOLATED_DRAIN_LIMIT_SECONDS if getattr(artifact, "isolate_tests", False) else 60


def _rfuzz_client_buffer_kib(environment=None):
    """Resolve the patched official client's optional shared-memory batch size."""
    values = os.environ if environment is None else environment
    if not isinstance(values, Mapping):
        raise ValueError("rfuzz-client-buffer-kib:environment-required")
    raw = values.get("MYFUZZ_RFUZZ_TEST_BUFFER_KIB")
    if raw is None:
        return 1024
    if not isinstance(raw, str) or not raw.isdecimal():
        raise ValueError("rfuzz-client-buffer-kib:decimal-required")
    kib = int(raw)
    if not 64 <= kib <= 65536:
        raise ValueError("rfuzz-client-buffer-kib:outside-bounds")
    return kib


def _rfuzz_client_max_runs(environment=None):
    """Resolve the optional official-client mutation-call batch limit."""
    values = os.environ if environment is None else environment
    if not isinstance(values, Mapping):
        raise ValueError("rfuzz-client-max-runs:environment-required")
    raw = values.get("MYFUZZ_RFUZZ_MAX_RUNS_PER_BATCH")
    if raw is None:
        return 16384
    if not isinstance(raw, str) or not raw.isdecimal():
        raise ValueError("rfuzz-client-max-runs:decimal-required")
    count = int(raw)
    if not 256 <= count <= 16384:
        raise ValueError("rfuzz-client-max-runs:outside-bounds")
    return count


class CheckerFailureStore:
    """Save bounded, deduplicated raw RFuzz records for checker failures."""

    def __init__(self, output_dir, artifact, *, max_cases=MAX_FAILURE_CASES,
                 max_bytes=MAX_FAILURE_BYTES):
        self.directory = Path(output_dir) / "failures"
        self.artifact = artifact
        self.max_cases = max_cases
        self.max_bytes = max_bytes
        self.cases = []
        self.by_hash = {}
        self.saved_bytes = 0
        self.dropped_cases = 0

    @property
    def saved_cases(self):
        return len(self.cases)

    def document(self):
        return {"schema_version": "checker_failure_manifest.v1",
                "entries": self.saved_cases, "saved_bytes": self.saved_bytes,
                "dropped_cases": self.dropped_cases,
                "max_cases": self.max_cases, "max_bytes": self.max_bytes,
                "cases": list(self.cases)}

    def record(self, records, counters):
        ports = tuple(getattr(self.artifact, "coverage_ports", ()))
        if len(counters) != len(ports):
            raise ValueError("checker failure counter length mismatch")
        failed = [bit for index, (name, bit) in enumerate(ports)
                  if name == "checker_fail_o" and counters[index] > 0]
        if not failed:
            return None
        width = self.artifact.transport.byte_count
        if (not records or any(not isinstance(row, bytes) or len(row) != width
                               for row in records)):
            raise ValueError("checker failure raw record width mismatch")
        payload = b"".join(records)
        input_hash = _hash_bytes(payload)
        mask = sum(1 << bit for bit in failed)
        mask_text = f"0x{mask:013x}"
        prior = self.by_hash.get(input_hash)
        if prior is not None:
            if prior["failure_mask"] != mask_text:
                raise ValueError("checker failure replay changed failure mask")
            return prior
        if self.saved_cases >= self.max_cases or self.saved_bytes + len(payload) > self.max_bytes:
            self.dropped_cases += 1
            return None
        build = getattr(self.artifact, "build_document", None)
        feedback = build.get("checker_feedback") if isinstance(build, Mapping) else None
        properties = feedback.get("properties", ()) if isinstance(feedback, Mapping) else ()
        ids = {item.get("bit"): item.get("property_id") for item in properties
               if isinstance(item, Mapping)}
        filename = f"case_{input_hash.removeprefix('sha256:')}.bin"
        entry = {"input_sha256": input_hash, "raw_file": filename,
                 "record_width_bytes": width, "cycles": len(records),
                 "failure_mask": mask_text,
                 "failure_ids": [ids.get(bit) or f"checker_fail_o[{bit}]"
                                 for bit in failed]}
        self.directory.mkdir(parents=True, exist_ok=True)
        raw_path = self.directory / filename
        staging_raw = self.directory / (filename + ".tmp")
        staging_raw.write_bytes(payload)
        staging_raw.replace(raw_path)
        self.cases.append(entry)
        self.by_hash[input_hash] = entry
        self.saved_bytes += len(payload)
        manifest = self.directory / "manifest.json"
        staging = self.directory / "manifest.json.tmp"
        staging.write_bytes(canonical_bytes(self.document()))
        staging.replace(manifest)
        return entry


class ProjectionRejectionStore:
    """Save bounded raw RFuzz inputs refused by the declared candidate program."""

    def __init__(self, output_dir, artifact, *, max_cases=MAX_PROJECTION_REJECTIONS,
                 max_bytes=MAX_PROJECTION_REJECTION_BYTES):
        self.directory = Path(output_dir) / "projection_rejections"
        self.artifact = artifact
        self.max_cases = max_cases
        self.max_bytes = max_bytes
        self.cases = []
        self.by_hash = {}
        self.saved_bytes = 0
        self.repeated_cases = 0
        self.dropped_cases = 0

    @property
    def saved_cases(self):
        return len(self.cases)

    def document(self):
        return {
            "schema_version": "rfuzz_projection_rejection_manifest.v1",
            "entries": self.saved_cases,
            "saved_bytes": self.saved_bytes,
            "repeated_cases": self.repeated_cases,
            "dropped_cases": self.dropped_cases,
            "max_cases": self.max_cases,
            "max_bytes": self.max_bytes,
            "cases": list(self.cases),
        }

    def record(self, records, rejection):
        width = self.artifact.transport.byte_count
        if (not records or any(not isinstance(row, bytes) or len(row) != width
                               for row in records)):
            raise ValueError("projection rejection raw record width mismatch")
        if (not isinstance(rejection, Mapping)
                or not isinstance(rejection.get("type"), str)
                or not isinstance(rejection.get("message"), str)):
            raise ValueError("projection rejection reason is invalid")
        payload = b"".join(records)
        input_hash = _hash_bytes(payload)
        prior = self.by_hash.get(input_hash)
        if prior is not None:
            prior["occurrences"] += 1
            self.repeated_cases += 1
            return prior
        if self.saved_cases >= self.max_cases or self.saved_bytes + len(payload) > self.max_bytes:
            self.dropped_cases += 1
            return None
        filename = f"case_{input_hash.removeprefix('sha256:')}.bin"
        entry = {
            "input_sha256": input_hash,
            "raw_file": filename,
            "record_width_bytes": width,
            "cycles": len(records),
            "occurrences": 1,
            "rejection_type": rejection["type"][:128],
            "rejection_message": rejection["message"][:512],
        }
        self.directory.mkdir(parents=True, exist_ok=True)
        raw_path = self.directory / filename
        staging_raw = self.directory / (filename + ".tmp")
        staging_raw.write_bytes(payload)
        staging_raw.replace(raw_path)
        self.cases.append(entry)
        self.by_hash[input_hash] = entry
        self.saved_bytes += len(payload)
        self.write_manifest()
        return entry

    def write_manifest(self):
        self.directory.mkdir(parents=True, exist_ok=True)
        manifest = self.directory / "manifest.json"
        staging = self.directory / "manifest.json.tmp"
        staging.write_bytes(canonical_bytes(self.document()))
        staging.replace(manifest)
        return manifest


def _hash_bytes(data):
    return "sha256:" + hashlib.sha256(data).hexdigest()


def _record_simulator_diagnostics(state, simulator):
    """Retain a bounded stdout sample while counting every captured RTL line."""
    report = state.setdefault("simulator_diagnostics", {"lines": 0, "sample_limit": 32, "samples": []})
    lines = getattr(simulator, "last_diagnostics", ())
    report["lines"] += len(lines)
    report["samples"].extend(lines[:max(0, report["sample_limit"] - len(report["samples"]))])


def _constraint_hash(artifact):
    projector = getattr(artifact, "projector", None)
    value = getattr(projector, "constraint_hash", None)
    if isinstance(value, str) and value:
        return value
    layout = getattr(artifact, "layout", None)
    fields = []
    for field in getattr(layout, "fields", ()):
        fields.append({
            "field_id": getattr(field, "field_id", None),
            "constraint": dict(getattr(field, "constraint", {})),
            "encoding": getattr(field, "encoding", None),
        })
    return _hash_bytes(canonical_bytes({
        "schema_version": "runtime_constraints.fallback.v1",
        "layout_hash": getattr(layout, "layout_hash", "unavailable"),
        "fields": fields,
    }))


def _binary_hash(artifact):
    executable = getattr(artifact, "executable", None)
    if executable is None:
        return "unavailable"
    path = Path(executable)
    if not path.is_file():
        return "unavailable"
    return _hash_bytes(path.read_bytes())


def _ibex_instruction_coverage_document(artifact, counter_maxima):
    """Decode the RVFI instruction-class counters into a named campaign summary."""
    build = getattr(artifact, "build_document", None)
    coverage = build.get("ibex_instruction_coverage") if isinstance(build, Mapping) else None
    if not isinstance(coverage, Mapping):
        return None
    bins = coverage.get("bins")
    observations = coverage.get("observations")
    ports = tuple(getattr(artifact, "coverage_ports", ()))
    if (not isinstance(bins, Sequence) or isinstance(bins, (str, bytes))
            or not isinstance(observations, Sequence)
            or isinstance(observations, (str, bytes))
            or len(bins) != len(observations)):
        return {"status": "invalid-build-coverage-map", "bins": {}}
    maxima = tuple(counter_maxima)
    results = {}
    for name, observation in zip(bins, observations):
        if (not isinstance(name, str) or not isinstance(observation, Sequence)
                or isinstance(observation, (str, bytes)) or len(observation) != 2):
            return {"status": "invalid-build-coverage-map", "bins": {}}
        port = (str(observation[0]), int(observation[1]))
        try:
            index = ports.index(port)
        except ValueError:
            return {"status": "invalid-build-coverage-map", "bins": {}}
        count = maxima[index] if index < len(maxima) else 0
        results[name] = {"counter_maximum": int(count), "covered": int(count) > 0}
    covered = sum(item["covered"] for item in results.values())
    return {
        "status": "observed",
        "source": coverage.get("source"),
        "semantic_oracle": coverage.get("semantic_oracle", "not_assessed"),
        "covered_bins": covered,
        "total_bins": len(results),
        "all_bins_covered": covered == len(results),
        "bins": results,
    }


def _physical_control_document(artifact):
    defaults = getattr(artifact, "control_defaults", {})
    randomized = getattr(artifact, "randomized_controls", ())
    return {
        "defaults": defaults if isinstance(defaults, dict) else dict(defaults or {}),
        "randomized": list(randomized),
        "simulator": getattr(artifact, "simulator", "icarus"),
        "isolate_tests": getattr(artifact, "isolate_tests", False),
        "execution_monitor": getattr(artifact, "execution_monitor", None),
    }


def _simulator_input_document(artifact):
    document = []
    for argument in getattr(artifact, "simulator_args", ()):
        if argument.startswith("+riscv_boot_image="):
            path = Path(argument.split("=", 1)[1]).resolve()
            if not path.is_file():
                raise ValueError("simulator boot image is missing")
            document.append({"name": "riscv_boot_image", "sha256": _hash_bytes(path.read_bytes())})
        else:
            document.append({"value": argument})
    return document


def replay_identity(artifact, raw_payload):
    if not isinstance(raw_payload, bytes) or not raw_payload:
        raise ValueError("replay raw payload must be nonempty bytes")
    if getattr(artifact, "transducer_hash", None) is not None and not getattr(artifact, "implementation_hash", None):
        raise ValueError("replay transducer implementation identity is missing")
    layout = getattr(artifact, "layout", None)
    layout_hash = getattr(layout, "layout_hash", None)
    if not isinstance(layout_hash, str) or not layout_hash:
        raise ValueError("replay layout identity is missing")
    constraint_hash = _constraint_hash(artifact)
    binary_hash = _binary_hash(artifact)
    physical_controls = _physical_control_document(artifact)
    physical_controls_hash = _hash_bytes(canonical_bytes(physical_controls))
    simulator_inputs = _simulator_input_document(artifact)
    simulator_inputs_hash = _hash_bytes(canonical_bytes(simulator_inputs))
    inputs = {
        "raw_sha256": _hash_bytes(raw_payload),
        "layout_hash": layout_hash,
        "constraint_hash": constraint_hash,
        "binary_sha256": binary_hash,
        "physical_controls_sha256": physical_controls_hash,
        "simulator_inputs_sha256": simulator_inputs_hash,
    }
    for key in ("transducer_hash", "header_hash", "implementation_hash"):
        value = getattr(artifact, key, None)
        if value is not None:
            inputs[key] = value
    return {
        **inputs,
        "physical_controls": physical_controls,
        "simulator_inputs": simulator_inputs,
        "binary_hash": binary_hash,
        "replay_key": _hash_bytes(canonical_bytes(inputs)),
    }


_CONTRACT_REPLAY_KEYS = (
    "raw_sha256", "layout_hash", "constraint_hash", "transducer_hash",
    "implementation_hash", "header_hash", "physical_controls_sha256",
    "simulator_inputs_sha256",
)


def _corpus_document(path, *, byte_count):
    max_size = 5 * byte_count * 200 + 4 * 1024 * 1024
    if path.stat().st_size > max_size:
        raise ValueError("oversized RFuzz corpus entry")
    document = json.loads(path.read_text())
    if not isinstance(document, dict) or not isinstance(document.get("entry"), dict):
        raise ValueError("invalid RFuzz corpus entry")
    raw = document["entry"].get("inputs")
    expected = document.get("trace_bits")
    if (
        not isinstance(raw, list)
        or not isinstance(expected, list)
        or any(type(value) is not int or not 0 <= value <= 255 for value in raw + expected)
    ):
        raise ValueError("invalid RFuzz corpus bytes")
    if not raw or len(raw) % byte_count or len(raw) // byte_count > 200:
        raise ValueError("invalid RFuzz corpus input size")
    return document, bytes(raw), expected


def _peer_events_for_payload(artifact, payload):
    """Decode the projected raw payload under the artifact's peer contract."""
    slots = tuple(getattr(artifact, "peer_slots", ()) or ())
    if not slots:
        return ()
    width = int(artifact.transport.byte_count)
    records = tuple(payload[index:index + width]
                    for index in range(0, len(payload), width))
    values = [artifact.transport.unpack(record) for record in records]
    projector = getattr(artifact, "projector", None)
    project_records = getattr(projector, "project_records", None)
    projected = (tuple(project_records(values)) if callable(project_records)
                 else tuple(projector.project(value) for value in values))
    try:
        return decode_peer_raw_events(projected, artifact.layout, slots,
                                      validate_spacing=False)
    except PeerRawReplayError as error:
        raise ValueError(f"peer event evidence decode failed: {error}") from error


def _annotate_peer_events(artifact, corpus):
    """Persist semantic peer events for raw entries before manifest replay."""
    if not tuple(getattr(artifact, "peer_slots", ()) or ()):
        return
    width = artifact.transport.byte_count
    for path in sorted(Path(corpus).glob("entry_*.json")):
        document, payload, _expected = _corpus_document(path, byte_count=width)
        if "peer_events" in document and "peer_event_hash" in document:
            continue
        if "peer_events" in document or "peer_event_hash" in document:
            raise ValueError(f"peer event evidence incomplete: {path.name}")
        events = _peer_events_for_payload(artifact, payload)
        document["peer_events"] = [dict(item) for item in events]
        document["peer_event_hash"] = peer_event_hash(events)
        path.write_text(json.dumps(document, sort_keys=True) + "\n", encoding="utf-8")


def build_corpus_manifest(artifact, corpus_dir, *, feedback_receipts=None):
    """Index the actual RFuzz-saved wire corpus without synthesizing coverage."""
    corpus = Path(corpus_dir)
    paths = sorted(corpus.glob("entry_*.json"))
    if not paths:
        raise ValueError("empty RFuzz corpus")
    width = artifact.transport.byte_count
    # The official client only knows the raw wire ABI.  Enrich its entries
    # before replay so the saved corpus also carries the declared peer slot,
    # cycle and payload evidence.  A direct replay of an unannotated peer
    # corpus remains a refusal (see replay_corpus below).
    _annotate_peer_events(artifact, corpus)
    verified = replay_corpus(artifact, corpus, _capture_receipts=feedback_receipts)
    verified_by_file = {entry["file"]: entry for entry in verified["replays"]}
    replays = []
    for path in paths:
        document, payload, expected = _corpus_document(path, byte_count=width)
        identity = replay_identity(artifact, payload)
        actual = verified_by_file.get(path.name)
        if actual is None or actual.get("input_sha256") != identity["raw_sha256"]:
            raise ValueError(f"RFuzz corpus coverage was not verified: {path.name}")
        declared = document.get("replay_identity")
        if isinstance(declared, dict):
            if getattr(artifact, "transducer_hash", None) is not None and not declared.get("implementation_hash"):
                raise ValueError(f"RFuzz replay identity mismatch: implementation_hash missing: {path.name}")
            for key in ("raw_sha256", "layout_hash", "constraint_hash", "binary_sha256",
                        "physical_controls_sha256", "simulator_inputs_sha256", "replay_key",
                        "transducer_hash", "header_hash", "implementation_hash"):
                if getattr(artifact, "transducer_hash", None) is not None and key in ("binary_sha256", "replay_key"):
                    # replay_corpus already checked the original build binding,
                    # including its sidecar when this is an independent rebuild.
                    continue
                if key in declared and declared[key] != identity.get(key):
                    raise ValueError(f"RFuzz replay identity mismatch: {path.name}")
        receipt = (identity["raw_sha256"], _hash_bytes(bytes(actual["counters"])))
        if feedback_receipts is not None and receipt not in feedback_receipts:
            raise ValueError(f"RFuzz corpus lacks completed shared-memory exchange: {path.name}")
        replays.append({
            "file": path.name,
            "input_bytes": len(payload),
            "cycles": len(payload) // width,
            "input_sha256": identity["raw_sha256"],
            "trace_sha256": _hash_bytes(bytes(expected)),
            "coverage_sha256": _hash_bytes(bytes(actual["counters"])),
            "coverage_verified": True,
            "shared_memory_exchange_verified": feedback_receipts is not None,
            **identity,
            **({"peer_event_hash": actual["peer_event_hash"]}
               if isinstance(actual, Mapping) and "peer_event_hash" in actual else {}),
        })
    return {
        "schema_version": "rfuzz_corpus_manifest.v1",
        "coverage_kind": getattr(artifact, "coverage_kind", "unspecified-rtl-feedback"),
        "coverage_transport": "sysv-shared-memory-rfuzz-coverage-buffer",
        "entries": len(replays),
        "layout_hash": replays[0]["layout_hash"],
        **{key: replays[0][key] for key in ("transducer_hash", "header_hash", "implementation_hash") if key in replays[0]},
        "constraint_hash": replays[0]["constraint_hash"],
        "binary_sha256": replays[0]["binary_sha256"],
        "physical_controls_sha256": replays[0]["physical_controls_sha256"],
        "simulator_inputs_sha256": replays[0]["simulator_inputs_sha256"],
        "instruction_mode": getattr(getattr(artifact, "projector", None), "instruction_mode", "none"),
        "replays": replays,
        **({"peer_event_mode": "raw-abi-derived-v1"}
           if getattr(artifact, "peer_slots", ()) else {}),
    }


def _configuration(artifact):
    lines = ['[general]', 'filename = "live_tb.sv"', 'instrumented = "live_tb.sv"',
             'top = "myfuzz_live_tb"', 'timestamp = 2026-09-07T00:00:00Z',
             '[[input]]', 'name = "raw_bits"', f'width = {artifact.layout.raw_width}']
    for index, (port, bit) in enumerate(artifact.coverage_ports):
        name = json.dumps(f"{port}[{bit}]")
        is_failure = port == "checker_fail_o"
        human = ("checker sticky failure" if is_failure else
                 "checker property evaluated" if port == "checker_eval_o" else
                 "source-instrumented RTL branch" if port == "__vi_coverage" else
                 "sampled output-bit event")
        lines.extend(['[[coverage]]', f'port = {name}', f'name = {name}', f'index = {index}',
            'filename = "live_tb.sv"', 'line = 0', 'column = 0',
            f'human = {json.dumps(human)}', '[[counter]]',
            f'name = {name}', 'width = 8', 'max = 255', 'scale = false',
            f'index = {index}', f'signal = {index}',
            'fail = true' if is_failure else 'fail = false'])
    return "\n".join(lines) + "\n"


def _owned_segments(pid):
    rows = Path("/proc/sysvipc/shm").read_text().splitlines()
    result = []
    for row in rows[1:]:
        entry = dict(zip(rows[0].split(), row.split()))
        if all(int(entry[key]) == value for key, value in (
                ("cpid", pid), ("uid", os.getuid()), ("cuid", os.getuid()))):
            result.append(int(entry["shmid"]))
    return result


def encode_initial_seed(artifact, values, seed_cycles):
    """Pack an optional one-raw-sample-per-cycle RFuzz starting seed."""
    if values is None:
        return None
    if isinstance(values, (str, bytes)) or not isinstance(values, Sequence):
        raise ValueError("initial-seed:sample-array-required")
    if len(values) != seed_cycles:
        raise ValueError("initial-seed:cycle-count-mismatch")
    raw_width = int(artifact.layout.raw_width)
    payload = bytearray()
    for value in values:
        if type(value) is not int or not 0 <= value < (1 << raw_width):
            raise ValueError("initial-seed:sample-out-of-range")
        record = artifact.transport.pack(value)
        if not isinstance(record, bytes) or len(record) != int(artifact.transport.byte_count):
            raise ValueError("initial-seed:transport-record-invalid")
        payload.extend(record)
    return bytes(payload)


def run_live(artifact, client_binary, output_dir, *, duration_seconds=30, seed_cycles=5,
             initial_seed_values=None, environment=None):
    """Retain a failure report even when startup or an RTL exchange raises."""
    state = {}
    def terminated(signum, frame):
        # Defer asynchronous termination to a supervised checkpoint. Raising
        # inside Popen or cleanup can strand a successfully launched child.
        state["termination_signal"] = signal.Signals(signum).name
    # signal.signal deliberately rejects non-main-thread use before launching
    # anything: this supervisor must be able to handle external termination.
    previous_term = signal.signal(signal.SIGTERM, terminated)
    previous_int = signal.signal(signal.SIGINT, terminated)
    try:
        result = _run_live(artifact, client_binary, output_dir,
                           duration_seconds=duration_seconds, seed_cycles=seed_cycles, state=state,
                           initial_seed_values=initial_seed_values,
                           environment=environment)
        if "termination_signal" in state:
            raise KeyboardInterrupt(state["termination_signal"] + " received during RFuzz run")
        return result
    except BaseException as error:
        output = state.pop("_output", None)
        if output is not None:
            state.update(status="failed", error=f"{type(error).__name__}: {error}")
            (output / "report.json").write_text(json.dumps(state, sort_keys=True) + "\n")
        raise
    finally:
        signal.signal(signal.SIGTERM, previous_term)
        signal.signal(signal.SIGINT, previous_int)


def _run_live(artifact, client_binary, output_dir, *, duration_seconds, state, seed_cycles=5,
              initial_seed_values=None, environment=None):
    if type(duration_seconds) not in (int,float) or not math.isfinite(duration_seconds) or not 0 < duration_seconds <= 86400:
        raise ValueError("finite positive live duration required")
    if type(seed_cycles) is not int or not 1 <= seed_cycles <= 200:
        raise ValueError("seed cycles must be between 1 and 200")
    client_buffer_kib = _rfuzz_client_buffer_kib(environment)
    client_max_runs = _rfuzz_client_max_runs(environment)
    initial_seed = encode_initial_seed(artifact, initial_seed_values, seed_cycles)
    binary=Path(client_binary).resolve(strict=True)
    output=Path(output_dir).absolute()
    if output.exists() or output.is_symlink():
        raise ValueError("live output must be new")
    output.mkdir(parents=True)
    state.update(_output=output, tests=0, rtl_tests=0, status="starting", layout_hash=artifact.layout.layout_hash,
                 rfuzz_client_buffer_kib=client_buffer_kib,
                 rfuzz_client_max_runs_per_batch=client_max_runs,
                 client_binary=str(binary), client_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
                 coverage_kind=artifact.coverage_kind, requested_duration_seconds=duration_seconds,
                 transport=artifact.transport.document(),
                 constraint_hash=_constraint_hash(artifact),
                 binary_sha256=_binary_hash(artifact),
                 instruction_mode=getattr(getattr(artifact, "projector", None), "instruction_mode", "none"),
                 runtime_controls=getattr(artifact, "control_defaults", None),
                 randomized_controls=list(getattr(artifact, "randomized_controls", ())),
                 coverage_transport="sysv-shared-memory-rfuzz-coverage-buffer",
                 memory_scope="runner PID plus owned client and simulator process groups; sampled RSS",
                 soft_rss_bytes=512 * 1024 * 1024, hard_rss_bytes=768 * 1024 * 1024,
                 memory_poll_min_interval_seconds=.1,
                 memory_poll_policy="check at FIFO/RTL IO checkpoints; scheduling and encoding can delay sampling")
    if hasattr(artifact, "executable"):
        provenance = artifact.executable.parent / "artifact_provenance.json"
        if not provenance.is_file():
            provenance = artifact.executable.parent.parent / "artifact_provenance.json"
        state["artifact_provenance"] = json.loads(provenance.read_text()) if provenance.is_file() else None
        state["simulator_sha256"] = hashlib.sha256(artifact.executable.read_bytes()).hexdigest()
    state["mutation_seed"] = None
    state["mutation_seed_policy"] = "upstream has no global seed option; retain corpus lineage and raw inputs for replay"
    state["mutation_mode"] = "official default deterministic and havoc mutation, JQF level 2"
    seed_path = None
    if initial_seed is None:
        state["initial_seed"] = {"kind": "all-zero", "cycles": seed_cycles}
    else:
        seed_path = output / "initial_seed.bin"
        seed_path.write_bytes(initial_seed)
        state["initial_seed"] = {
            "kind": "explicit-raw-samples", "cycles": seed_cycles,
            "sha256": _hash_bytes(initial_seed), "file": seed_path.name,
        }
    config=output/"rfuzz.toml"
    config.write_text(_configuration(artifact))
    state["config_sha256"] = hashlib.sha256(config.read_bytes()).hexdigest()
    started=time.monotonic()
    deadline=started+duration_seconds
    # Upstream completes a full shared-memory batch before honoring SIGINT.
    # Process-isolated RTL tests need a larger, still bounded drain allowance.
    drain_limit = _drain_limit_seconds(artifact)
    state["drain_limit_seconds"] = drain_limit
    tests=0
    rtl_tests=0
    projection_rejections=0
    maxima=[0]*len(artifact.coverage_ports)
    failure_store = CheckerFailureStore(output, artifact)
    projection_rejection_store = ProjectionRejectionStore(output, artifact)
    peak=0
    next_memory_check=0
    interrupted=False
    client=None
    removed=[]
    receipts = set()
    pending_receipts = []
    # Keep a bounded, replayable receipt sample in addition to the set used
    # for corpus verification. Each row is the completed FIFO reply identity
    # (raw input hash plus actual RTL coverage hash).
    receipt_records = []
    execution_totals = {}
    next_checkpoint = started
    with FifoEndpoint() as endpoint, RtlSimulator(
            artifact, reject_invalid_projection=True) as simulator, (output/"client.log").open("wb") as log:
        # The pinned client's prettytable 0.6.7 crashes on this Rust build when
        # -c prints the final table. Omit only that optional presentation step;
        # upstream still saves corpus, statistics and its final raw bitmap.
        try:
            command = ["nice", "-n15", str(binary), str(config), "-s",
                       endpoint.directory.name, "-o", str(output / "corpus"),
                       "--seed-cycles", str(seed_cycles)]
            if seed_path is not None:
                command.extend(("--seed-input", str(seed_path)))
            client=subprocess.Popen(tuple(command),stdout=log,stderr=subprocess.STDOUT,
                start_new_session=True, env=(None if environment is None else dict(environment)))
            state.update(status="running", client_pid=client.pid, command=list(client.args),
                         compatibility="omit optional -c prettytable output; mutation mode unchanged")
            def check():
                nonlocal interrupted, peak, next_memory_check, next_checkpoint
                if "termination_signal" in state:
                    raise KeyboardInterrupt(state["termination_signal"] + " received during RFuzz run")
                now=time.monotonic()
                if now >= next_memory_check:
                    try:
                        client_memory = read_process_group_rss_bytes(client.pid)
                    except CampaignError:
                        if client.poll() is None:
                            raise
                        client_memory = 0  # The owned child exited during sampling.
                    memory=client_memory+read_process_group_rss_bytes(simulator.process.pid)
                    own_rss = next(line for line in Path("/proc/self/status").read_text().splitlines()
                                   if line.startswith("VmRSS:"))
                    memory += int(own_rss.split()[1]) * 1024
                    peak=max(peak,memory)
                    next_memory_check=now+.1
                    if memory >= 512*1024*1024:
                        raise MemoryError("live aggregate RSS reached soft memory limit")
                if now >= next_checkpoint:
                    checkpoint = {
                        "elapsed_seconds": now-started, "tests": tests,
                        "actual_rtl_tests": rtl_tests,
                        "projection_rejections": projection_rejections,
                        "counter_maxima": maxima, "peak_rss_bytes": peak,
                        "corpus_entries": len(tuple((output/"corpus").glob("entry_*.json"))),
                        "coverage_sha256": _hash_bytes(bytes(maxima)),
                        "errors": execution_totals.get("errors", 0),
                        "execution_totals": dict(execution_totals),
                        "completed_feedback_exchanges": len(receipts),
                        "checker_failures": {
                            "saved_cases": failure_store.saved_cases,
                            "saved_bytes": failure_store.saved_bytes,
                            "dropped_cases": failure_store.dropped_cases,
                        },
                    }
                    with (output/"checkpoints.jsonl").open("a") as checkpoints:
                        checkpoints.write(json.dumps(checkpoint, sort_keys=True)+"\n")
                    next_checkpoint = now+30
                if now>=deadline and not interrupted and client.poll() is None:
                    client.send_signal(signal.SIGINT)
                    interrupted=True
                    state["interrupt_elapsed_seconds"] = now-started
                if now>=deadline+drain_limit:
                    raise TimeoutError("RFuzz client failed to finish after interrupt")
            def execute(records):
                nonlocal tests, rtl_tests, projection_rejections
                check()
                try:
                    counters=simulator.run_test(records, monitor=check)
                finally:
                    _record_simulator_diagnostics(state, simulator)
                tests += 1
                state["tests"] = tests
                rejection = getattr(simulator, "last_projection_rejection", None)
                if rejection is not None:
                    if any(counters):
                        raise RuntimeError("rejected RFuzz input received nonzero coverage")
                    projection_rejections += 1
                    projection_rejection_store.record(records, rejection)
                    state["projection_rejections"] = projection_rejection_store.document()
                    state["projection_rejection_count"] = projection_rejections
                    return counters
                rtl_tests += 1
                state["rtl_tests"] = rtl_tests
                for key, value in getattr(simulator, "last_execution", {}).items():
                    execution_totals[key] = execution_totals.get(key, 0) + value
                state["execution_totals"] = dict(execution_totals)
                for index,value in enumerate(counters):
                    maxima[index]=max(maxima[index],value)
                failure_store.record(records, counters)
                pending_receipts.append((_hash_bytes(b"".join(records)), _hash_bytes(counters)))
                return counters
            while client.poll() is None:
                check()
                token=endpoint.receive(timeout=.02)
                if token is not None:
                    reply=process_pair(*token,creator_pid=client.pid,
                        input_bytes=artifact.transport.byte_count,counter_count=len(maxima),execute=execute)
                    endpoint.reply(reply)
                    receipts.update(pending_receipts)
                    for raw_hash, coverage_hash in pending_receipts:
                        if len(receipt_records) < 4096:
                            receipt_records.append({
                                "input_sha256": raw_hash,
                                "coverage_sha256": coverage_hash,
                                "status": "fifo_reply_and_rtl_completed",
                                "transport": "sysv-shared-memory-rfuzz-coverage-buffer",
                            })
                    pending_receipts.clear()
                    if len(receipts) > 250000:
                        raise RuntimeError("RFuzz feedback receipt bound exceeded")
        finally:
            if client is not None:
                # The launched client owns a new session. Clean the entire group
                # even if its leader already exited but left a descendant alive.
                try:
                    os.killpg(client.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                try:
                    client.wait(timeout=1)
                except subprocess.TimeoutExpired:
                    pass
                try:
                    os.killpg(client.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                client.wait(timeout=1)
                # Only this launched child's creator-owned segments can be removed.
                # Upstream normally removes them; this covers abnormal client exits.
                libc=ctypes.CDLL(None,use_errno=True)
                for segment in _owned_segments(client.pid):
                    if libc.shmctl(segment,0,None) == 0:
                        removed.append(segment)
                state.update(returncode=client.returncode, counter_maxima=maxima,
                             coverage_maxima=maxima,
                             coverage_feedback={
                                 "transport": "sysv-shared-memory-rfuzz-coverage-buffer",
                                 "records": tests,
                                 "counter_width": 8,
                                 "actual_rtl_records": rtl_tests,
                                 "projection_rejections": projection_rejections,
                             },
                             checker_failures=failure_store.document(),
                             projection_rejections=projection_rejection_store.document(),
                             projection_rejection_count=projection_rejections,
                             fifo_reply_receipts=receipt_records,
                             fifo_reply_receipt_count=len(receipts),
                             fifo_reply_receipt_sample_limit=4096,
                             actual_rtl_execution={
                                 "tests": rtl_tests,
                                 "execution_totals": dict(execution_totals),
                                 "coverage_records": len(receipts),
                                 "projection_rejections": projection_rejections,
                             },
                             peak_rss_bytes=peak, duration_seconds=time.monotonic()-started,
                             removed_owned_segments=removed, remaining_segments=_owned_segments(client.pid))
                projection_rejection_store.write_manifest()
                projection = getattr(simulator, "projection_document", None)
                if callable(projection):
                    try:
                        value = projection()
                    except Exception:
                        value = None
                    if isinstance(value, Mapping):
                        state["input_projection"] = dict(value)
                state["drain_seconds"] = (state["duration_seconds"] - state["interrupt_elapsed_seconds"]
                                          if "interrupt_elapsed_seconds" in state else 0)
    result={"returncode":client.returncode,"tests":tests,"counter_maxima":maxima,
        "coverage_kind":artifact.coverage_kind,"duration_seconds":time.monotonic()-started,
        "peak_rss_bytes":peak,"corpus_entries":len(tuple((output/"corpus").glob("entry_*.json"))),
        "remaining_segments":_owned_segments(client.pid),"removed_owned_segments":removed,
        "layout_hash":artifact.layout.layout_hash,"client_binary":str(binary)}
    result["fifo_reply_receipts"] = list(receipt_records)
    result["fifo_reply_receipt_count"] = len(receipts)
    result["fifo_reply_receipt_sample_limit"] = 4096
    result["actual_rtl_execution"] = {
        "tests": rtl_tests,
        "execution_totals": dict(execution_totals),
        "coverage_records": len(receipts),
        "projection_rejections": projection_rejections,
    }
    result["checker_failures"] = failure_store.document()
    result["projection_rejections"] = projection_rejection_store.document()
    result["projection_rejection_count"] = projection_rejections
    instruction_coverage = _ibex_instruction_coverage_document(artifact, maxima)
    if instruction_coverage is not None:
        result["ibex_instruction_coverage"] = instruction_coverage
    state.update(result)
    if client.returncode == 0:
        if not rtl_tests:
            raise RuntimeError("RFuzz client produced no accepted RTL tests")
        if not result["corpus_entries"]:
            raise RuntimeError("RFuzz client produced no saved corpus")
        if result["remaining_segments"]:
            raise RuntimeError("RFuzz client left owned shared-memory segments")
        manifest = build_corpus_manifest(artifact, output / "corpus", feedback_receipts=receipts)
        manifest_path = output / "corpus_manifest.json"
        manifest_path.write_text(json.dumps(manifest, sort_keys=True) + "\n")
        state["corpus_manifest_sha256"] = _hash_bytes(manifest_path.read_bytes())
        state["corpus_manifest"] = manifest
        state["completed_feedback_exchanges"] = len(receipts)
    result = {key: value for key, value in state.items() if key != "_output"}
    result["status"] = "completed" if client.returncode == 0 else "failed"
    (output/"report.json").write_text(json.dumps(result,sort_keys=True)+"\n")
    if client.returncode != 0:
        raise RuntimeError(f"RFuzz client exited {client.returncode}; see {output/'client.log'}")
    return result


def replay_corpus(artifact, corpus_dir, *, _capture_receipts=None):
    """Compare persisted upstream trace bytes with a fresh real RTL execution.

    Upstream config.rs aligns (counter bytes + two cycle-prefix bytes) to eight;
    its saved trace_bits includes the zero transport padding after the counters.
    """
    count = len(artifact.coverage_ports)
    padded_count = ((count + 9) // 8) * 8 - 2
    paths = sorted(Path(corpus_dir).glob("entry_*.json"))
    if not paths:
        raise ValueError("empty RFuzz corpus")
    constrained = getattr(artifact, "transducer_hash", None) is not None
    saved_entries = None
    manifest_path = Path(corpus_dir).parent / "corpus_manifest.json"
    if constrained and manifest_path.exists():
        if not manifest_path.is_file():
            raise ValueError("RFuzz saved corpus manifest is invalid")
        manifest = json.loads(manifest_path.read_text())
        if (not isinstance(manifest, dict) or manifest.get("entries") != len(paths)
                or not isinstance(manifest.get("replays"), list)
                or len(manifest["replays"]) != len(paths)):
            raise ValueError("RFuzz saved corpus manifest is invalid")
        saved_entries = {item.get("file"): item for item in manifest["replays"] if isinstance(item, dict)}
        if len(saved_entries) != len(paths) or set(saved_entries) != {path.name for path in paths}:
            raise ValueError("RFuzz saved corpus manifest entries mismatch")
    entries = []
    with RtlSimulator(artifact) as simulator:
        for path in paths:
            # Five JSON characters per byte covers even spaced decimal arrays;
            # reserve a separate bounded budget for upstream lineage/statistics.
            if path.stat().st_size > 5 * artifact.transport.byte_count * 200 + 4 * 1024 * 1024:
                raise ValueError("oversized RFuzz corpus entry")
            document, payload, expected = _corpus_document(
                path, byte_count=artifact.transport.byte_count
            )
            peer_slots = tuple(getattr(artifact, "peer_slots", ()) or ())
            expected_peer_hash = None
            expected_peer_events = None
            if peer_slots:
                if "peer_events" not in document or "peer_event_hash" not in document:
                    raise ValueError(f"peer event evidence missing: {path.name}")
                expected_peer_events = document.get("peer_events")
                if (not isinstance(expected_peer_events, list)
                        or any(not isinstance(item, Mapping) for item in expected_peer_events)):
                    raise ValueError(f"peer event evidence invalid: {path.name}")
                expected_peer_hash = str(document.get("peer_event_hash", ""))
                if expected_peer_hash != peer_event_hash(expected_peer_events):
                    raise ValueError(f"peer event evidence hash mismatch: {path.name}")
            if len(expected) != padded_count or any(expected[count:]):
                raise ValueError("invalid RFuzz coverage padding")
            identity = replay_identity(artifact, payload)
            declared = document.get("replay_identity")
            if saved_entries is not None:
                saved = saved_entries[path.name]
                # A rebuild has its own binary/replay key. All semantic inputs
                # and the actual compiled rule identity must still match.
                for key in _CONTRACT_REPLAY_KEYS:
                    if not saved.get(key) or saved[key] != identity.get(key):
                        raise ValueError(f"RFuzz saved corpus identity mismatch: {key}: {path.name}")
                if saved.get("trace_sha256") != _hash_bytes(bytes(expected)):
                    raise ValueError(f"RFuzz saved corpus trace identity mismatch: {path.name}")
            elif constrained and not isinstance(declared, dict) and _capture_receipts is None:
                raise ValueError(f"RFuzz constrained corpus requires a saved identity manifest: {path.name}")
            if isinstance(declared, dict):
                if constrained:
                    for key in _CONTRACT_REPLAY_KEYS:
                        if not declared.get(key) or declared[key] != identity.get(key):
                            raise ValueError(f"RFuzz replay identity mismatch: {key}: {path.name}")
                for key in ("raw_sha256", "layout_hash", "constraint_hash", "binary_sha256",
                            "physical_controls_sha256", "simulator_inputs_sha256", "replay_key",
                            "transducer_hash", "header_hash", "implementation_hash"):
                    # Inline build-specific bindings belong to the original
                    # sidecar, not the independently rebuilt executable.
                    binding = (saved_entries[path.name]
                               if saved_entries is not None and key in ("binary_sha256", "replay_key")
                               else identity)
                    if key in declared and declared[key] != binding.get(key):
                        raise ValueError(f"RFuzz replay identity mismatch: {path.name}")
            width = artifact.transport.byte_count
            records = tuple(payload[i:i+width] for i in range(0, len(payload), width))
            counters = simulator.run_test(records)
            if peer_slots:
                actual_peer_events = tuple(getattr(simulator, "last_peer_events", ()) or ())
                actual_peer_hash = peer_event_hash(actual_peer_events)
                if actual_peer_hash != expected_peer_hash:
                    raise ValueError(f"peer event mismatch: {path.name}")
            if saved_entries is not None and saved_entries[path.name].get("coverage_sha256") != _hash_bytes(counters):
                raise ValueError(f"RFuzz saved corpus coverage identity mismatch: {path.name}")
            if _capture_receipts is not None and (
                identity["raw_sha256"], _hash_bytes(counters)
            ) not in _capture_receipts:
                raise ValueError(f"RFuzz corpus lacks completed shared-memory exchange: {path.name}")
            if counters != bytes(expected[:count]):
                raise ValueError(f"RFuzz corpus coverage mismatch: {path.name}")
            physical = []
            projector = getattr(artifact, "projector", None)
            if projector is not None and hasattr(projector, "project_ports"):
                physical = [projector.project_ports(artifact.transport.unpack(record)) for record in records]
            replay_entry = {
                "file": path.name,
                "input_sha256": identity["raw_sha256"],
                "cycles": len(records),
                "counters": list(counters),
                "trace_sha256": _hash_bytes(bytes(expected)),
                "physical_ports_sha256": _hash_bytes(canonical_bytes(physical)),
                **identity,
            }
            if peer_slots:
                replay_entry["peer_event_hash"] = str(expected_peer_hash)
                replay_entry["peer_event_count"] = len(expected_peer_events or ())
            entries.append(replay_entry)
    return {
        "status": "passed", "entries": len(entries), "replays": entries,
        "layout_hash": artifact.layout.layout_hash,
        "constraint_hash": entries[0]["constraint_hash"],
        **{key: entries[0][key] for key in ("transducer_hash", "header_hash", "implementation_hash") if key in entries[0]},
        "binary_sha256": entries[0]["binary_sha256"],
        "coverage_kind": artifact.coverage_kind,
        "coverage_transport": "sysv-shared-memory-rfuzz-coverage-buffer",
        **({"peer_event_mode": "raw-abi-derived-v1"} if getattr(artifact, "peer_slots", ()) else {}),
    }
