"""Deterministic planning for fair declarative harness experiments."""

from __future__ import annotations

import hashlib
import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass

from myfuzz.contracts import canonical_bytes, content_hash, validate_contract

from .identity import candidate_semantic_hash
from .jobs import Job, JobKind


class ExperimentPlanError(ValueError):
    """Raised when an experiment cannot satisfy its fairness contract."""


@dataclass(frozen=True, slots=True)
class RfuzzExecution:
    """Stable inputs needed to turn one planned job into RFuzz driver argv."""

    design_config_path: str
    stage: str
    worker_count: int
    candidate_mode: str | None = None
    seed: int | None = None
    fuzz_seconds: int | None = None
    max_cycles: int | None = None
    server_artifact_id: str | None = None
    hard_memory_bytes: int | None = None
    server_input_identity: str | None = None

    def __post_init__(self) -> None:
        path = self.design_config_path
        parts = path.split("/")
        if not path or path.startswith("/") or ".." in parts:
            raise ValueError("design_config_path must be a repository-relative path")
        if self.stage not in {"server", "fuzz"}:
            raise ValueError(f"unsupported RFuzz execution stage: {self.stage}")
        if self.worker_count != 1:
            raise ValueError("RFuzz execution worker_count must be 1")
        if self.candidate_mode is not None and self.candidate_mode not in {
            "flat_direct",
            "candidate_direct",
            "candidate_depaware",
            "candidate_static",
        }:
            raise ValueError("RFuzz execution requires a supported candidate_mode")
        if self.server_artifact_id is not None and re.fullmatch(
            r"sha256:[0-9a-f]{64}", self.server_artifact_id
        ) is None:
            raise ValueError("server_artifact_id must be a canonical SHA-256 content hash")
        if self.server_input_identity is not None and re.fullmatch(
            r"sha256:[0-9a-f]{64}", self.server_input_identity
        ) is None:
            raise ValueError("server_input_identity must be a canonical SHA-256 content hash")
        if self.hard_memory_bytes is not None and (
            isinstance(self.hard_memory_bytes, bool)
            or not isinstance(self.hard_memory_bytes, int)
            or self.hard_memory_bytes <= 0
        ):
            raise ValueError("hard_memory_bytes must be a positive integer")
        if self.stage == "server":
            if any(
                value is not None
                for value in (
                    self.seed,
                    self.fuzz_seconds,
                    self.max_cycles,
                )
            ):
                raise ValueError("server execution cannot declare fuzz parameters")
            return
        if self.candidate_mode is None:
            raise ValueError("fuzz execution requires a supported candidate_mode")
        if isinstance(self.seed, bool) or not isinstance(self.seed, int) or self.seed < 0:
            raise ValueError("fuzz execution seed must be a non-negative integer")
        limits = (self.fuzz_seconds is not None, self.max_cycles is not None)
        if sum(limits) != 1:
            raise ValueError("fuzz execution requires exactly one budget limit")
        for label, value in (
            ("fuzz_seconds", self.fuzz_seconds),
            ("max_cycles", self.max_cycles),
        ):
            if value is not None and (
                isinstance(value, bool) or not isinstance(value, int) or value <= 0
            ):
                raise ValueError(f"{label} must be a positive integer")


@dataclass(frozen=True, slots=True)
class ExperimentBuildJob(Job):
    """One executable RFuzz server-build prerequisite."""

    execution: RfuzzExecution
    target_id: str = ""
    candidate_id: str = ""
    harness: str = ""
    artifact_id: str = ""
    harness_content_hash: str | None = None
    harness_abi_hash: str | None = None
    projection_plan_hash: str | None = None


@dataclass(frozen=True, slots=True)
class ExperimentJob(Job):
    """One stable runnable cell in an experiment matrix."""

    target_id: str
    candidate_id: str
    harness: str
    budget_kind: str
    budget_value: int
    config_path: str
    estimated_rss_bytes: int
    priority: int
    execution: RfuzzExecution
    build_job_id: str = ""
    budget_name: str = ""
    raw_width: int = 0
    instrumented_rtl_hash: str = ""
    coverage_universe: str = ""
    coverage_metadata_hash: str = ""
    harness_content_hash: str | None = None
    harness_abi_hash: str | None = None
    projection_plan_hash: str | None = None
    mutation: tuple[tuple[str, int | bool | str], ...] = ()


@dataclass(frozen=True, slots=True)
class HarnessIdentity:
    """Concrete runtime identity shared by one candidate harness pair."""

    raw_width: int
    instrumented_rtl_hash: str
    coverage_universe: str
    coverage_metadata_hash: str


@dataclass(frozen=True, slots=True)
class CandidatePairIdentity:
    """Auditable identities for one configured candidate harness pair."""

    candidate_id: str
    candidate_harness: str
    direct: HarnessIdentity
    candidate: HarnessIdentity

    @property
    def depaware(self) -> HarnessIdentity:
        """Return the legacy dependency-aware identity when that pair is configured."""
        if self.candidate_harness != "candidate-depaware":
            raise AttributeError("depaware is only available for candidate-depaware plans")
        return self.candidate


@dataclass(frozen=True, slots=True)
class FairnessAudit:
    candidate_pair_has_equal_budget: bool
    candidate_pair_has_equal_seeds: bool
    candidate_pair_has_equal_raw_width: bool
    shared_instrumented_rtl: bool
    shared_coverage_universe: bool
    shared_coverage_metadata: bool = True
    candidate_pair_identities: tuple[CandidatePairIdentity, ...] = ()


@dataclass(frozen=True, slots=True)
class RuntimePolicy:
    """Bounded host-resource policy retained with every experiment plan."""

    build_concurrency: int
    waveforms: bool
    replay_queue_capacity: int
    event_ring_capacity: int
    field_groups_per_batch: int
    soft_memory_bytes: int
    hard_memory_bytes: int
    token_bytes: int
    unknown_rss_bytes: int


@dataclass(frozen=True, slots=True)
class ExperimentPlan:
    jobs: tuple[ExperimentJob, ...]
    build_jobs: tuple[ExperimentBuildJob, ...]
    run_blocks: tuple[tuple[str, ...], ...]
    fairness: FairnessAudit
    runtime_policy: RuntimePolicy
    plan_hash: str

    @property
    def execution_jobs(self) -> tuple[Job, ...]:
        """Return build prerequisites followed by the runnable fuzz matrix."""
        return self.build_jobs + self.jobs


@dataclass(frozen=True, slots=True)
class _Budget:
    name: str
    kind: str
    value: int


@dataclass(frozen=True, slots=True)
class _PlannerConfig:
    target_id: str
    config_path: str
    design_config_path: str
    harness_groups: tuple[str, ...]
    comparison_pair: tuple[str, str]
    candidate_count: int
    seeds: tuple[int, ...]
    budgets: tuple[_Budget, ...]
    mutation: tuple[tuple[str, int | bool | str], ...]
    runtime_policy: RuntimePolicy
    native_input_identity: str | None = None

    @property
    def candidate_harness(self) -> str:
        return self.comparison_pair[1]


@dataclass(frozen=True, slots=True)
class _Candidate:
    candidate_id: str
    candidate_hash: str
    build_cache_key: str
    estimated_rss_bytes: int
    flat_raw_width: int
    candidate_raw_width: int
    flat_instrumented_rtl_hash: str
    candidate_instrumented_rtl_hash: str
    flat_coverage_universe: str
    candidate_coverage_universe: str
    coverage_metadata_hash: str
    harness_semantics: tuple[tuple[str, str | None, str | None, str | None], ...]


_BASE_HARNESS_GROUPS = ("flat-direct", "candidate-direct")
_CANDIDATE_HARNESSES = frozenset(("candidate-depaware", "candidate-static"))
_HARNESS_MODES = {
    "flat-direct": "flat_direct",
    "candidate-direct": "candidate_direct",
    "candidate-depaware": "candidate_depaware",
    "candidate-static": "candidate_static",
}
_BUDGET_KINDS = frozenset(("cycles", "seconds"))
_COVERAGE_MEASURES = frozenset(("percentage", "covered-count", "shared-stable-source-id"))
_MIB_BYTES = 1024 * 1024


def _object(value: object, label: str) -> Mapping[str, object]:
    if not isinstance(value, Mapping):
        raise ExperimentPlanError(f"{label} must be an object")
    return value


def _array(value: object, label: str) -> Sequence[object]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes, bytearray)):
        raise ExperimentPlanError(f"{label} must be an array")
    return value


def _string(value: object, label: str) -> str:
    if not isinstance(value, str) or not value:
        raise ExperimentPlanError(f"{label} must be a non-empty string")
    return value


def _canonical_hash(value: object, label: str) -> str:
    digest = _string(value, label)
    if re.fullmatch(r"sha256:[0-9a-f]{64}", digest) is None:
        raise ExperimentPlanError(f"{label} must be a canonical SHA-256 content hash")
    return digest


def _repository_relative_path(value: object, label: str) -> str:
    path = _string(value, label)
    parts = path.split("/")
    if path.startswith("/") or ".." in parts:
        raise ExperimentPlanError(f"{label} must be a repository-relative path")
    return path


def _positive_int(value: object, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise ExperimentPlanError(f"{label} must be a positive integer")
    return value


def _nonnegative_int(value: object, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ExperimentPlanError(f"{label} must be a non-negative integer")
    return value


def _parse_mutation(value: object) -> tuple[tuple[str, int | bool | str], ...]:
    document = _object(value, "mutation")
    if not document:
        raise ExperimentPlanError("mutation must not be empty")
    result: list[tuple[str, int | bool | str]] = []
    for key, item in sorted(document.items()):
        _string(key, "mutation key")
        if not isinstance(item, (int, bool, str)) or isinstance(item, str) and not item:
            raise ExperimentPlanError(f"mutation.{key} must be a scalar")
        result.append((key, item))
    return tuple(result)


def _parse_budgets(value: object) -> tuple[_Budget, ...]:
    budgets: list[_Budget] = []
    seen: set[str] = set()
    for index, item in enumerate(_array(value, "budgets")):
        record = _object(item, f"budgets[{index}]")
        name = _string(record.get("name"), f"budgets[{index}].name")
        kind = _string(record.get("kind"), f"budgets[{index}].kind")
        budget_value = _positive_int(record.get("value"), f"budgets[{index}].value")
        if name in seen:
            raise ExperimentPlanError("budget names must be unique")
        if kind not in _BUDGET_KINDS:
            raise ExperimentPlanError(f"unsupported budget kind: {kind}")
        seen.add(name)
        budgets.append(_Budget(name, kind, budget_value))
    if not budgets:
        raise ExperimentPlanError("budgets must not be empty")
    return tuple(sorted(budgets, key=lambda budget: (budget.name, budget.kind, budget.value)))


def _validate_coverage(
    value: object,
    harness_groups: tuple[str, ...],
) -> tuple[str, str]:
    coverage = _object(value, "coverage")
    _string(coverage.get("metric"), "coverage.metric")
    scopes = {
        "flat-direct": "flat",
        "candidate-direct": "candidate",
        "candidate-depaware": "candidate",
        "candidate-static": "candidate",
    }
    candidate_harnesses: list[str] = []
    for index, item in enumerate(_array(coverage.get("comparisons"), "coverage.comparisons")):
        comparison = _object(item, f"coverage.comparisons[{index}]")
        left = _string(comparison.get("left_harness"), f"coverage.comparisons[{index}].left_harness")
        right = _string(comparison.get("right_harness"), f"coverage.comparisons[{index}].right_harness")
        measure = _string(comparison.get("measure"), f"coverage.comparisons[{index}].measure")
        if left not in harness_groups or right not in harness_groups:
            raise ExperimentPlanError("coverage comparison references an undeclared harness")
        if measure not in _COVERAGE_MEASURES:
            raise ExperimentPlanError(f"unsupported coverage comparison measure: {measure}")
        if measure == "percentage" and scopes[left] != scopes[right]:
            raise ExperimentPlanError("cannot compare coverage percentages across distinct universes")
        if left == "candidate-direct" and right in _CANDIDATE_HARNESSES:
            candidate_harnesses.append(right)
    if len(candidate_harnesses) != 1:
        raise ExperimentPlanError(
            "coverage must declare exactly one candidate-direct comparison"
        )
    return "candidate-direct", candidate_harnesses[0]


def _validate_reference(value: object) -> None:
    reference = _object(value, "reference")
    expected = {
        "mode": "evaluation-only",
        "allowed_stage": "report",
        "comparison": "shared-stable-source-id",
    }
    if dict(reference) != expected:
        raise ExperimentPlanError("reference must be evaluation-only report metadata")


def _parse_config(config: object) -> _PlannerConfig:
    document = _object(config, "config")
    if document.get("schema_version") != "experiment.v1":
        raise ExperimentPlanError("schema_version must be experiment.v1")

    target = _object(document.get("target"), "target")
    target_id = _string(target.get("target_id"), "target.target_id")
    config_path_value = document.get("config_path", "")
    config_path = "" if config_path_value == "" else _string(config_path_value, "config_path")
    native_input_value = document.get("native_rfuzz_input_identity")
    native_input_identity = (
        None
        if native_input_value is None
        else _canonical_hash(native_input_value, "native_rfuzz_input_identity")
    )
    design_config_path = _repository_relative_path(
        document.get("design_config_path"),
        "design_config_path",
    )
    selection = _object(document.get("candidate_selection"), "candidate_selection")
    candidate_count = _positive_int(selection.get("k"), "candidate_selection.k")

    declared_groups = tuple(
        _string(item, "harness_groups") for item in _array(document.get("harness_groups"), "harness_groups")
    )
    if (
        len(declared_groups) != 3
        or len(set(declared_groups)) != 3
        or not set(_BASE_HARNESS_GROUPS).issubset(declared_groups)
        or len(set(declared_groups) & _CANDIDATE_HARNESSES) != 1
    ):
        raise ExperimentPlanError("harness_groups must declare each supported group once")

    candidate_pair = _object(document.get("candidate_pair"), "candidate_pair")
    seeds = tuple(
        sorted(_nonnegative_int(item, "candidate_pair.seeds") for item in _array(candidate_pair.get("seeds"), "candidate_pair.seeds"))
    )
    if not seeds or len(seeds) != len(set(seeds)):
        raise ExperimentPlanError("candidate_pair.seeds must be non-empty and unique")

    budgets = _parse_budgets(document.get("budgets"))
    mutation = _parse_mutation(document.get("mutation"))
    comparison_pair = _validate_coverage(document.get("coverage"), declared_groups)
    _, candidate_harness = comparison_pair
    if candidate_harness not in declared_groups:
        raise ExperimentPlanError("coverage candidate comparison references an undeclared harness")
    harness_groups = (*_BASE_HARNESS_GROUPS, candidate_harness)

    build_concurrency = _positive_int(document.get("build_concurrency"), "build_concurrency")
    if build_concurrency != 1:
        raise ExperimentPlanError("build_concurrency must be 1")
    waveforms = document.get("waveforms")
    if waveforms is not False:
        raise ExperimentPlanError("waveforms must be false")
    replay_capacity = _positive_int(document.get("replay_queue_capacity"), "replay_queue_capacity")
    event_capacity = _positive_int(document.get("event_ring_capacity"), "event_ring_capacity")
    field_groups = _positive_int(document.get("field_groups_per_batch"), "field_groups_per_batch")
    if replay_capacity > 128 or event_capacity > 4_096 or field_groups > 64:
        raise ExperimentPlanError("runtime queues and field batches exceed bounded limits")

    soft_memory = _positive_int(document.get("soft_memory_bytes"), "soft_memory_bytes")
    hard_memory = _positive_int(document.get("hard_memory_bytes"), "hard_memory_bytes")
    token_bytes = _positive_int(document.get("token_bytes"), "token_bytes")
    if soft_memory >= hard_memory:
        raise ExperimentPlanError("soft_memory_bytes must be less than hard_memory_bytes")
    if token_bytes > soft_memory:
        raise ExperimentPlanError("token_bytes must not exceed soft_memory_bytes")

    reference = document.get("reference")
    if reference is not None:
        _validate_reference(reference)
    runtime_policy = RuntimePolicy(
        build_concurrency=build_concurrency,
        waveforms=waveforms,
        replay_queue_capacity=replay_capacity,
        event_ring_capacity=event_capacity,
        field_groups_per_batch=field_groups,
        soft_memory_bytes=soft_memory,
        hard_memory_bytes=hard_memory,
        token_bytes=token_bytes,
        # No measurement means no evidence for a smaller reservation. Reserving
        # the complete soft allowance admits at most one unknown worker.
        unknown_rss_bytes=soft_memory,
    )
    return _PlannerConfig(
        target_id,
        config_path,
        design_config_path,
        harness_groups,
        comparison_pair,
        candidate_count,
        seeds,
        budgets,
        mutation,
        runtime_policy,
        native_input_identity,
    )


def _harness_record(manifest: Mapping[str, object], harness: str) -> Mapping[str, object]:
    harnesses = _object(manifest.get("harnesses"), "manifest.harnesses")
    value = harnesses.get(harness)
    return value if isinstance(value, Mapping) else {}


def _fallback_raw_width(manifest: Mapping[str, object]) -> int:
    width = 0
    for index, item in enumerate(_array(manifest.get("top_port_abi"), "manifest.top_port_abi")):
        port = _object(item, f"manifest.top_port_abi[{index}]")
        if port.get("direction") in ("input", "inout"):
            width += _positive_int(port.get("width"), f"manifest.top_port_abi[{index}].width")
    if width <= 0:
        raise ExperimentPlanError("candidate manifest has no runnable raw input width")
    return width


def _raw_width(record: Mapping[str, object], fallback: int, label: str) -> int:
    value = record.get("raw_width")
    return fallback if value is None else _positive_int(value, f"{label}.raw_width")


def _universe_from_record(record: Mapping[str, object]) -> str | None:
    for key in ("coverage_universe", "coverage_universe_id", "coverage_universe_hash"):
        value = record.get(key)
        if value is not None:
            return _string(value, f"harness.{key}")
    return None


def _candidate_universe(manifest: Mapping[str, object]) -> str:
    points = _array(manifest.get("coverage_universe"), "manifest.coverage_universe")
    ordered = sorted(points, key=canonical_bytes)
    return content_hash({"coverage_universe": ordered})


def _coverage_metadata_hash(manifest: Mapping[str, object]) -> str:
    computed = _candidate_universe(manifest)
    declared = manifest.get("coverage_metadata_hash")
    if declared is None:
        return computed
    value = _string(declared, "manifest.coverage_metadata_hash")
    if value != computed:
        raise ExperimentPlanError(
            "manifest coverage_metadata_hash does not match coverage_universe"
        )
    return value


def _record_metadata_hash(record: Mapping[str, object], label: str) -> str | None:
    value = record.get("coverage_metadata_hash")
    return None if value is None else _string(value, f"{label}.coverage_metadata_hash")


def _instrumented_rtl(record: Mapping[str, object], fallback: str) -> str:
    for key in ("instrumented_rtl_hash", "top_content_hash"):
        value = record.get(key)
        if value is not None:
            return _string(value, f"harness.{key}")
    return fallback


def _optional_harness_hash(
    record: Mapping[str, object],
    key: str,
    harness: str,
) -> str | None:
    value = record.get(key)
    return None if value is None else _canonical_hash(value, f"harnesses.{harness}.{key}")


def _estimated_rss(manifest: Mapping[str, object], fallback: int) -> int:
    resources = _object(manifest.get("resources"), "manifest.resources")
    value = resources.get("peak_rss_bytes")
    return fallback if value is None else _positive_int(value, "manifest.resources.peak_rss_bytes")


def _parse_candidate(manifest: Mapping[str, object], config: _PlannerConfig) -> _Candidate:
    candidate_id = _string(manifest.get("candidate_id"), "manifest.candidate_id")
    _string(manifest.get("composition_ir_hash"), "manifest.composition_ir_hash")
    build_cache_key = _string(manifest.get("build_cache_key"), "manifest.build_cache_key")
    top = _object(manifest.get("top"), "manifest.top")
    top_hash = _string(top.get("content_hash"), "manifest.top.content_hash")

    direct_record = _harness_record(manifest, "candidate-direct")
    candidate_record = _harness_record(manifest, config.candidate_harness)
    if config.candidate_harness == "candidate-static":
        harnesses = _object(manifest.get("harnesses"), "manifest.harnesses")
        static_record = harnesses.get("candidate-static")
        if not isinstance(static_record, Mapping):
            raise ExperimentPlanError("candidate-static harness record must be an object")
        candidate_record = static_record
        for field in ("content_hash", "abi_hash"):
            _canonical_hash(candidate_record.get(field), f"candidate-static.{field}")
    flat_record = _harness_record(manifest, "flat-direct")
    harness_records = {
        "flat-direct": flat_record,
        "candidate-direct": direct_record,
        config.candidate_harness: candidate_record,
    }
    fallback_width = _fallback_raw_width(manifest)
    direct_width = _raw_width(direct_record, fallback_width, "candidate-direct")
    candidate_width = _raw_width(candidate_record, fallback_width, config.candidate_harness)
    if direct_width != candidate_width:
        raise ExperimentPlanError("candidate pair raw width must be equal")

    direct_rtl = _instrumented_rtl(direct_record, top_hash)
    candidate_rtl = _instrumented_rtl(candidate_record, top_hash)
    if direct_rtl != candidate_rtl:
        raise ExperimentPlanError("candidate pair instrumented RTL must be shared")

    coverage_metadata_hash = _coverage_metadata_hash(manifest)
    direct_universe = _universe_from_record(direct_record) or coverage_metadata_hash
    candidate_universe = _universe_from_record(candidate_record) or coverage_metadata_hash
    if direct_universe != candidate_universe:
        raise ExperimentPlanError("candidate pair coverage universe must be shared")
    direct_metadata = _record_metadata_hash(direct_record, "candidate-direct")
    candidate_metadata = _record_metadata_hash(candidate_record, config.candidate_harness)
    if any(
        value is not None and value != coverage_metadata_hash
        for value in (direct_metadata, candidate_metadata)
    ):
        raise ExperimentPlanError("candidate pair coverage metadata must be shared")

    flat_universe = _universe_from_record(flat_record) or content_hash(
        {"scope": "flat-direct", "target_id": config.target_id}
    )
    if flat_universe == direct_universe:
        raise ExperimentPlanError("flat-direct must use a distinct coverage universe")

    return _Candidate(
        candidate_id=candidate_id,
        candidate_hash=candidate_semantic_hash(manifest),
        build_cache_key=build_cache_key,
        estimated_rss_bytes=_estimated_rss(manifest, config.runtime_policy.unknown_rss_bytes),
        flat_raw_width=_raw_width(flat_record, fallback_width, "flat-direct"),
        candidate_raw_width=direct_width,
        flat_instrumented_rtl_hash=_instrumented_rtl(flat_record, top_hash),
        candidate_instrumented_rtl_hash=direct_rtl,
        flat_coverage_universe=flat_universe,
        candidate_coverage_universe=direct_universe,
        coverage_metadata_hash=coverage_metadata_hash,
        harness_semantics=tuple(
            (
                harness,
                _optional_harness_hash(record, "content_hash", harness),
                _optional_harness_hash(record, "abi_hash", harness),
                _optional_harness_hash(record, "projection_plan_hash", harness),
            )
            for harness, record in harness_records.items()
        ),
    )


def _base_job_document(job: Job) -> dict[str, object]:
    document = {
        "job_id": job.job_id,
        "kind": job.kind.value,
        "gate_name": job.gate_name,
        "owner": job.owner,
        "requested_mib": job.requested_mib,
        "seed": job.seed,
        "candidate_hash": job.candidate_hash,
        "build_cache_key": job.build_cache_key,
        "worker_limit": job.worker_limit,
    }
    if isinstance(job, (ExperimentBuildJob, ExperimentJob)):
        document["execution"] = _execution_document(job.execution)
    if isinstance(job, ExperimentBuildJob):
        document.update({
            "target_id": job.target_id,
            "candidate_id": job.candidate_id,
            "harness": job.harness,
            "artifact_id": job.artifact_id,
            "harness_content_hash": job.harness_content_hash,
            "harness_abi_hash": job.harness_abi_hash,
            "projection_plan_hash": job.projection_plan_hash,
        })
    return document


def _execution_document(execution: RfuzzExecution) -> dict[str, object]:
    return {
        "design_config_path": execution.design_config_path,
        "stage": execution.stage,
        "worker_count": execution.worker_count,
        "candidate_mode": execution.candidate_mode,
        "server_artifact_id": execution.server_artifact_id,
        "server_input_identity": execution.server_input_identity,
        "seed": execution.seed,
        "fuzz_seconds": execution.fuzz_seconds,
        "max_cycles": execution.max_cycles,
        "hard_memory_bytes": execution.hard_memory_bytes,
    }


def _job_document(job: ExperimentJob) -> dict[str, object]:
    document = _base_job_document(job)
    document.update({
        "target_id": job.target_id,
        "candidate_id": job.candidate_id,
        "harness": job.harness,
        "build_job_id": job.build_job_id,
        "budget_name": job.budget_name,
        "budget_kind": job.budget_kind,
        "budget_value": job.budget_value,
        "config_path": job.config_path,
        "estimated_rss_bytes": job.estimated_rss_bytes,
        "priority": job.priority,
        "raw_width": job.raw_width,
        "instrumented_rtl_hash": job.instrumented_rtl_hash,
        "coverage_universe": job.coverage_universe,
        "coverage_metadata_hash": job.coverage_metadata_hash,
        "harness_content_hash": job.harness_content_hash,
        "harness_abi_hash": job.harness_abi_hash,
        "projection_plan_hash": job.projection_plan_hash,
        "mutation": dict(job.mutation),
    })
    return document


def _runtime_policy_document(policy: RuntimePolicy) -> dict[str, object]:
    return {
        "build_concurrency": policy.build_concurrency,
        "waveforms": policy.waveforms,
        "replay_queue_capacity": policy.replay_queue_capacity,
        "event_ring_capacity": policy.event_ring_capacity,
        "field_groups_per_batch": policy.field_groups_per_batch,
        "soft_memory_bytes": policy.soft_memory_bytes,
        "hard_memory_bytes": policy.hard_memory_bytes,
        "token_bytes": policy.token_bytes,
        "unknown_rss_bytes": policy.unknown_rss_bytes,
    }


def _requested_mib(estimated_rss_bytes: int) -> int:
    return (estimated_rss_bytes + _MIB_BYTES - 1) // _MIB_BYTES


def _make_job(
    config: _PlannerConfig,
    candidate: _Candidate,
    harness: str,
    seed: int,
    budget: _Budget,
    priority: int,
    worker_limit: int,
    slot_index: int,
    build_job: ExperimentBuildJob,
) -> ExperimentJob:
    is_flat = harness == "flat-direct"
    raw_width = candidate.flat_raw_width if is_flat else candidate.candidate_raw_width
    rtl_hash = (
        candidate.flat_instrumented_rtl_hash if is_flat else candidate.candidate_instrumented_rtl_hash
    )
    universe = candidate.flat_coverage_universe if is_flat else candidate.candidate_coverage_universe
    harness_content_hash, harness_abi_hash, projection_plan_hash = {
        name: (content, abi, projection)
        for name, content, abi, projection in candidate.harness_semantics
    }[harness]
    requested_mib = _requested_mib(candidate.estimated_rss_bytes)
    gate_name = f"fuzz-slot-{slot_index % worker_limit}"
    execution = RfuzzExecution(
        design_config_path=config.design_config_path,
        stage="fuzz",
        worker_count=1,
        candidate_mode=_HARNESS_MODES[harness],
        server_artifact_id=build_job.artifact_id,
        server_input_identity=config.native_input_identity,
        seed=seed,
        fuzz_seconds=budget.value if budget.kind == "seconds" else None,
        max_cycles=budget.value if budget.kind == "cycles" else None,
        hard_memory_bytes=config.runtime_policy.hard_memory_bytes,
    )
    identity = {
        "target_id": config.target_id,
        "candidate_id": candidate.candidate_id,
        "candidate_hash": candidate.candidate_hash,
        "harness": harness,
        "build_job_id": build_job.job_id,
        "seed": seed,
        "budget_name": budget.name,
        "budget_kind": budget.kind,
        "budget_value": budget.value,
        "build_cache_key": candidate.build_cache_key,
        "config_path": config.config_path,
        "estimated_rss_bytes": candidate.estimated_rss_bytes,
        "priority": priority,
        "kind": JobKind.FUZZ.value,
        "gate_name": gate_name,
        "requested_mib": requested_mib,
        "worker_limit": worker_limit,
        "raw_width": raw_width,
        "instrumented_rtl_hash": rtl_hash,
        "coverage_universe": universe,
        "coverage_metadata_hash": candidate.coverage_metadata_hash,
        "harness_content_hash": harness_content_hash,
        "harness_abi_hash": harness_abi_hash,
        "projection_plan_hash": projection_plan_hash,
        "mutation": dict(config.mutation),
        "execution": _execution_document(execution),
    }
    token = content_hash(identity).removeprefix("sha256:")
    return ExperimentJob(
        job_id=f"fuzz-{token}",
        kind=JobKind.FUZZ,
        gate_name=gate_name,
        owner=f"job-{token}",
        requested_mib=requested_mib,
        seed=seed,
        candidate_hash=candidate.candidate_hash,
        build_cache_key=candidate.build_cache_key,
        worker_limit=worker_limit,
        target_id=config.target_id,
        candidate_id=candidate.candidate_id,
        harness=harness,
        budget_kind=budget.kind,
        budget_value=budget.value,
        config_path=config.config_path,
        estimated_rss_bytes=candidate.estimated_rss_bytes,
        priority=priority,
        execution=execution,
        build_job_id=build_job.job_id,
        budget_name=budget.name,
        raw_width=raw_width,
        instrumented_rtl_hash=rtl_hash,
        coverage_universe=universe,
        coverage_metadata_hash=candidate.coverage_metadata_hash,
        harness_content_hash=harness_content_hash,
        harness_abi_hash=harness_abi_hash,
        projection_plan_hash=projection_plan_hash,
        mutation=config.mutation,
    )


def _make_build_jobs(
    candidates: tuple[_Candidate, ...],
    config: _PlannerConfig,
) -> tuple[ExperimentBuildJob, ...]:
    build_records: dict[tuple[str, str], ExperimentBuildJob] = {}
    for candidate in candidates:
        semantics = {
            harness: (content, abi, projection)
            for harness, content, abi, projection in candidate.harness_semantics
        }
        for harness in config.harness_groups:
            content, abi, projection = semantics[harness]
            artifact_document = {
                "target_id": config.target_id,
                "candidate_id": candidate.candidate_id,
                "candidate_hash": candidate.candidate_hash,
                "build_cache_key": candidate.build_cache_key,
                "harness": harness,
                "candidate_mode": _HARNESS_MODES[harness],
                "harness_content_hash": content,
                "harness_abi_hash": abi,
                "projection_plan_hash": projection,
                "native_rfuzz_input_identity": config.native_input_identity,
            }
            artifact_id = content_hash(artifact_document)
            requested_mib = _requested_mib(candidate.estimated_rss_bytes)
            execution = RfuzzExecution(
                design_config_path=config.design_config_path,
                stage="server",
                worker_count=1,
                candidate_mode=_HARNESS_MODES[harness],
                server_artifact_id=artifact_id,
                hard_memory_bytes=config.runtime_policy.hard_memory_bytes,
                server_input_identity=config.native_input_identity,
            )
            identity = {
                "kind": JobKind.BUILD.value,
                "gate_name": "build",
                "requested_mib": requested_mib,
                "seed": 0,
                "candidate_hash": candidate.candidate_hash,
                "build_cache_key": candidate.build_cache_key,
                "worker_limit": 1,
                "artifact_id": artifact_id,
                "execution": _execution_document(execution),
            }
            token = content_hash(identity).removeprefix("sha256:")
            job = ExperimentBuildJob(
                job_id=f"build-{token}",
                kind=JobKind.BUILD,
                gate_name="build",
                owner=f"job-{token}",
                requested_mib=requested_mib,
                seed=0,
                candidate_hash=candidate.candidate_hash,
                build_cache_key=candidate.build_cache_key,
                worker_limit=1,
                execution=execution,
                target_id=config.target_id,
                candidate_id=candidate.candidate_id,
                harness=harness,
                artifact_id=artifact_id,
                harness_content_hash=content,
                harness_abi_hash=abi,
                projection_plan_hash=projection,
            )
            key = (candidate.candidate_id, harness)
            previous = build_records.get(key)
            if previous is not None and previous.artifact_id != artifact_id:
                raise ExperimentPlanError(
                    "duplicate candidate harness has conflicting artifact identities"
                )
            build_records[key] = job
    return tuple(build_records[key] for key in sorted(build_records))


def resolve_build_prerequisite(
    plan: ExperimentPlan,
    fuzz_job: ExperimentJob,
) -> ExperimentBuildJob:
    """Resolve and validate the single server build required by a fuzz job."""
    if fuzz_job.build_job_id:
        matches = tuple(job for job in plan.build_jobs if job.job_id == fuzz_job.build_job_id)
    else:
        matches = tuple(
            job
            for job in plan.build_jobs
            if job.candidate_hash == fuzz_job.candidate_hash
            and job.build_cache_key == fuzz_job.build_cache_key
            and (not job.harness or job.harness == fuzz_job.harness)
        )
    if len(matches) != 1:
        raise ExperimentPlanError("fuzz build prerequisite must resolve exactly once")
    build = matches[0]
    for field in ("candidate_hash", "build_cache_key"):
        if getattr(build, field) != getattr(fuzz_job, field):
            raise ExperimentPlanError(f"fuzz build prerequisite {field} does not match")
    for field in ("candidate_id", "target_id"):
        if getattr(build, field) and getattr(build, field) != getattr(fuzz_job, field):
            raise ExperimentPlanError(f"fuzz build prerequisite {field} does not match")
    if build.harness and build.harness != fuzz_job.harness:
        raise ExperimentPlanError("fuzz build prerequisite harness does not match")
    if build.harness:
        expected_mode = _HARNESS_MODES.get(build.harness)
        if (
            expected_mode is None
            or build.execution.candidate_mode != expected_mode
            or fuzz_job.execution.candidate_mode != expected_mode
        ):
            raise ExperimentPlanError("fuzz build prerequisite candidate mode does not match")
    for field in ("harness_content_hash", "harness_abi_hash", "projection_plan_hash"):
        if getattr(build, field) != getattr(fuzz_job, field):
            raise ExperimentPlanError(f"fuzz build prerequisite {field} does not match")
    if build.artifact_id and build.execution.server_artifact_id != build.artifact_id:
        raise ExperimentPlanError(
            "fuzz build prerequisite build execution server artifact ID does not match"
        )
    if build.artifact_id != (fuzz_job.execution.server_artifact_id or ""):
        raise ExperimentPlanError("fuzz execution server artifact ID does not match")
    return build


def _harness_identity(jobs: tuple[ExperimentJob, ...]) -> HarnessIdentity:
    identities = {
        HarnessIdentity(
            raw_width=job.raw_width,
            instrumented_rtl_hash=job.instrumented_rtl_hash,
            coverage_universe=job.coverage_universe,
            coverage_metadata_hash=job.coverage_metadata_hash,
        )
        for job in jobs
    }
    if len(identities) != 1:
        raise ExperimentPlanError("each candidate harness must have one stable identity")
    return next(iter(identities))


def _audit_fairness(
    jobs: tuple[ExperimentJob, ...],
    comparison_pair: tuple[str, str],
) -> FairnessAudit:
    direct_harness, candidate_harness = comparison_pair
    candidate_ids = sorted({job.candidate_id for job in jobs})
    equal_budget = True
    equal_seeds = True
    equal_width = True
    shared_rtl = True
    shared_universe = True
    shared_metadata = True
    identities: list[CandidatePairIdentity] = []
    for candidate_id in candidate_ids:
        direct = tuple(
            job
            for job in jobs
            if job.candidate_id == candidate_id and job.harness == direct_harness
        )
        candidate = tuple(
            job
            for job in jobs
            if job.candidate_id == candidate_id and job.harness == candidate_harness
        )
        equal_budget &= bool(direct) and bool(candidate) and {
            (job.seed, job.budget_name, job.budget_kind, job.budget_value) for job in direct
        } == {(job.seed, job.budget_name, job.budget_kind, job.budget_value) for job in candidate}
        equal_seeds &= {job.seed for job in direct} == {job.seed for job in candidate}
        equal_width &= {job.raw_width for job in direct} == {job.raw_width for job in candidate}
        shared_rtl &= {job.instrumented_rtl_hash for job in direct} == {
            job.instrumented_rtl_hash for job in candidate
        }
        shared_universe &= {job.coverage_universe for job in direct} == {
            job.coverage_universe for job in candidate
        }
        shared_metadata &= {job.coverage_metadata_hash for job in direct} == {
            job.coverage_metadata_hash for job in candidate
        }
        identities.append(
            CandidatePairIdentity(
                candidate_id=candidate_id,
                candidate_harness=candidate_harness,
                direct=_harness_identity(direct),
                candidate=_harness_identity(candidate),
            )
        )
    return FairnessAudit(
        candidate_pair_has_equal_budget=equal_budget,
        candidate_pair_has_equal_seeds=equal_seeds,
        candidate_pair_has_equal_raw_width=equal_width,
        shared_instrumented_rtl=shared_rtl,
        shared_coverage_universe=shared_universe,
        shared_coverage_metadata=shared_metadata,
        candidate_pair_identities=tuple(identities),
    )


def _require_fairness(audit: FairnessAudit) -> None:
    checks = (
        (audit.candidate_pair_has_equal_seeds, "candidate pair seeds must be equal"),
        (audit.candidate_pair_has_equal_budget, "candidate pair budget must be equal"),
        (audit.candidate_pair_has_equal_raw_width, "candidate pair raw width must be equal"),
        (audit.shared_instrumented_rtl, "candidate pair instrumented RTL must be shared"),
        (audit.shared_coverage_universe, "candidate pair coverage universe must be shared"),
        (audit.shared_coverage_metadata, "candidate pair coverage metadata must be shared"),
    )
    for passed, message in checks:
        if not passed:
            raise ExperimentPlanError(message)


def validate_candidate_pair_fairness(
    jobs: tuple[ExperimentJob, ...],
    comparison_pair: tuple[str, str],
) -> FairnessAudit:
    """Recompute and require the frozen candidate-pair fairness contract."""
    audit = _audit_fairness(jobs, comparison_pair)
    _require_fairness(audit)
    direct_harness, candidate_harness = comparison_pair
    for candidate_id in sorted({job.candidate_id for job in jobs}):
        mutations_by_cell = {
            harness: {
                (
                    job.seed,
                    job.budget_name,
                    job.budget_kind,
                    job.budget_value,
                    job.mutation,
                )
                for job in jobs
                if job.candidate_id == candidate_id and job.harness == harness
            }
            for harness in comparison_pair
        }
        if mutations_by_cell[direct_harness] != mutations_by_cell[candidate_harness]:
            raise ExperimentPlanError("candidate pair mutation must be equal")
    return audit


def _run_blocks(
    jobs: tuple[ExperimentJob, ...],
    config: _PlannerConfig,
    candidates: tuple[_Candidate, ...],
) -> tuple[tuple[str, ...], ...]:
    by_key = {
        (job.candidate_id, job.budget_name, job.seed, job.harness): job.job_id
        for job in jobs
    }
    blocks: list[tuple[str, ...]] = []
    for candidate in candidates:
        for budget in config.budgets:
            for seed in config.seeds:
                digest = hashlib.sha256(
                    canonical_bytes({"seed": seed, "candidate_id": candidate.candidate_id})
                ).digest()
                candidate_pair = config.comparison_pair
                pair = candidate_pair if digest[0] & 1 == 0 else tuple(reversed(candidate_pair))
                blocks.append(
                    (
                        by_key[(candidate.candidate_id, budget.name, seed, "flat-direct")],
                        *(by_key[(candidate.candidate_id, budget.name, seed, harness)] for harness in pair),
                    )
                )
    return tuple(blocks)


def plan_experiment(config: object, candidate_manifests: Sequence[object]) -> ExperimentPlan:
    """Create a stable, fair run matrix from declarative configuration data."""
    validated: list[Mapping[str, object]] = []
    for manifest in candidate_manifests:
        validate_contract(manifest, "candidate_manifest.v1")
        validated.append(_object(manifest, "candidate manifest"))
    if not validated:
        raise ExperimentPlanError("candidate_manifests must not be empty")

    parsed_config = _parse_config(config)
    candidates = tuple(sorted((_parse_candidate(item, parsed_config) for item in validated), key=lambda item: item.candidate_id))
    if len({item.candidate_id for item in candidates}) != len(candidates):
        raise ExperimentPlanError("candidate IDs must be unique")
    selected = candidates[: parsed_config.candidate_count]
    if any(
        candidate.estimated_rss_bytes > parsed_config.runtime_policy.soft_memory_bytes
        for candidate in selected
    ):
        raise ExperimentPlanError("measured peak_rss_bytes cannot fit soft memory policy")
    build_jobs = _make_build_jobs(selected, parsed_config)
    builds_by_candidate_harness = {
        (job.candidate_id, job.harness): job for job in build_jobs
    }
    largest_rss_bytes = max(candidate.estimated_rss_bytes for candidate in selected)
    worker_limit = max(1, parsed_config.runtime_policy.soft_memory_bytes // largest_rss_bytes)

    jobs: list[ExperimentJob] = []
    for candidate in selected:
        for budget_index, budget in enumerate(parsed_config.budgets):
            priority = len(parsed_config.budgets) - budget_index
            for seed in parsed_config.seeds:
                for harness in parsed_config.harness_groups:
                    jobs.append(
                        _make_job(
                            parsed_config,
                            candidate,
                            harness,
                            seed,
                            budget,
                            priority,
                            worker_limit,
                            len(jobs),
                            builds_by_candidate_harness[(candidate.candidate_id, harness)],
                        )
                    )
    frozen_jobs = tuple(jobs)
    prerequisite_plan = ExperimentPlan(
        jobs=frozen_jobs,
        build_jobs=build_jobs,
        run_blocks=(),
        fairness=FairnessAudit(False, False, False, False, False),
        runtime_policy=parsed_config.runtime_policy,
        plan_hash="",
    )
    for fuzz_job in frozen_jobs:
        resolve_build_prerequisite(prerequisite_plan, fuzz_job)
    fairness = validate_candidate_pair_fairness(
        frozen_jobs,
        parsed_config.comparison_pair,
    )
    run_blocks = _run_blocks(frozen_jobs, parsed_config, selected)
    plan_document = {
        "build_jobs": [_base_job_document(job) for job in build_jobs],
        "jobs": [_job_document(job) for job in frozen_jobs],
        "run_blocks": [list(block) for block in run_blocks],
        "fairness": {
            "candidate_pair_has_equal_budget": fairness.candidate_pair_has_equal_budget,
            "candidate_pair_has_equal_seeds": fairness.candidate_pair_has_equal_seeds,
            "candidate_pair_has_equal_raw_width": fairness.candidate_pair_has_equal_raw_width,
            "shared_instrumented_rtl": fairness.shared_instrumented_rtl,
            "shared_coverage_universe": fairness.shared_coverage_universe,
            "shared_coverage_metadata": fairness.shared_coverage_metadata,
            "candidate_pair_identities": [
                {
                    "candidate_id": identity.candidate_id,
                    "candidate_harness": identity.candidate_harness,
                    "direct": {
                        "raw_width": identity.direct.raw_width,
                        "instrumented_rtl_hash": identity.direct.instrumented_rtl_hash,
                        "coverage_universe": identity.direct.coverage_universe,
                        "coverage_metadata_hash": identity.direct.coverage_metadata_hash,
                    },
                    "candidate": {
                        "raw_width": identity.candidate.raw_width,
                        "instrumented_rtl_hash": identity.candidate.instrumented_rtl_hash,
                        "coverage_universe": identity.candidate.coverage_universe,
                        "coverage_metadata_hash": identity.candidate.coverage_metadata_hash,
                    },
                }
                for identity in fairness.candidate_pair_identities
            ],
        },
        "runtime_policy": _runtime_policy_document(parsed_config.runtime_policy),
    }
    return ExperimentPlan(
        jobs=frozen_jobs,
        build_jobs=build_jobs,
        run_blocks=run_blocks,
        fairness=fairness,
        runtime_policy=parsed_config.runtime_policy,
        plan_hash=content_hash(plan_document),
    )
