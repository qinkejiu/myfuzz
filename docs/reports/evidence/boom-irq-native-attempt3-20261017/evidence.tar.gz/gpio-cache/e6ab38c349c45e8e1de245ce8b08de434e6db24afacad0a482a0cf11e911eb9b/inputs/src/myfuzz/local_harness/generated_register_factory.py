"""Create register-observation sessions and input ownership from admitted artifacts."""
from __future__ import annotations

from collections.abc import Mapping

from myfuzz.scenario.ownership import InputField, InputOwner, compile_ownership
from myfuzz.scenario.runner import Binding

from .ahb_lite_register_session import GeneratedAhbLiteRegisterSession
from .apb3_register_session import GeneratedApb3RegisterSession
from .axi4lite_register_template import (
    register_observe_policy as axi4lite_register_policy)
from .axi4lite_register_session import GeneratedAxi4LiteRegisterSession
from .axi4lite_uart_peer_session import GeneratedAxi4LiteUartPeerSession
from .request import LocalHarnessRequestV2
from .tlul_register_session import GeneratedTlulRegisterSession
from .tlul_session_factory import create_generated_tlul_session
from .wishbone_register_session import GeneratedWishboneRegisterSession


_KINDS = frozenset(('tlul_register_observe', 'apb3_register_observe',
                    'wishbone_register_observe', 'axi4lite_register_observe', 'ahb_lite_register_observe'))


def _document(artifact):
    document = getattr(artifact, 'runtime_document', None)
    plan = getattr(artifact, 'plan', None)
    if (not isinstance(document, dict) or document.get('kind') not in _KINDS
            or document.get('driver_status') != 'generated' or plan is None
            or not isinstance(plan.request, LocalHarnessRequestV2)):
        raise ValueError('generated v2 register artifact required')
    return document


def create_generated_register_session(artifact, *, base_dir, cache_dir,
                                      setup_writes=(), probe_offsets=()):
    """Select the local register service by artifact kind, never component name."""
    kind = _document(artifact)['kind']
    if kind == 'tlul_register_observe':
        selected = create_generated_tlul_session(artifact, base_dir=base_dir,
                                                 cache_dir=cache_dir)
        if not setup_writes and not probe_offsets:
            return selected
        if type(selected) is not GeneratedTlulRegisterSession:
            raise ValueError('serial peer setup comes from artifact tuning')
        return GeneratedTlulRegisterSession(artifact, base_dir=base_dir,
            cache_dir=cache_dir, setup_writes=setup_writes,
            probe_offsets=probe_offsets)
    if kind == 'axi4lite_register_observe':
        return _create_axi4lite_session(artifact, base_dir=base_dir,
                                        cache_dir=cache_dir,
                                        setup_writes=setup_writes,
                                        probe_offsets=probe_offsets)
    if kind == 'ahb_lite_register_observe':
        return GeneratedAhbLiteRegisterSession(artifact, base_dir=base_dir, cache_dir=cache_dir,
            setup_writes=setup_writes, probe_offsets=probe_offsets)
    cls = (GeneratedApb3RegisterSession if kind == 'apb3_register_observe'
           else GeneratedWishboneRegisterSession)
    return cls(artifact, base_dir=base_dir, cache_dir=cache_dir,
               setup_writes=setup_writes, probe_offsets=probe_offsets)


def _create_axi4lite_session(artifact, *, base_dir, cache_dir,
                             setup_writes=(), probe_offsets=()):
    document = _document(artifact)
    plan = artifact.plan
    # Re-derive the peer from the plan: an artifact whose recorded peer differs
    # from what its own tuning declares must not be executable.
    expected = axi4lite_register_policy(plan)[3]
    if document.get('serial_peer') != expected:
        raise ValueError('AXI4-Lite serial peer tuning differs from artifact')
    if expected is None:
        return GeneratedAxi4LiteRegisterSession(
            artifact, base_dir=base_dir, cache_dir=cache_dir,
            setup_writes=setup_writes, probe_offsets=probe_offsets)
    if setup_writes or probe_offsets:
        raise ValueError('serial peer setup comes from artifact tuning')
    if expected['format'] != '8N1':
        raise ValueError('unknown generated AXI4-Lite serial peer format')
    writes = tuple(tuple(row) for row in expected['startup_writes'])
    return GeneratedAxi4LiteUartPeerSession(
        artifact, base_dir=base_dir, cache_dir=cache_dir,
        rx_port=expected['rx_port'], tx_port=expected['tx_port'],
        source_id=expected['source_id'],
        clocks_per_bit=expected['clocks_per_bit'],
        idle_bits=expected['idle_bits'], setup_writes=writes)


def compile_generated_register_ownership(artifacts: Mapping[str, object]):
    """Compile the physical input owners of independent register harnesses.

    Serial peers own an abstract frame source rather than a physical pin, so
    callers must use the peer's scenario input contract for those artifacts.
    """
    if not isinstance(artifacts, Mapping) or not artifacts:
        raise ValueError('at least one generated register artifact required')
    fields = []
    owners = []
    for component_id, artifact in artifacts.items():
        if type(component_id) is not str or not component_id:
            raise ValueError('component id must be a nonempty string')
        document = _document(artifact)
        if document.get('serial_peer') is not None:
            raise ValueError('serial peer requires abstract frame source ownership')
        names = set()
        for key, kind, producer in (
                ('fixed_physical_inputs', 'fixed', 'profile_constant'),
                ('dynamic_physical_inputs', 'source', 'source_id'),
                ('bound_physical_inputs', 'bound', 'producer_ref')):
            rows = document.get(key)
            if not isinstance(rows, list):
                raise ValueError('generated register input ownership is missing')
            for row in rows:
                if not isinstance(row, dict):
                    raise ValueError('invalid generated register input ownership')
                name = row.get('input_name') or (
                    str(row.get('endpoint_id')) + '.' + str(row.get('role')))
                width = row.get('width')
                if (name in names or type(width) is not int or not 1 <= width <= 64):
                    raise ValueError('overlapping or invalid generated register input')
                names.add(name)
                reference = producer if kind == 'fixed' else row.get(producer)
                if type(reference) is not str or not reference:
                    raise ValueError('generated register input lacks owner identity')
                fields.append(InputField(component_id, name, width))
                owners.append(InputOwner(component_id, name, 0, width, kind,
                                         reference))
    return compile_ownership(tuple(fields), tuple(owners))


def compile_generated_register_bindings(artifacts: Mapping[str, object]):
    """Resolve declared Bound Inputs to whole real physical RTL outputs."""
    if not isinstance(artifacts, Mapping) or not artifacts:
        raise ValueError('at least one generated register artifact required')
    documents = {component: _document(artifact)
                 for component, artifact in artifacts.items()}
    if any(type(component) is not str or not component for component in documents):
        raise ValueError('component id must be a nonempty string')
    bindings = []
    for target_component, document in documents.items():
        for row in document['bound_physical_inputs']:
            producer_ref = row['producer_ref']
            if type(producer_ref) is not str or producer_ref.count('.') != 1:
                raise ValueError('bound input producer must name one component output')
            source_component, source_port = producer_ref.split('.')
            source = documents.get(source_component)
            if source is None or source_component == target_component:
                raise ValueError('bound input lacks distinct generated producer')
            outputs = [port for port in source['physical_exports']
                       if port['physical_port'] == source_port
                       and port['direction'] == 'output']
            if (len(outputs) != 1 or type(row['width']) is not int or
                    outputs[0]['width'] != row['width']):
                raise ValueError('bound input lacks exact real output width')
            bindings.append(Binding(source_component, source_port,
                                    target_component, row['input_name'], row['width']))
    return tuple(bindings)
