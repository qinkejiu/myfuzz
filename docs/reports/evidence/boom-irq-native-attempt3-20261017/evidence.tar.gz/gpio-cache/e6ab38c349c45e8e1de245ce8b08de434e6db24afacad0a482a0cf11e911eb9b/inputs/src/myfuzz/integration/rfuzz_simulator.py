"""Persistent layout-to-Icarus boundary with sampled output-bit event counters.

Counters count asserted observations after each driven cycle (saturating at
255). They are deliberately not advertised as RTL branch or toggle coverage.
"""
from dataclasses import asdict, dataclass, replace
from collections.abc import Mapping, Sequence
import hashlib
import json
import math
import os
from pathlib import Path
import selectors
import signal
import shutil
import subprocess
import sys
import time

from myfuzz.contracts import canonical_bytes, content_hash
from myfuzz.composition.contract_transducer import ContractRuntime, ContractTransducerPlan
from myfuzz.composition.cycle_input import CycleInputLayout, TestHeader, TEST_HEADER_SCHEMA_VERSION
from myfuzz.composition.auto import _generic_with_reset_contract, _generic_endpoint_reset_contract, _generic_source_evidence_hash
from myfuzz.composition.input_layout import InputLayout, input_layout_document
from myfuzz.composition.interface_description import interface_description_document
from myfuzz.composition.protocol_composer import (
    _generic_routes, _generic_port_records, _generic_include_paths,
    _generic_define_options, _validate_generic_plan_freshness, write_generic_composition,
    _validate_processor_transducer,
)
from myfuzz.composition.rfuzz_transport import build_rfuzz_transport, RfuzzInputTransport
from myfuzz.composition.runtime_projection import RuntimeProjector
from myfuzz.composition.soc_peer_replay import (
    PeerRawReplayError,
    decode_peer_raw_events,
)
from .rtl_execution_monitor import (
    validate_monitor, monitor_rtl, monitor_output, parse_metrics, validate_execution,
)
from .soc_coverage import (
    FIRST_SEEN_EVIDENCE,
    FIRST_SEEN_EVENT,
    FIRST_SEEN_SCHEMA,
    MAX_FIRST_SEEN_ENTRIES,
)
from .campaign import CampaignOptions, run_supervised_command, read_process_group_rss_bytes

MAX_CYCLES = 65536
MAX_IO_BYTES = 8 * 1024 * 1024
MAX_DIAGNOSTIC_BYTES = 256 * 1024
MAX_DIAGNOSTIC_LINES = 1024
MAX_DIAGNOSTIC_LINE_BYTES = 4096
MAX_PROJECTION_UNIQUE = 65536
SIMULATOR_PROTOCOL_VERSION = 2
MAX_REQUEST_ID = (1 << 64) - 1
RSS_POLL_SECONDS = 0.1
#: A newly lit point is written out immediately the first time, then at most
#: once per interval, so a long campaign does not rewrite the ledger per test
#: while a killed process still leaves the sightings it already observed.
FIRST_SEEN_FLUSH_SECONDS = 5.0


def real_soc_opt_in(environment: Mapping[str, str] | None = None) -> bool:
    """Return whether the opt-in real-SoC acceptance path is requested."""
    values = os.environ if environment is None else environment
    return values.get("MYFUZZ_SOC_REAL", "") == "1"


def probe_soc_dependencies(root: Path, *, source_paths: Sequence[str] = (),
                           simulator: str = "verilator", require_real: bool | None = None) -> dict:
    """Check real CPU/IP prerequisites without silently changing test mode.

    By default the probe is observational and returns a machine-readable
    report.  When ``MYFUZZ_SOC_REAL=1`` (or ``require_real=True``) is set, a
    missing source/tool raises instead of becoming a skip; this is the boundary
    used by formal acceptance tests.
    """
    root = Path(root).resolve()
    if simulator not in {"verilator", "icarus"}:
        raise ValueError("unsupported SoC simulator")
    if require_real is None:
        require_real = real_soc_opt_in()
    if type(require_real) is not bool:
        raise ValueError("require_real must be boolean")
    paths = tuple(source_paths) or (
        "third_party/rfuzz/upstream/ibex/rtl/ibex_top.sv",
        "third_party/soc-pulp-apb-gpio/rtl/apb_gpio.sv",
        "third_party/soc-pulp-apb-spi/apb_spi_master.sv",
        "configs/soc/sources.lock.json",
    )
    missing: list[str] = []
    checked: list[str] = []
    for value in paths:
        if not isinstance(value, str) or not value or value.startswith("/"):
            raise ValueError("SoC dependency paths must be nonempty relative strings")
        parts = value.split("/")
        if any(part in {"", ".", ".."} for part in parts):
            raise ValueError("SoC dependency path escapes the repository")
        checked.append(value)
        if not (root / value).is_file():
            missing.append(value)
    tool = shutil.which(simulator)
    if tool is None:
        missing.append(f"tool:{simulator}")
    report = {
        "schema_version": "soc_dependency_probe.v1",
        "root": str(root),
        "simulator": simulator,
        "simulator_path": tool,
        "opt_in": bool(require_real),
        "checked": checked,
        "missing": missing,
        "ready": not missing,
        "status": "ready" if not missing else "missing",
        "policy": "missing dependencies fail when real acceptance is opt-in; otherwise report only",
    }
    if require_real and missing:
        raise RuntimeError("real SoC dependencies missing: " + ", ".join(missing))
    return report


@dataclass(frozen=True)
class SimulatorArtifact:
    layout: InputLayout | CycleInputLayout
    transport: RfuzzInputTransport
    executable: Path
    coverage_ports: tuple[tuple[str, int], ...]
    projector: "RuntimeProjector | CycleIdentityProjector"
    coverage_kind: str = "sampled-output-bit-events-u8-saturating"
    control_defaults: Mapping[str, object] = None
    randomized_controls: tuple[str, ...] = ()
    simulator_args: tuple[str, ...] = ()
    simulator: str = "icarus"
    isolate_tests: bool = False
    execution_monitor: dict | None = None
    transducer_hash: str | None = None
    header_hash: str | None = None
    test_header: TestHeader | None = None
    implementation_hash: str | None = None
    #: Profile peer slot contracts with raw offsets.  Empty for legacy cells;
    #: populated profile artifacts use it to publish replayable event evidence.
    peer_slots: tuple[Mapping[str, object], ...] = ()
    #: Where the per-test counter readback records each point's first sighting.
    #: ``None`` (every non-instrumented artifact) writes no ledger at all, so
    #: other simulator users keep their exact behaviour.
    coverage_first_seen_ledger: Path | None = None


def checker_feedback_observations(ports: Sequence[Mapping[str, object]],
                                  *, width: int = 50) -> tuple[tuple[str, int], ...]:
    """Map checker output bits to sampled counters, distinct from RTL branches.

    Evaluation and sticky failure are two independent output buses. Callers
    append these records after their source-instrumented branch observations.
    """
    by_name = {str(item.get("name")): item for item in ports}
    for name in ("checker_eval_o", "checker_fail_o"):
        port = by_name.get(name)
        if (port is None or port.get("direction") != "output"
                or type(port.get("width")) is not int or port["width"] != width):
            raise ValueError(f"checker-bus-width:{name}")
    return tuple((name, bit) for name in ("checker_eval_o", "checker_fail_o")
                 for bit in range(width))


class CycleIdentityProjector:
    """Keep backend entropy unchanged; expose only proven external bindings."""
    instruction_mode = "stateful-contract-transducer-rtl"

    def __init__(self, plan, external_fields):
        self.layout = plan.cycle_layout
        self.constraint_hash = plan.contract_hash
        self.external_fields = tuple(external_fields)

    def project(self, raw):
        if type(raw) is not int or not 0 <= raw < 1 << self.layout.raw_width:
            raise ValueError("raw sample outside cycle layout")
        return raw

    def project_ports(self, raw):
        self.project(raw)
        values = {}
        for field in self.external_fields:
            value = (raw >> field.raw_lo) & ((1 << field.width) - 1)
            values[field.port] = values.get(field.port, 0) | (value << (field.port_raw_lo or 0))
        return values


_CONTROL_ROLE_ALIASES = {
    "boot_address": frozenset(("boot_address", "boot_addr", "reset_vector")),
    "hart_id": frozenset(("hart_id", "hartid")),
    "debug_request": frozenset(("debug_request", "debug_req", "debug")),
    "interrupt": frozenset(("interrupt", "interrupt_request", "irq", "software_interrupt",
                             "timer_interrupt", "external_interrupt", "fast_interrupt",
                             "nonmaskable_interrupt", "non_maskable_interrupt")),
}
_CONTROL_DEFAULTS = {role: 0 for role in _CONTROL_ROLE_ALIASES}


def _canonical_control_role(role, explicit=()):
    for canonical, aliases in _CONTROL_ROLE_ALIASES.items():
        if role in aliases:
            return canonical
    return role if role in explicit else None


def _normalize_control_roles(value):
    if value is None:
        return ()
    if isinstance(value, (str, bytes)) or not isinstance(value, Sequence):
        raise ValueError("randomized controls must be a sequence")
    result = []
    for role in value:
        if not isinstance(role, str):
            raise ValueError("randomized control role must be a string")
        canonical = _canonical_control_role(role)
        if canonical is None:
            raise ValueError(f"unsupported randomized control: {role}")
        if canonical in result:
            raise ValueError("duplicate randomized control")
        result.append(canonical)
    return tuple(sorted(result))


def _control_defaults(value):
    if value is None:
        return dict(_CONTROL_DEFAULTS)
    if not isinstance(value, Mapping):
        raise ValueError("control defaults must be a mapping")
    result = dict(_CONTROL_DEFAULTS)
    for role, default in value.items():
        if not isinstance(role, str):
            raise ValueError("control default role must be a string")
        canonical = _canonical_control_role(role) or role
        if not role or not role.isidentifier():
            raise ValueError(f"invalid control default: {role}")
        if type(default) is not int or default < 0:
            raise ValueError("control default must be a nonnegative integer")
        result[canonical] = default
    return result


def _runtime_control_bindings(plan, ports, layout, randomized_controls, defaults):
    source_fields = tuple(getattr(getattr(plan, "layout", None), "fields", ()))
    included = {field.field_id for field in layout.fields}
    bindings = []
    present = set()
    for field in source_fields:
        canonical = _canonical_control_role(field.role, defaults)
        if canonical is None or field.field_id in included:
            continue
        present.add(canonical)
        if field.direction not in ("input", "inout") or field.port not in ports:
            raise ValueError("invalid runtime control binding")
        if ports[field.port]["direction"] != "input":
            raise ValueError("runtime control must drive an input port")
        value = defaults[canonical]
        field_mask = (1 << field.width) - 1
        if value > field_mask:
            raise ValueError(f"runtime control default exceeds {field.field_id} width")
        if field.member_path:
            if any(item is None for item in (field.port_raw_lo, field.port_raw_hi, field.port_width)):
                raise ValueError("incomplete packed runtime control")
        elif ports[field.port]["width"] != field.width:
            raise ValueError("scalar runtime control width mismatch")
        bindings.append((field, value))
    for role in randomized_controls:
        if not any(_canonical_control_role(field.role) == role and
                   field.field_id in included for field in source_fields):
            raise ValueError(f"randomized control lacks interface opt-in: {role}")
    document = {
        "roles": tuple(sorted(present)),
        "values": {role: defaults[role] for role in sorted(present)},
        "policy": "explicit-opt-in; otherwise constant",
        "bindings": [{"field_id": f.field_id, "port": f.port, "width": f.width,
                      "raw_lo": f.port_raw_lo, "raw_hi": f.port_raw_hi, "value": v}
                     for f, v in bindings],
    }
    return tuple(bindings), document


def _runtime_boundary(plan, base_dir, *, randomized_controls=(), control_defaults=(), contract_transducer=None):
    randomized_controls = _normalize_control_roles(randomized_controls)
    execution = getattr(plan, "processor_execution", None)
    if execution is None:
        routes = _generic_routes(plan)
        internal = frozenset(f["source_port"] for r in routes for f in r["fields"])
        bound = {r["source_endpoint_id"] for r in routes}
    else:
        processor_routes = getattr(execution, "routes", None)
        if not isinstance(processor_routes, tuple) or not processor_routes:
            raise ValueError("invalid processor runtime routes")
        internal = frozenset(
            str(physical.get("port", physical.get("container_port")))
            for route in processor_routes
            for connection in route.field_connections
            for physical in (connection["physical"],)
        )
        if "None" in internal:
            raise ValueError("invalid processor runtime physical port")
        bound = {route.endpoint_id for route in processor_routes}
    ports = {r["source_port"]: r for r in _generic_port_records(plan, internal_ports=internal)}
    clocks, resets, contracts = set(), set(), set()
    source_root = base_dir / plan.interface_description.source.source_root
    modules = {e["endpoint_id"]: e["module"] for e in plan.annotations["endpoints"]}
    if execution is not None:
        from myfuzz.composition.protocol_composer import _processor_controls
        processor_clock, processor_reset, semantics = _processor_controls(plan)
        clocks.add(processor_clock)
        resets.add(processor_reset)
        contracts.add((semantics["polarity"], semantics["synchrony"]))
    for cap in plan.capabilities:
        if cap.protocol is not None and cap.endpoint_id not in bound:
            raise ValueError("unbound external protocol fields")
        for f in cap.fields:
            if f.role in {"clock", "reset"}:
                if (f.direction != "input" or f.width != 1 or f.port not in ports or
                        f.member_path or f.container_width not in (None, 1) or
                        ports[f.port]["width"] != 1):
                    raise ValueError("invalid runtime clock/reset")
                (clocks if f.role == "clock" else resets).add(f.port)
        controls = {f.role: f.port for f in cap.fields if f.role in {"clock", "reset"}}
        if set(controls) == {"clock", "reset"}:
            # Semantic field bindings survive even when the crawler cannot
            # infer its conventional active-low asynchronous control bundle.
            # The HDL reset verifier below still proves polarity/synchrony.
            endpoint = replace(cap, clock=controls["clock"], reset=controls["reset"])
            verified = _generic_with_reset_contract(endpoint, source_root, modules[cap.endpoint_id])
            semantics = _generic_endpoint_reset_contract(verified)
            contracts.add((semantics["polarity"], semantics["synchrony"]))
    if len(clocks) != 1 or len(resets) != 1 or len(contracts) != 1 or clocks & resets:
        raise ValueError("runtime requires one verified clock/reset domain")
    clock, reset = next(iter(clocks)), next(iter(resets))
    wanted = {p for p, r in ports.items() if r["direction"] == "input"} - clocks - resets
    fields, seen, cursor = [], set(), 0
    for field in plan.layout.fields:
        role = _canonical_control_role(field.role, control_defaults)
        enabled = role in randomized_controls and field.constraint.get("randomizable") is True
        if field.port not in wanted or (role is not None and not enabled):
            continue
        seen.add(field.port)
        fields.append(replace(field, raw_lo=cursor, raw_hi=cursor + field.width - 1))
        cursor += field.width
    fixed = {field.port for field in plan.layout.fields
             if _canonical_control_role(field.role, control_defaults) is not None}
    expected = wanted - fixed
    if not expected.issubset(seen) or (not fields and contract_transducer is None) or cursor > 65536:
        raise ValueError("unbound or oversized runtime input layout")
    provisional = InputLayout("input_layout.v1", cursor, tuple(fields), "pending")
    doc = input_layout_document(provisional)
    doc.pop("layout_hash")
    for f in doc["fields"]:
        f.pop("provenance", None)
    layout = replace(provisional, layout_hash=hashlib.sha256(canonical_bytes(doc)).hexdigest())
    if contract_transducer is None:
        projector = RuntimeProjector(
            layout, isa=plan.request.isa,
            require_compiler_provenance=getattr(plan, "processor_execution", None) is not None,
        )
    else:
        declared = dict(contract_transducer.external_inputs)
        if declared != {field.field_id: field.width for field in fields}:
            raise ValueError("contract external inputs do not match runtime physical bindings")
        # Existing physical-binding checks prove packed compiler offsets and
        # complete, nonoverlapping ranges; no projection is applied to entropy.
        if fields:
            RuntimeProjector(layout, require_compiler_provenance=True)
        for field in fields:
            if field.encoding != "bits" or set(field.constraint) - {"randomizable"}:
                raise ValueError("contract external input requires unconstrained bits")
        cycle_fields = {field.field_id: field for field in contract_transducer.cycle_layout.fields}
        if {name: field.width for name, field in cycle_fields.items() if name.startswith("external.")} != {
            f"external.{field.field_id}": field.width for field in fields
        }:
            raise ValueError("external cycle slices do not match physical bindings")
        external_fields = tuple(replace(field,
            raw_lo=cycle_fields[f"external.{field.field_id}"].raw_lo,
            raw_hi=cycle_fields[f"external.{field.field_id}"].raw_hi) for field in fields)
        layout = replace(layout, fields=external_fields)
        projector = CycleIdentityProjector(contract_transducer, external_fields)
    return ports, clock, reset, next(iter(contracts))[0], layout, projector


def _bench(ports, clock, reset, polarity, layout, coverage, *, control_bindings=(), coverage_signals=(), execution_monitor=None,
           external_fields=None, test_header=None, address_width=None):
    names = {p: r["opaque_port"] for p, r in ports.items()}
    declarations = [f"logic [{r['width']-1}:0] {r['opaque_port']};" for r in ports.values()]
    inputs = []
    for field in layout.fields if external_fields is None else external_fields:
        target = names[field.port]
        if field.member_path:
            target += f"[{field.port_raw_hi}:{field.port_raw_lo}]"
        inputs.append(f"assign {target} = raw_bits[{field.raw_hi}:{field.raw_lo}];")
    controls = []
    for field, value in control_bindings:
        target = names[field.port]
        if field.member_path:
            target += f"[{field.port_raw_hi}:{field.port_raw_lo}]"
        controls.append(f"assign {target} = {field.width}'h{value:x};")
    connections = ",".join(f".{n}({n})" for n in names.values())
    test_controls = []
    begin_test = []
    if test_header is not None:
        test_controls = ["reg test_begin = 0;",
            f"wire [{address_width-1}:0] test_boot_address = {address_width}'h{test_header.boot_address:x};",
            f"wire test_illegal_instruction = 1'b{int(test_header.illegal_instruction)};"]
        connections += ",.rfuzz_cycle_bits(raw_bits),.test_begin(test_begin),.test_boot_address(test_boot_address),.test_illegal_instruction(test_illegal_instruction)"
        begin_test = ["test_begin=1; tick(); test_begin=0;"]
    active = 0 if polarity == "active_low" else 1
    c, r = names[clock], names[reset]
    observations = tuple(coverage) + tuple((f"dut.{signal}", bit) for signal, bit in coverage_signals)
    expressions = tuple(f"{names[port]}[{bit}]" for port, bit in coverage) + tuple(
        f"((dut.{signal} >> {bit}) & 1'b1)" for signal, bit in coverage_signals
    )
    sample = []
    for i, expression in enumerate(expressions):
        sample += [f"if ({expression} !== 1'b0 && {expression} !== 1'b1) $fatal(1,\"unknown observation\");",
                   f"if ({expression} && counters[{i}] != 8'hff) counters[{i}] = counters[{i}] + 1'b1;"]
    return "\n".join([
        "module myfuzz_live_tb;", *declarations, *controls, *test_controls,
        f"reg [{layout.raw_width-1}:0] raw_bits = 0;",
        f"reg [7:0] counters[0:{len(observations)-1}]; integer count, scan, i, j;",
        "logic [63:0] request_id, last_request_id=0;",
        *inputs, f"generic_composition_top dut({connections});",
        *(f'initial if ({bit} >= $bits(dut.{signal})) $fatal(1,"observation bit out of range");'
          for signal, bit in coverage_signals),
        *monitor_rtl(c, r, active, execution_monitor),
        f"task tick; begin #5; {c}=1; #5; {c}=0; end endtask",
        f"initial begin {c}=0; {r}={1-active};",
        f'$display("RFUZZ_READY {SIMULATOR_PROTOCOL_VERSION}"); $fflush();',
        "forever begin",
        'scan=$fscanf(32\'h80000000,"%h %d",request_id,count);',
        'if (scan == -1) $finish;',
        'if (scan != 2 || request_id == 0 || request_id <= last_request_id) $fatal(1,"request id");',
        "last_request_id=request_id;",
        f'if (count < 1 || count > {MAX_CYCLES}) $fatal(1,"cycle count");',
        "raw_bits=0;", *begin_test,
        (f"{r}={active}; repeat ({test_header.reset_cycles}) tick(); {r}={1-active};"
         if test_header is not None else f"{r}={active}; tick(); tick(); {r}={1-active};"),
        f"for (j=0;j<{len(observations)};j=j+1) counters[j]=0;",
        "for (i=0;i<count;i=i+1) begin",
        'scan=$fscanf(32\'h80000000,"%h",raw_bits);',
        'if (scan != 1) $fatal(1,"raw sample");',
        "tick();", *sample, "end",
        '$write("RFUZZ_COUNTERS %016h ",request_id);',
        f'for (j=0;j<{len(observations)};j=j+1) $write("%02x",counters[j]);',
        *monitor_output(execution_monitor),
        '$write("\\n"); $fflush();', "end end endmodule\n",
    ])


def build_simulator(plan, output_dir, *, base_dir, coverage_ports,
                    coverage_inputs=(),
                    randomized_controls=(), control_defaults=None, coverage_signals=(),
                    simulator_args=(), simulator="icarus", isolate_tests=False, execution_monitor=None,
                    contract_transducer=None, test_header=None):
    """Publish into a new directory only; reject unsafe boundaries before build."""
    root, output = Path(base_dir).resolve(), Path(output_dir).absolute()
    if output.exists() or output.is_symlink():
        raise ValueError("simulator output already exists")
    if simulator not in {"icarus", "verilator"}:
        raise ValueError("unsupported simulator")
    if type(isolate_tests) is not bool:
        raise ValueError("isolate_tests must be boolean")
    plan = _validate_generic_plan_freshness(plan, root)
    execution_monitor = validate_monitor(execution_monitor)
    if execution_monitor is not None and getattr(plan, "processor_execution", None) is None:
        raise ValueError("execution monitor requires generated processor backend")
    randomized_controls = _normalize_control_roles(randomized_controls)
    defaults = _control_defaults(control_defaults)
    if contract_transducer is not None:
        if not isinstance(contract_transducer, ContractTransducerPlan):
            raise ValueError("contract transducer plan required")
        if getattr(plan, "processor_execution", None) is None:
            raise ValueError("contract transducer requires processor execution")
        _validate_processor_transducer(plan, contract_transducer)
        contract_transducer.cycle_layout.validate()
        if contract_transducer.cycle_layout.raw_width > 65536:
            raise ValueError("oversized contract cycle layout")
        if test_header is None:
            test_header = TestHeader(TEST_HEADER_SCHEMA_VERSION,
                contract_transducer.cycle_layout.layout_hash, contract_transducer.contract_hash,
                2, MAX_CYCLES, defaults["boot_address"], defaults["hart_id"])
        ContractRuntime(contract_transducer).begin_test(test_header)
        if not 1 <= test_header.reset_cycles <= MAX_CYCLES or not 1 <= test_header.execution_cycles <= MAX_CYCLES:
            raise ValueError("header reset/execution cycles must be bounded and positive")
        if set(randomized_controls) & {"boot_address", "hart_id"}:
            raise ValueError("header boot address and hart id must be fixed")
        for role in ("boot_address", "hart_id"):
            value = getattr(test_header, role)
            if control_defaults is not None and any(
                (_canonical_control_role(key) or key) == role and default != value
                for key, default in control_defaults.items()
            ):
                raise ValueError("header conflicts with fixed runtime control")
            defaults[role] = value
    elif test_header is not None:
        raise ValueError("test header requires contract transducer")
    if execution_monitor is not None and execution_monitor.get("mode") == "contract_transducer":
        if contract_transducer is None:
            raise ValueError("contract execution monitor requires contract transducer")
        if execution_monitor["memory_capacity_entries"] != contract_transducer.memory_capacity_entries:
            raise ValueError("contract execution monitor memory capacity does not match transducer")
        if len(set(dict(contract_transducer.memory_domains).values())) != 1:
            raise ValueError("contract execution monitor requires one shared memory domain")
    if isinstance(simulator_args, (str, bytes)) or not isinstance(simulator_args, Sequence):
        raise ValueError("simulator args must be a sequence")
    if any(not isinstance(value, str) or not value for value in simulator_args):
        raise ValueError("simulator args must be nonempty strings")
    simulator_args = tuple(simulator_args)
    if contract_transducer is not None and any(arg.startswith("+riscv_boot_image=") for arg in simulator_args):
        raise ValueError("contract transducer does not accept a fixed boot image")
    ports, clock, reset, polarity, layout, projector = _runtime_boundary(
        plan, root, randomized_controls=randomized_controls, control_defaults=defaults,
        contract_transducer=contract_transducer,
    )
    control_bindings, control_document = _runtime_control_bindings(
        plan, ports, layout, randomized_controls, defaults
    )
    coverage = tuple(coverage_ports)
    input_coverage = tuple(coverage_inputs)
    signals = tuple(coverage_signals)
    if not coverage and not input_coverage and not signals:
        raise ValueError("explicit bounded output-bit observations required")
    if len(coverage) + len(input_coverage) + len(signals) > 4096:
        raise ValueError("too many coverage observations")
    for item in coverage:
        if not isinstance(item, tuple) or len(item) != 2:
            raise ValueError("invalid output-bit observation")
        port, bit = item
        if (not isinstance(port, str) or port not in ports or ports[port]["direction"] != "output"
                or type(bit) is not int or not 0 <= bit < ports[port]["width"]):
            raise ValueError("invalid output-bit observation")
    if len(set(coverage)) != len(coverage):
        raise ValueError("duplicate output-bit observation")
    randomized_input_ports = {
        field.port for field in layout.fields
        if field.constraint.get("randomizable") is True
    }
    external_fields = layout.fields if contract_transducer is not None else None
    if contract_transducer is not None:
        layout = contract_transducer.cycle_layout
    for item in input_coverage:
        if not isinstance(item, tuple) or len(item) != 2:
            raise ValueError("invalid randomized runtime input observation")
        port, bit = item
        if (not isinstance(port, str) or port not in randomized_input_ports
                or port not in ports or ports[port]["direction"] != "input"
                or type(bit) is not int or not 0 <= bit < ports[port]["width"]):
            raise ValueError("coverage input must be a randomized runtime input")
    if len(set(input_coverage)) != len(input_coverage):
        raise ValueError("duplicate randomized runtime input observation")
    for item in signals:
        if (not isinstance(item, tuple) or len(item) != 2 or not isinstance(item[0], str)
                or not item[0].isidentifier() or type(item[1]) is not int or item[1] < 0):
            raise ValueError("invalid internal coverage observation")
    if len(set(signals)) != len(signals):
        raise ValueError("duplicate internal coverage observation")
    boundary_coverage = coverage + input_coverage
    observations = boundary_coverage + tuple((f"dut.{signal}", bit) for signal, bit in signals)
    coverage_kind = (
        "sampled-dut-signal-bit-events-u8-saturating"
        if input_coverage else "sampled-output-bit-events-u8-saturating"
    )
    transport = (RfuzzInputTransport(layout.raw_width, layout.layout_hash)
                 if contract_transducer is not None else build_rfuzz_transport(layout))
    bench = _bench(ports, clock, reset, polarity, layout, boundary_coverage,
                   control_bindings=control_bindings, coverage_signals=signals,
                   execution_monitor=execution_monitor, external_fields=external_fields,
                   test_header=test_header,
                   address_width=contract_transducer.address_width if contract_transducer is not None else None)
    output.mkdir(parents=True, exist_ok=False)
    write_generic_composition(plan, output / "composition", base_dir=root,
        **({"contract_transducer": contract_transducer} if contract_transducer is not None else {}))
    header_hash = None
    if contract_transducer is not None:
        for filename in ("contract_transducer.json", "contract_transducer.sv"):
            (output / filename).write_bytes((output / "composition" / filename).read_bytes())
        header_hash = content_hash(asdict(test_header))
        (output / "test_header.json").write_bytes(canonical_bytes({**asdict(test_header), "header_hash": header_hash}))
    (output / "runtime_layout.json").write_bytes(canonical_bytes(
        layout.document() if contract_transducer is not None else input_layout_document(layout)))
    (output / "runtime_transport.json").write_bytes(canonical_bytes(transport.document()))
    (output / "observations.json").write_bytes(canonical_bytes({
        "kind": coverage_kind,
        "transport": "rfuzz-coverage-buffer",
        "ports": [list(c) for c in observations],
        "randomized_input_ports": [list(c) for c in input_coverage],
        "internal_signals": [list(c) for c in signals],
    }))
    bench_path = output / "live_tb.sv"
    bench_path.write_text(bench)
    # Publication adds execution sources (including the shared arbiter) which
    # are not necessarily members of the original CPU/component source list.
    published_sources = tuple(
        str((output / "composition" / line).resolve())
        for line in (output / "composition/sources.f").read_text().splitlines()
        if line and not line.startswith(("+", "-"))
    )
    sources = (*published_sources, str(bench_path))
    includes = tuple("-I" + str(p) for p in _generic_include_paths(plan, root))
    if simulator == "icarus":
        executable = output / "sim.vvp"
        command = ("nice", "-n15", "iverilog", "-g2012", "-s", "myfuzz_live_tb",
                   "-o", str(executable), *includes, *_generic_define_options(plan), *sources)
    else:
        executable = output / "obj_dir/Vmyfuzz_live_tb"
        command = ("nice", "-n15", "verilator", "--binary", "--timing",
                   "--top-module", "myfuzz_live_tb", "-Wno-fatal", "-j", "1",
                   "--Mdir", str(output / "obj_dir"),
                   *includes, *_generic_define_options(plan), *sources)
    log_path = output / "compiler.log"
    supervised = (sys.executable, "-c",
        "import subprocess,sys; "
        "log=open(sys.argv[1],'wb'); "
        "result=subprocess.call(sys.argv[2:],stdout=log,stderr=subprocess.STDOUT); "
        "log.close(); sys.exit(result)", str(log_path), *command)
    result = run_supervised_command(CampaignOptions(command=supervised, output_dir=output / "build",
        duration_seconds=120 if simulator == "verilator" else 30,
        checkpoint_seconds=1, env={"JOBS": "1", "MAKEFLAGS": "-j1"}))
    if result["status"] != "completed" or result["returncode"] != 0:
        raise ValueError(f"{simulator} build failed; see {log_path}: {result}")
    if _generic_source_evidence_hash(root, plan.source_files, plan.interface_description.source) != plan.source_evidence_hash:
        raise ValueError("simulator source evidence changed during compilation")
    (output / "artifact_provenance.json").write_bytes(canonical_bytes({
        "schema_version": "rfuzz_artifact_provenance.v1",
        "interface_description": interface_description_document(plan.interface_description),
        "composition_ir_hash": plan.composition_ir_hash,
        "source_evidence_hash": plan.source_evidence_hash,
        "composition_seed": plan.request.seed,
        "isa": asdict(plan.request.isa) if plan.request.isa is not None else None,
        "source_base_dir": str(root),
        "source_sha256": {f: hashlib.sha256((root / f).read_bytes()).hexdigest()
                          for f in plan.source_files},
        "build_command": list(command),
        "executable_sha256": hashlib.sha256(executable.read_bytes()).hexdigest(),
        "layout_hash": layout.layout_hash,
        "transport_hash": transport.document()["transport_hash"],
        "constraint_hash": projector.constraint_hash,
        "instruction_mode": projector.instruction_mode,
        "runtime_controls": {**control_document, "randomized": list(randomized_controls)},
        "coverage_transport": "sysv-shared-memory-rfuzz-coverage-buffer",
        "coverage_kind": coverage_kind,
        "coverage_ports": [list(c) for c in coverage],
        "coverage_inputs": [list(c) for c in input_coverage],
        "coverage_signals": [list(c) for c in signals],
        "simulator_args": list(simulator_args),
        "simulator": simulator,
        "isolate_tests": isolate_tests,
        "execution_monitor": execution_monitor,
        **({"transducer_hash": contract_transducer.contract_hash,
            "implementation_hash": contract_transducer.implementation_hash,
            "transducer_rtl_sha256": "sha256:" + hashlib.sha256((output / "contract_transducer.sv").read_bytes()).hexdigest(),
            "header_hash": header_hash, "test_header": asdict(test_header)}
           if contract_transducer is not None else {}),
    }))
    return SimulatorArtifact(
        layout, transport, executable, observations, projector,
        coverage_kind=coverage_kind,
        control_defaults=control_document,
        randomized_controls=randomized_controls,
        simulator_args=simulator_args,
        simulator=simulator,
        isolate_tests=isolate_tests,
        execution_monitor=execution_monitor,
        transducer_hash=contract_transducer.contract_hash if contract_transducer is not None else None,
        header_hash=header_hash,
        test_header=test_header,
        implementation_hash=contract_transducer.implementation_hash if contract_transducer is not None else None,
    )


class CoverageFirstSeenLedger:
    """Per-point first sighting, derived from the per-test counter readback.

    ``RtlSimulator.run_test`` reads the whole instrumented counter vector back
    once per RTL test (the harness answers ``RFUZZ_COUNTERS <request id>`` with
    the counters of that test), so the first readback that shows a point
    non-zero is a recorded, checkable event - no timestamp has to be invented
    and no post-run snapshot of surviving inputs is involved.

    The ledger is **identity-bound**: it stores the artifact's exact
    ``(port, bit)`` list in the same order as the counter vector, so a reader
    joins entries to points by identity instead of trusting a position, and it
    is **fail-closed**: a readback whose width does not match the declared list,
    a non-integer counter, or a port list beyond
    :data:`~myfuzz.integration.soc_coverage.MAX_FIRST_SEEN_ENTRIES` makes the
    document explicitly invalid and it is then never written.  A missing or
    invalid ledger is reported by the reader as *unavailable with a reason*,
    never as "no point was ever seen".
    """

    def __init__(self, path, ports, *, coverage_kind: str = "",
                 bound: int = MAX_FIRST_SEEN_ENTRIES,
                 session: str | None = None, clock=time.monotonic,
                 flush_seconds: float = FIRST_SEEN_FLUSH_SECONDS) -> None:
        self.path = Path(path)
        self.ports = tuple((str(name), int(bit)) for name, bit in ports)
        self.coverage_kind = str(coverage_kind)
        self.bound = int(bound)
        self.session = session or f"{os.getpid()}-{time.monotonic():.6f}"
        self.flush_seconds = float(flush_seconds)
        self._clock = clock
        self._started = clock()
        self._last_write = None
        self._entries: list[dict | None] = [None] * len(self.ports)
        self._readbacks = 0
        self._reason = ""
        if len(self.ports) > self.bound:
            self._reason = (f"the counter vector holds {len(self.ports)} points, "
                            f"beyond the first-seen bound {self.bound}")

    # -- reading -----------------------------------------------------------

    @property
    def valid(self) -> bool:
        return not self._reason

    @property
    def reason(self) -> str:
        return self._reason

    def document(self) -> dict:
        return {
            "schema_version": FIRST_SEEN_SCHEMA,
            "evidence": FIRST_SEEN_EVIDENCE,
            "event": FIRST_SEEN_EVENT,
            "coverage_kind": self.coverage_kind,
            "counter_count": len(self.ports),
            "bound": self.bound,
            "points": [[name, bit] for name, bit in self.ports],
            "entries": [None if item is None else dict(item)
                        for item in self._entries],
            "observed_points": sum(1 for item in self._entries if item is not None),
            "readbacks": self._readbacks,
            "truncated": False,
            "valid": self.valid,
            "reason": self._reason or None,
            "session": self.session,
        }

    # -- recording ---------------------------------------------------------

    def observe(self, counters, *, event=None) -> bool:
        """Record every point this readback lights for the first time.

        Returns ``True`` when the caller should flush the document now (the
        first sighting of the session, or a later one past the flush interval).
        The readback is the simulator's own counter vector, in the artifact's
        port order; a vector that does not match that order is refused rather
        than reinterpreted.
        """
        now = self._clock()
        values = list(counters)
        if self._reason:
            return False
        self._readbacks += 1
        if len(values) != len(self.ports):
            self._reason = (f"the readback carries {len(values)} counters for "
                            f"{len(self.ports)} declared points")
            return False
        for value in values:
            if type(value) is not int or not 0 <= value <= 255:
                self._reason = f"counter value {value!r} is not an unsigned byte"
                return False
        order = event if event is not None else self._readbacks
        fresh = False
        for index, value in enumerate(values):
            if value > 0 and self._entries[index] is None:
                # Every entry names its own point, so a reader joins by identity
                # instead of trusting a position in a list.
                self._entries[index] = {
                    "point": [self.ports[index][0], self.ports[index][1]],
                    "event": order,
                    "time": round(now - self._started, 6),
                }
                fresh = True
        if not fresh:
            return False
        if self._last_write is None or now - self._last_write >= self.flush_seconds:
            self._last_write = now
            return True
        return False

    # -- persistence -------------------------------------------------------

    def write(self) -> str:
        """Persist the ledger; return ``""`` on success, else the reason.

        Never raises and never clobbers another session's ledger: a run may
        execute comparison arms against the same build directory, and the arm
        that did not own the live readback must not rewrite its evidence.
        """
        if self._reason:
            return self._reason
        existing = None
        if self.path.exists():
            try:
                existing = json.loads(self.path.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                return f"the existing first-seen ledger is unreadable: {self.path}"
            if not isinstance(existing, dict):
                return f"the existing first-seen ledger is not an object: {self.path}"
            if existing.get("session") not in (None, self.session):
                return (f"another coverage session owns the first-seen ledger: "
                        f"{self.path}")
        payload = (json.dumps(self.document(), ensure_ascii=True, sort_keys=True,
                              separators=(",", ":")) + "\n").encode("utf-8")
        temporary = self.path.with_name(self.path.name + ".tmp")
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            temporary.write_bytes(payload)
            os.replace(temporary, self.path)
        except OSError as error:
            try:
                temporary.unlink()
            except OSError:
                pass
            return f"first-seen ledger write failed: {type(error).__name__}"
        return ""


def first_seen_ledger_for_artifact(artifact, *, session: str | None = None,
                                   clock=time.monotonic):
    """The ledger this artifact asked for, or ``None`` when it asked for none.

    Only the instrumented ``soc_*`` build declares
    ``coverage_first_seen_ledger``, so every other simulator user (online
    campaigns, direct replay, comparison arms over non-instrumented artifacts)
    writes nothing at all.
    """
    path = getattr(artifact, "coverage_first_seen_ledger", None)
    if not isinstance(path, (str, Path)) or not str(path):
        return None
    return CoverageFirstSeenLedger(
        Path(path),
        tuple(getattr(artifact, "coverage_ports", ()) or ()),
        coverage_kind=str(getattr(artifact, "coverage_kind", "") or ""),
        session=session, clock=clock)


class RtlSimulator:
    """One private persistent child, with bounded per-test IO and cleanup.

    ``last_diagnostics`` preserves non-protocol output from the latest exchange
    as UTF-8 strings (invalid bytes replaced), including when that test fails.
    Limits count original bytes, including newlines, and apply per exchange.
    Internal protocol v2 correlates every response with its monotonic uint64
    request id encoded as exactly 16 lowercase hexadecimal digits. Versionless
    executables must be rebuilt; no fallback is safe.
    """
    def __init__(self, artifact, *, timeout_seconds=5.0,
                 reject_invalid_projection=False):
        if not isinstance(artifact, SimulatorArtifact):
            raise ValueError("simulator artifact required")
        if (type(timeout_seconds) not in (int, float) or not math.isfinite(timeout_seconds)
                or not 0 < timeout_seconds <= 60):
            raise ValueError("finite simulator deadline required")
        if type(reject_invalid_projection) is not bool:
            raise ValueError("reject_invalid_projection must be boolean")
        self.artifact, self.timeout_seconds = artifact, timeout_seconds
        self.reject_invalid_projection = reject_invalid_projection
        self.last_diagnostics = ()
        self.last_peer_events = ()
        self.last_projection_rejection = None
        self.last_execution = {}
        self._next_rss_poll = 0.0  # Immediate startup check; shared across tests.
        self._executions = 0
        # Projection accounting is evidence for direct-vs-constrained campaign
        # comparisons.  It is bounded and never participates in DUT coverage.
        self._projection_stats = {
            "raw_samples": 0,
            "projected_samples": 0,
            "projection_rejections": 0,
            "raw_unique": 0,
            "projected_unique": 0,
            "unique_tracking_truncated": False,
        }
        self._raw_projection_values: set[int] = set()
        self._projected_values: set[int] = set()
        # Per-point first-seen evidence, recorded from the readback this class
        # already owns.  ``None`` for every artifact that does not declare a
        # ledger, so nothing is written for non-instrumented runs.
        self.first_seen = first_seen_ledger_for_artifact(artifact)
        self.first_seen_error = ""
        self._start()

    def projection_document(self) -> dict[str, object]:
        """Return bounded input projection metrics, separate from RTL coverage."""
        document = dict(self._projection_stats)
        projector = getattr(self.artifact, "projector", None)
        repairs = getattr(projector, "repair_counts", None)
        if isinstance(repairs, Mapping):
            document["repair_counts"] = {
                str(name): int(value) for name, value in repairs.items()
                if type(value) is int and value >= 0
            }
        normalization = getattr(projector, "last_candidate_input_normalization", None)
        if isinstance(normalization, Mapping):
            document["candidate_input_normalization"] = dict(normalization)
        document["instruction_mode"] = str(
            getattr(projector, "instruction_mode", "none"))
        constraint_hash = getattr(projector, "constraint_hash", None)
        if isinstance(constraint_hash, str) and constraint_hash:
            document["constraint_hash"] = constraint_hash
        return document

    def _start(self):
        artifact = self.artifact
        runner = ("vvp",) if artifact.simulator == "icarus" else ()
        self.process = subprocess.Popen(("nice", "-n15", *runner, str(artifact.executable), *artifact.simulator_args),
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True)
        self.closed = False
        try:
            os.set_blocking(self.process.stdin.fileno(), False)
            os.set_blocking(self.process.stdout.fileno(), False)
            if self._exchange(b"", 64) != f"RFUZZ_READY {SIMULATOR_PROTOCOL_VERSION}".encode("ascii"):
                raise ValueError(f"unsupported simulator protocol; rebuild artifact for version {SIMULATOR_PROTOCOL_VERSION}")
        except BaseException:
            self.close()
            raise

    def _exchange(self, payload, max_reply, monitor=None):
        deadline = time.monotonic() + self.timeout_seconds
        pending, reply = memoryview(payload), bytearray()
        diagnostics, diagnostic_bytes, frame = [], 0, None
        self.last_diagnostics = ()
        try:
            # No output from the previous transaction may satisfy a new test.
            if pending:
                try:
                    stale = os.read(self.process.stdout.fileno(), 4096)
                except BlockingIOError:
                    pass
                else:
                    if not stale:
                        raise RuntimeError("simulator closed output")
                    raise ValueError("unexpected simulator response framing before test")
            with selectors.DefaultSelector() as selector:
                selector.register(self.process.stdout, selectors.EVENT_READ)
                if pending:
                    selector.register(self.process.stdin, selectors.EVENT_WRITE)
                while True:
                    if monitor is not None:
                        monitor()
                    now = time.monotonic()
                    if now >= deadline:
                        raise TimeoutError("simulator IO deadline exceeded")
                    if now >= self._next_rss_poll and self.process.poll() is None:
                        rss = read_process_group_rss_bytes(self.process.pid)
                        self._next_rss_poll = time.monotonic() + RSS_POLL_SECONDS
                        if rss >= 512 * 1024 * 1024:
                            raise RuntimeError("simulator group RSS soft limit exceeded")
                    for key, _ in selector.select(min(0.02, max(0, deadline - time.monotonic()))):
                        if key.fileobj is self.process.stdin:
                            try:
                                count = os.write(key.fd, pending[:65536])
                            except BlockingIOError:
                                continue
                            pending = pending[count:]
                            if not pending:
                                selector.unregister(self.process.stdin)
                        else:
                            # Drain all currently readable chunks before accepting
                            # a frame, so read chunking cannot hide duplicates.
                            while True:
                                try:
                                    chunk = os.read(key.fd, 4096)
                                except BlockingIOError:
                                    if frame is not None:
                                        if self.process.poll() is not None:
                                            raise RuntimeError("simulator exited after response")
                                        return frame
                                    break
                                if not chunk:
                                    raise RuntimeError("simulator closed output")
                                if frame is not None:
                                    raise ValueError("unexpected simulator response framing")
                                reply.extend(chunk)
                                while b"\n" in reply:
                                    line, _, remaining = reply.partition(b"\n")
                                    reply = bytearray(remaining)
                                    if line.startswith(b"RFUZZ_"):
                                        expected = (line.startswith(b"RFUZZ_COUNTERS ")
                                                    if payload else line == b"RFUZZ_READY" or line.startswith(b"RFUZZ_READY "))
                                        if pending or not expected or reply:
                                            raise ValueError("unexpected simulator response framing")
                                        if len(line) > max_reply:
                                            raise ValueError("oversized simulator response")
                                        frame = bytes(line)
                                    else:
                                        if (len(line) > MAX_DIAGNOSTIC_LINE_BYTES
                                                or len(diagnostics) >= MAX_DIAGNOSTIC_LINES
                                                or diagnostic_bytes + len(line) + 1 > MAX_DIAGNOSTIC_BYTES):
                                            raise ValueError("simulator diagnostic output limit exceeded")
                                        diagnostic_bytes += len(line) + 1
                                        diagnostics.append(line.decode("utf-8", errors="replace"))
                                if reply.startswith(b"RFUZZ_"):
                                    if len(reply) > max_reply:
                                        raise ValueError("oversized simulator response")
                                elif (len(reply) > MAX_DIAGNOSTIC_LINE_BYTES
                                      or diagnostic_bytes + len(reply) > MAX_DIAGNOSTIC_BYTES):
                                    raise ValueError("simulator diagnostic output limit exceeded")
        finally:
            if (reply and not reply.startswith(b"RFUZZ_")
                    and len(reply) <= MAX_DIAGNOSTIC_LINE_BYTES
                    and len(diagnostics) < MAX_DIAGNOSTIC_LINES
                    and diagnostic_bytes + len(reply) <= MAX_DIAGNOSTIC_BYTES):
                diagnostics.append(reply.decode("utf-8", errors="replace"))
            self.last_diagnostics = tuple(diagnostics)

    def run_test(self, records, *, monitor=None):
        self.last_diagnostics = ()
        self.last_peer_events = ()
        self.last_projection_rejection = None
        self.last_execution = {}
        if self.closed:
            raise ValueError("simulator is closed")
        if not isinstance(records, (tuple, list)) or not 1 <= len(records) <= MAX_CYCLES:
            raise ValueError("bounded nonempty sample sequence required")
        if self.artifact.test_header is not None and len(records) > self.artifact.test_header.execution_cycles:
            raise ValueError("test exceeds header execution cycle limit")
        if len(records) * (self.artifact.layout.raw_width // 4 + 2) > MAX_IO_BYTES:
            raise ValueError("test input exceeds IO bound")
        if self._executions >= MAX_REQUEST_ID:
            raise ValueError("simulator request id exhausted")
        if self.artifact.isolate_tests and self._executions:
            self.close()
            self._start()
        self._executions += 1
        raw_values = [self.artifact.transport.unpack(r) for r in records]
        self._projection_stats["raw_samples"] += len(raw_values)
        if len(self._raw_projection_values) < MAX_PROJECTION_UNIQUE:
            self._raw_projection_values.update(raw_values)
            if len(self._raw_projection_values) >= MAX_PROJECTION_UNIQUE:
                self._projection_stats["unique_tracking_truncated"] = True
        self._projection_stats["raw_unique"] = len(self._raw_projection_values)
        try:
            project_records = getattr(self.artifact.projector, "project_records", None)
            samples = (project_records(raw_values) if project_records is not None else
                       [self.artifact.projector.project(raw) for raw in raw_values])
        except BaseException as error:
            self._projection_stats["projection_rejections"] += len(raw_values)
            if self.reject_invalid_projection:
                # soc_builder imports this module to define SimulatorArtifact,
                # so import its exception only after module initialization.
                # Direct simulator/replay use keeps the existing fail-closed
                # behavior; only live campaigns may turn a declared candidate
                # refusal into an empty-feedback mutation sample.
                from .soc_builder import SocBuildError
                if isinstance(error, SocBuildError):
                    self.last_projection_rejection = {
                        "type": type(error).__name__,
                        "message": str(error)[:512],
                    }
                    return bytes(len(self.artifact.coverage_ports))
            self.close()
            raise
        if (not isinstance(samples, Sequence) or isinstance(samples, (str, bytes))
                or len(samples) != len(raw_values)):
            raise ValueError("projector returned the wrong sample count")
        for sample in samples:
            if type(sample) is not int or not 0 <= sample < (1 << self.artifact.layout.raw_width):
                self._projection_stats["projection_rejections"] += len(raw_values)
                self.close()
                raise ValueError("projector returned a sample outside the layout")
        peer_slots = tuple(getattr(self.artifact, "peer_slots", ()) or ())
        if peer_slots:
            try:
                self.last_peer_events = decode_peer_raw_events(
                    samples, self.artifact.layout, peer_slots, validate_spacing=False)
            except PeerRawReplayError as error:
                self.close()
                raise ValueError(str(error)) from error
        else:
            self.last_peer_events = ()
        self._projection_stats["projected_samples"] += len(samples)
        if len(self._projected_values) < MAX_PROJECTION_UNIQUE:
            self._projected_values.update(samples)
            if len(self._projected_values) >= MAX_PROJECTION_UNIQUE:
                self._projection_stats["unique_tracking_truncated"] = True
        self._projection_stats["projected_unique"] = len(self._projected_values)
        payload = (f"{self._executions:016x} {len(samples)}\n" + "".join(f"{s:x}\n" for s in samples)).encode("ascii")
        try:
            count = len(self.artifact.coverage_ports)
            reply = self._exchange(payload, 2 * count + 256, monitor=monitor)
            prefix = f"RFUZZ_COUNTERS {self._executions:016x} ".encode("ascii")
            if not reply.startswith(prefix):
                raise ValueError("invalid simulator response request id")
            reply = reply[len(prefix):]
            if self.artifact.execution_monitor is not None:
                reply, separator, metrics = reply.partition(b" EXEC ")
                if not separator:
                    raise ValueError("missing RTL execution metrics")
                self.last_execution = validate_execution(parse_metrics(metrics, self.artifact.execution_monitor))
            if len(reply) != 2 * count:
                raise ValueError("invalid simulator counter response")
            counters = bytes.fromhex(reply.decode("ascii"))
            if len(counters) != count:
                raise ValueError("invalid simulator counter length")
            self._record_first_seen(counters)
            return counters
        except BaseException:
            self.close()
            raise

    def _record_first_seen(self, counters) -> None:
        """Add this readback's first sightings to the artifact's ledger.

        Recording is pure bookkeeping next to the readback that already
        happened: it can never change the counters a caller receives, and a
        ledger problem is reported through the ledger document instead of
        failing the test.  If the ledger itself misbehaves, evidence is dropped
        (and therefore reported as unavailable by the reader) rather than
        turning an RTL test into a campaign failure.
        """
        ledger = self.first_seen
        if ledger is None:
            return
        try:
            if ledger.observe(counters, event=self._executions):
                ledger.write()
        except Exception as error:  # auxiliary evidence, never the run gate
            self.first_seen_error = f"{type(error).__name__}: {error}"
            self.first_seen = None

    def close(self):
        if self.closed:
            return
        self.closed = True
        # The readback stream ends here, so the ledger is flushed even when the
        # campaign was interrupted: the evidence must not exist only in memory.
        # It must never delay the child cleanup below either.
        if self.first_seen is not None:
            try:
                self.first_seen.write()
            except Exception as error:  # auxiliary evidence, never the run gate
                self.first_seen_error = f"{type(error).__name__}: {error}"
        # start_new_session establishes an owned process group. Signal only it,
        # including descendants even when the immediate VVP child exited.
        try:
            os.killpg(self.process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        try:
            self.process.wait(timeout=0.25)
        except subprocess.TimeoutExpired:
            pass
        try:
            os.killpg(self.process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        self.process.wait(timeout=1)
        self.process.stdin.close()
        self.process.stdout.close()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()
