#!/bin/bash
set -u
source /root/fanzehui/system-20261016/environment.sh
export PYTHONPATH=/root/fanzehui/f4-verification-20261017/project-attempt3/src:/root/fanzehui/f4-verification-20261017/project-attempt3:/root/fanzehui/system-20261016/pythonlib
cd /root/fanzehui/f4-verification-20261017/project-attempt3 || exit 97
printf '%s\n' "$$" > /root/fanzehui/f4-verification-20261017/gate-attempt3.pid
python3 scripts/run_compiled_dataflow.py \
  --compose configs/scenarios/compiled-f4-obi-apb-ibex/compose.json \
  --ip-capability configs/scenarios/compiled-f4-obi-apb-ibex/test_capability.json \
  --supplement configs/scenarios/compiled-f4-obi-apb-ibex/execution_supplement.json \
  --records configs/scenarios/compiled-f4-obi-apb-ibex/example_records.json \
  --executor compiled_f4_obi_apb \
  --output /root/fanzehui/f4-verification-20261017/evidence-attempt3 \
  --cache-dir /root/fanzehui/system-20261016/f4-ibex-cache \
  --heavy-lock /root/fanzehui/system-20261016/project/.superpowers/heavy-worker.lock \
  --run-id compiled-f4-ibex-real --max-cases 4 --rounds-per-case 128 --replays 2 \
  > /root/fanzehui/f4-verification-20261017/logs/entry-attempt3.log 2>&1
entry_exit=$?
printf '%s\n' "$entry_exit" > /root/fanzehui/f4-verification-20261017/logs/entry-attempt3.exit
exit "$entry_exit"
