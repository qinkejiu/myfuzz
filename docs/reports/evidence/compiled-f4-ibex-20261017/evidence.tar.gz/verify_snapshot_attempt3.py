from pathlib import Path
from hashlib import sha256
import json
root=Path('/root/fanzehui/f4-verification-20261017/project-attempt3')
manifest=json.loads((root.parent/'source_manifest_attempt3.json').read_text())
wrong=[name for name,digest in manifest['files'].items() if not (root/name).is_file() or sha256((root/name).read_bytes()).hexdigest()!=digest]
(root.parent/'logs/source_verification-attempt3.json').write_text(json.dumps({'matches':not wrong,'mismatches':wrong,'file_count':len(manifest['files'])},indent=2)+'\n')
if wrong:raise SystemExit(2)
