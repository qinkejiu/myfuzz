#!/bin/bash
set -euo pipefail
export MYFUZZ_SOURCE_ROOT=/root/fanzehui/myfuzz/operations/p7-i5-independent-601964f-20261018-attempt2/project
. /root/fanzehui/myfuzz/operations/environment-20261018-attempt3/environment.sh
cd "$MYFUZZ_SOURCE_ROOT"
exec python3 /root/fanzehui/myfuzz/operations/p7-i5-attempt2-inputs-20261018/run_i5_attempt2.py
