import base64,json,subprocess,hashlib
from pathlib import Path
base=Path('/tmp/p7-i5-root-control-20261018')
repairs={f'third_party/rfuzz/upstream/ibex/.git/refs{suffix}':{'mode':493,'evidence':'Root read-only observation of original /tmp/myfuzz-independent-preparation-20261018/ibex-materialized/.git/refs on 2026-10-18: refs contains empty heads and tags, all0755; remote first attempt missing refs.'} for suffix in ('','/heads','/tags')}
(base/'directory-repairs.json').write_text(json.dumps(repairs,sort_keys=True,indent=2)+'\n')
files={'prepare_attempt2.py':Path('/tmp/p7-i5-attempt2-control-20261018/prepare_attempt2.py'),'prepare_p7_i5_snapshot.py':Path('/home/qinkejiu/myfuzz/scripts/prepare_p7_i5_snapshot.py'),'directory-repairs.json':base/'directory-repairs.json','verify_layout.py':base/'verify_layout.py'}
payload={name:base64.b64encode(p.read_bytes()).decode() for name,p in files.items()}
script="import base64,json\nfrom pathlib import Path\nb=Path('/root/fanzehui/myfuzz/operations/p7-i5-attempt2-inputs-20261018');b.mkdir(exist_ok=False)\npayload="+repr(payload)+"\nfor n,v in payload.items():\n with (b/n).open('xb') as f:f.write(base64.b64decode(v))\nprint(json.dumps({'status':'uploaded_inputs_only','base':str(b)}))\n"
result=subprocess.run(['ssh','jumpserver','ssh root@192.168.5.70 python3 -'],input=script.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(base/'upload.stdout').write_bytes(result.stdout);(base/'upload.stderr').write_bytes(result.stderr)
pins={n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in files.items()};(base/'input-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
print(json.dumps({'returncode':result.returncode,'stdout':result.stdout.decode(),'pins':pins}));raise SystemExit(result.returncode)
