import sys
sys.dont_write_bytecode=True
from pathlib import Path
import json,os
base=Path('/root/fanzehui/myfuzz/operations/p7-i5-independent-6b40ef4-20261018-attempt1');run=base/'run-attempt1'
report={'run_exists':run.exists(),'processes':[],'result':None,'live_parents':[]}
if run.exists():
 for p in sorted(run.glob('*.process.json')):
  r=json.loads(p.read_text());report['processes'].append({'name':p.stem,'pid':r.get('pid'),'returncode':r.get('returncode')})
  if r.get('returncode') is None and r.get('pid'):
   s=Path('/proc')/str(r['pid'])/'status'
   if s.is_file():
    fields=dict(line.split(':',1) for line in s.read_text().splitlines() if ':' in line)
    parent=int(fields['PPid'].strip());cmd=(Path('/proc')/str(parent)/'cmdline').read_bytes().split(b'\0')
    if str(run).encode() in cmd:report['live_parents'].append({'pid':parent,'child_pid':r['pid'],'state':fields['State'].strip()})
 if (run/'result.json').is_file():report['result']=json.loads((run/'result.json').read_text())
print(json.dumps(report))
