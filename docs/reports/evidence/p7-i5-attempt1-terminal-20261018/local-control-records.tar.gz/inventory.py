import sys
sys.dont_write_bytecode=True
from pathlib import Path
import os,json,hashlib,shutil,stat
base=Path('/root/fanzehui/myfuzz/operations/p7-i5-independent-6b40ef4-20261018-attempt1')
envbase=Path('/root/fanzehui/myfuzz/operations/environment-20261018-attempt1')
ready=json.loads((base/'control/copy-ready.json').read_text())
assert ready['status']=='source_copy_verified_only'
def pin(p):
 p=Path(p);real=p.resolve(strict=True)
 with real.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
 return {'path':str(p),'resolved':str(real),'sha256':digest,'bytes':real.stat().st_size,'executable':os.access(real,os.X_OK)}
files={}
for p in (envbase/'bin').iterdir():files[str(p)]=pin(p)
installed=Path('/root/fanzehui/myfuzz/tools/verilator-5.051')
for p in (installed/'bin').iterdir():files[str(p)]=pin(p)
share={}
for p in (installed/'share/verilator').rglob('*'):
 if p.is_symlink():raise ValueError('unexpected tool share symlink:'+str(p))
 if p.is_file():share[str(p.relative_to(installed))]=pin(p)
system={n:pin('/usr/bin/'+n) for n in ('git','c++','g++','gcc','cc','ar','make','perl','python3')}
pythonlib=Path('/root/fanzehui/myfuzz/pythonlib');dependencies={}
for p in pythonlib.rglob('*'):
 if p.is_symlink():raise ValueError('pythonlib symlink:'+str(p))
 if p.is_file():
  with p.open('rb') as f:d=hashlib.file_digest(f,'sha256').hexdigest()
  dependencies[str(p.relative_to(pythonlib))]={'sha256':d,'bytes':p.stat().st_size}
receipt={'status':'static_inventory_only_no_tool_executed','pid':os.getpid(),'source_copy_freeze':ready['freeze_sha256'],'entrypoints':files,'system_entrypoints':system,'verilator_share':share,'pythonlib_files':dependencies,'pythonlib_file_count':len(dependencies),'native_tests_frontend_build_executed':False,'environment_source_sha256':pin(envbase/'environment.sh')['sha256']}
(base/'control/tool-inventory.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':receipt['status'],'pid':os.getpid(),'wrappers_and_installed':len(files),'share_files':len(share),'pythonlib_files':len(dependencies),'system_entrypoints':{n:r['resolved'] for n,r in system.items()}}))
