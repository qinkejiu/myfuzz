#!/bin/bash
set -eu
export MYFUZZ_SOURCE_ROOT=/root/fanzehui/myfuzz/operations/p7-i5-independent-6b40ef4-20261018-attempt1/project
. /root/fanzehui/myfuzz/operations/environment-20261018-attempt3/environment.sh
exec python3 /root/fanzehui/myfuzz/operations/p7-i5-independent-6b40ef4-20261018-attempt1/control/query-tools.py
