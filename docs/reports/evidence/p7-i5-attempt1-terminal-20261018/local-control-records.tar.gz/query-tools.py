import sys
sys.dont_write_bytecode=True
from pathlib import Path
import os,json,hashlib,subprocess,fcntl,shutil,re,time
base=Path('/root/fanzehui/myfuzz/operations/p7-i5-independent-6b40ef4-20261018-attempt1');project=base/'project';environment=Path('/root/fanzehui/myfuzz/operations/environment-20261018-attempt3')
output=base/'control/tool-query-attempt1';output.mkdir(exist_ok=False)
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(v):(output/'operation.json').write_text(json.dumps(v,indent=2)+'\n')
manifest=environment/'tool-freeze.json';assert sha(manifest)=='6591a2023be5c4564d72d4a224d8c6c4b543fd811884f540355273eefbd63b4b'
assert sha(environment/'environment.sh')=='9141ae65b8af8a0a1fdd891b64afb6bfc1cf4497a686bf14e35f0d926574f15c'
tools=json.loads(manifest.read_text());freeze=json.loads((base/'control/ready-freeze.json').read_text())
def check_source():
 for n,pin in freeze.items():
  p=project/n
  if p.stat().st_size!=pin['bytes'] or sha(p)!=pin['sha256']:raise ValueError('source-drift:'+n)
def check_tools():
 for name,row in tools.items():
  found=shutil.which(name)
  if found is None or str(Path(found).resolve())!=row['path'] or sha(row['path'])!=row['sha256']:raise ValueError('tool-selection-drift:'+name)
status={'status':'started','pid':os.getpid(),'scope':'tool version/identity only; no frontend/model/build/test','children':[]};save(status)
with Path('/root/fanzehui/system-20261016/project/.superpowers/heavy-worker.lock').open('r+') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 try:
  check_tools();check_source()
  commands=[('verilator',['--version']),('verilator',['-V']),('verilator_bin',['--version']),('c++',['--version']),('make',['--version']),('ar',['--version']),('git',['--version']),('perl',['--version']),('python3',['--version'])]
  for i,(name,args) in enumerate(commands):
   argv=[tools[name]['path'],*args];prefix=str(i)+'-'+name.replace('+','x')
   with (output/(prefix+'.stdout')).open('xb') as out,(output/(prefix+'.stderr')).open('xb') as err:
    child=subprocess.Popen(argv,env=dict(os.environ),stdout=out,stderr=err,stdin=subprocess.DEVNULL)
    row={'argv':argv,'pid':child.pid,'returncode':None};status['children'].append(row)
    primary=None
    try:save(status)
    except BaseException as exc:primary=exc
    while True:
     try:code=child.wait(timeout=10);break
     except subprocess.TimeoutExpired:continue
     except BaseException as exc:
      if primary is None:primary=exc
    row['returncode']=code;row['stdout_sha256']=sha(output/(prefix+'.stdout'));row['stderr_sha256']=sha(output/(prefix+'.stderr'))
    save(status)
    if primary is not None:raise primary
    if code:raise RuntimeError('version-query-child-nonzero:'+prefix)
  details=(output/'1-verilator.stdout').read_text()
  roots=re.findall(r'^\s*VERILATOR_ROOT\s*=\s*(.+)$',details,re.M)
  expected='/root/fanzehui/myfuzz/tools/verilator-5.051/share/verilator'
  if not roots or str(Path(roots[-1].strip()).resolve())!=expected:raise ValueError('runtime-root-mismatch')
  check_tools();check_source()
  status.update(status='terminal0',tools_unchanged=True,source_unchanged=True,verilator_runtime_root=expected,native_tests_frontend_build_executed=False)
 except BaseException as exc:
  status.update(status='failed',error=type(exc).__name__+': '+str(exc));save(status);raise
 save(status)
print(json.dumps({'status':status['status'],'pid':os.getpid(),'children':len(status['children']),'source_unchanged':status.get('source_unchanged'),'verilator_runtime_root':status.get('verilator_runtime_root')}))
