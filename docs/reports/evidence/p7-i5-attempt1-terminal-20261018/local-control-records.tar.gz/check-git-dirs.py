import sys
sys.dont_write_bytecode=True
from pathlib import Path
import json
base=Path('/root/fanzehui/myfuzz/operations/p7-i5-independent-6b40ef4-20261018-attempt1');root=base/'project'
rows=[]
for name in ('.git','third_party/rfuzz/upstream/ibex/.git','third_party/cv32e20_upstream_reference/.git','third_party/soc-pulp-apb-gpio/.git'):
 p=root/name;rows.append({'path':name,'HEAD_file':(p/'HEAD').is_file(),'HEAD':(p/'HEAD').read_text().strip() if (p/'HEAD').is_file() else None,'objects_directory':(p/'objects').is_dir(),'refs_directory':(p/'refs').is_dir()})
receipt={'scope':'read-only essential Git directory inspection afterterminalfailure','rows':rows,'test_or_native_executed':False}
(base/'control/git-directory-diagnosis.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
