#!/bin/bash
set -euo pipefail
export MYFUZZ_SOURCE_ROOT=/root/fanzehui/myfuzz/operations/p7-i5-independent-6b40ef4-20261018-attempt1/project
. /root/fanzehui/myfuzz/operations/environment-20261018-attempt3/environment.sh
cd "$MYFUZZ_SOURCE_ROOT"
exec python3 scripts/run_p7_i5_acceptance.py \
 --base-dir "$MYFUZZ_SOURCE_ROOT" \
 --freeze-map /root/fanzehui/myfuzz/operations/p7-i5-independent-6b40ef4-20261018-attempt1/control/ready-freeze.json \
 --freeze-sha256 b6372fcdb7ca1e93c289f850b0d53bc421c571204a65b86bd828815eb1f13dd2 \
 --expected-commit 6b40ef4a5c13f01d50a1103dabbdffd2dd4c8941 \
 --output /root/fanzehui/myfuzz/operations/p7-i5-independent-6b40ef4-20261018-attempt1/run-attempt1 \
 --client-binary /root/fanzehui/myfuzz/operations/p7-i5-independent-6b40ef4-20261018-attempt1/client/kfuzz \
 --client-sha256 16434544a4a0712fa7716f6f3e3ff8e0dd949139f6a047780f4d08694ff31dcc \
 --lock-file /root/fanzehui/system-20261016/project/.superpowers/heavy-worker.lock \
 --pythonlib /root/fanzehui/myfuzz/pythonlib \
 --tool-freeze /root/fanzehui/myfuzz/operations/environment-20261018-attempt3/tool-freeze.json \
 --tool-freeze-sha256 6591a2023be5c4564d72d4a224d8c6c4b543fd811884f540355273eefbd63b4b \
 --execute
