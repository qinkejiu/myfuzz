import sys
sys.dont_write_bytecode=True
from pathlib import Path
import json,os,hashlib,shutil
root=Path('/root/fanzehui/myfuzz');base=root/'operations/environment-20261018-attempt2';tool=root/'tools/verilator-5.051'
assert (tool/'bin/verilator_bin').is_file()
assert all((tool/'share/verilator/include'/n).is_file() for n in ('verilated_std.sv','verilated_std_waiver.vlt'))
base.mkdir(parents=True,exist_ok=False);(base/'bin').mkdir();(base/'tmp').mkdir();(base/'empty.gitconfig').write_text('')
for name in ('c++','g++','gcc','cc','ar','make'):
 p=base/'bin'/name;p.write_text('#!/bin/sh\nexport TMPDIR='+str(base/'tmp')+'\nexec /usr/bin/'+name+' "$@"\n');p.chmod(0o755)
env='''# Isolated environment, prepared without invoking any compiler/frontend/model.
case "${MYFUZZ_SOURCE_ROOT:-}" in
 /root/fanzehui/myfuzz/operations/*/project) ;;
 *) echo 'independent operations project required' >&2; return 2 ;;
esac
unset GIT_DIR GIT_WORK_TREE GIT_COMMON_DIR GIT_INDEX_FILE GIT_NAMESPACE GIT_OBJECT_DIRECTORY GIT_ALTERNATE_OBJECT_DIRECTORIES GIT_CONFIG_COUNT GIT_CONFIG_PARAMETERS GIT_CONFIG_SYSTEM
unset PYTHONHOME PYTHONSTARTUP PYTHONUSERBASE PYTHONPYCACHEPREFIX PYTEST_ADDOPTS
unset VERILATOR_ROOT VERILATOR_BIN VERILATOR_TEST_FLAGS VERILATOR_GDB VERILATOR_VALGRIND
export PATH=BASE/bin:TOOL/bin:/usr/bin:/bin
export TMPDIR=BASE/tmp
export PYTHONPATH="$MYFUZZ_SOURCE_ROOT/src:$MYFUZZ_SOURCE_ROOT:/root/fanzehui/myfuzz/pythonlib"
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 PYTHONOPTIMIZE=0 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
export GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=BASE/empty.gitconfig GIT_OPTIONAL_LOCKS=0 GIT_NO_LAZY_FETCH=1
'''.replace('BASE',str(base)).replace('TOOL',str(tool))
(base/'environment.sh').write_text(env)
def pin(p):
 p=Path(p);r=p.resolve(strict=True)
 with r.open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=str(p),resolved=str(r),sha256=sha,bytes=r.stat().st_size)
paths={n:base/'bin'/n for n in ('c++','g++','gcc','cc','ar','make')}
paths.update(verilator=tool/'bin/verilator',verilator_bin=tool/'bin/verilator_bin',git=Path('/usr/bin/git'),perl=Path('/usr/bin/perl'),python3=Path('/usr/bin/python3'))
manifest={n:{'path':v['resolved'],'sha256':v['sha256']} for n,p in paths.items() for v in [pin(p)]}
(base/'tool-freeze.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
receipt={'status':'prepared_static_only','base':str(base),'pid':os.getpid(),'files':{str(p.relative_to(base)):pin(p) for p in base.rglob('*') if p.is_file()},'source_snapshot_modified':False,'coherent_verilator_prefix':str(tool),'actual_backend_adjacent':True,'pseudo_source_paths_match_prefix':True,'tools_queried_or_executed':False,'native_tests_frontend_build_executed':False}
(base/'preparation-receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':receipt['status'],'base':str(base),'tool_freeze_sha256':pin(base/'tool-freeze.json')['sha256'],'environment_sha256':pin(base/'environment.sh')['sha256'],'tool_manifest_entries':len(manifest)}))
