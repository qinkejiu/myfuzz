"""Component-neutral persistent APB3 register and pin-observation session."""
from __future__ import annotations

from collections import deque
from collections.abc import Mapping
from copy import deepcopy
import json

from .session import GeneratedLocalSession


class GeneratedApb3RegisterSession(GeneratedLocalSession):
    artifact_kind = 'apb3_register_observe'
    # Driver command names are class attributes so a sibling register protocol
    # can reuse this beat-facing implementation by naming its own commands.
    # The defaults keep every existing APB3 artifact byte-identical.
    access_operation = 'ACCESS_APB3_REG'
    step_operation = 'STEP_APB3_REG'
    source_operation = 'SOURCE_APB3_REG'
    bind_operation = 'BIND_APB3_REG'
    transport_error_label = 'generic APB3'
    error_response_label = 'real APB3'

    def __init__(self, artifact, *, base_dir, cache_dir, setup_writes=(),
                 probe_offsets=(), **kwargs):
        super().__init__(artifact, base_dir=base_dir, cache_dir=cache_dir, **kwargs)
        if self._expected_ready()[3] != self.artifact_kind:
            raise ValueError(f'{self.transport_error_label} register artifact required')
        window = artifact.plan.profile.address.window_size
        def offset_ok(value):
            return type(value) is int and 0 <= value < window and value % 4 == 0
        if (type(setup_writes) is not tuple or len(setup_writes) > 16 or
                any(type(row) is not tuple or len(row) != 2 or not offset_ok(row[0]) or
                    type(row[1]) is not int or not 0 <= row[1] <= 0xffffffff
                    for row in setup_writes) or
                type(probe_offsets) is not tuple or len(probe_offsets) > 16 or
                any(not offset_ok(offset) for offset in probe_offsets)):
            raise ValueError(f'invalid {self.transport_error_label} register scenario')
        self.setup_writes = setup_writes
        self.probe_offsets = probe_offsets
        self._window = window
        self._started = False
        self._storage_active_context = None
        self._storage_last_access = None
        self._samples = deque()
        self.local_transactions = []
        # A2 retrieval state is private and initialized before any command.
        # Ordinary `_take` and `_samples` remain reserved for normal commands.
        self._storage_startup_contract = None
        self._storage_startup_required = False
        self._storage_startup_complete = False
        self._storage_startup_receipts = []
        self._storage_startup_last_receipt = None
        self._storage_startup_failure = None
        self._storage_startup_ports = None
        self._storage_startup_retrieving = False
        self._storage_startup_bytes = 0
        self._dynamic = {}
        for index, row in enumerate(artifact.runtime_document['dynamic_physical_inputs']):
            name = row['input_name']
            if name in self._dynamic or not 1 <= row['width'] <= 64:
                raise ValueError(f'invalid {self.transport_error_label} dynamic input')
            self._dynamic[name] = (index, row['width'], row['source_id'])
        self._dynamic_values = {name: 0 for name in self._dynamic}
        self._bound = {}
        for index, row in enumerate(artifact.runtime_document['bound_physical_inputs']):
            name = row['input_name']
            if name in self._dynamic or name in self._bound or not 1 <= row['width'] <= 64:
                raise ValueError(f'invalid {self.transport_error_label} bound input')
            self._bound[name] = (index, row['width'], row['producer_ref'])
        self._bound_values = {name: 0 for name in self._bound}
        self._outputs = {}
        for row in artifact.runtime_document['physical_exports']:
            if row['direction'] != 'output':
                continue
            name = row['physical_port']
            if name in self._outputs:
                raise ValueError(f'ambiguous {self.transport_error_label} physical observation')
            self._outputs[name] = (row['runtime_name'], row['width'])
        document = self._artifact_document
        if ('storage_startup_capture' in document
                or document.get('driver_schema_version') ==
                'local_driver_generation.apb_storage_startup.v2'):
            from .apb_storage_startup import contract_from_document
            self._storage_startup_contract = contract_from_document(document)
            self._storage_startup_required = True
            # The closed A2 producer is admitted only with empty setup/probe
            # lists and no dynamic or bound inputs; page retrieval itself does
            # not become a normal samples producer.
            if setup_writes or probe_offsets or self._dynamic or self._bound:
                raise ValueError('storage startup requires empty setup and probes')
            self._storage_startup_ports = deepcopy(document['storage_probe_ports'])
        wait = artifact.runtime_document['effective_max_wait_cycles']
        self.max_local_ticks_per_register_access = 2 * wait + 5
        self.max_local_ticks_per_step = 1 + len(self._dynamic) + len(self._bound) + (
            len(setup_writes) + len(probe_offsets)) * self.max_local_ticks_per_register_access

    @property
    def routed_register_access_enabled(self):
        from .session import _storage_version_authority
        self._check_artifact_stable()
        return _storage_version_authority(self) is not None

    def routed_register_access(self, source_transaction, *, address, offset,
                               write, value, be, delivery_context):
        from dataclasses import asdict
        from copy import deepcopy
        import json
        from myfuzz.scenario.ledger import TransactionKey
        if (not self.routed_register_access_enabled or type(source_transaction) is not TransactionKey
                or type(write) is not bool or any(type(v) is not int for v in (address,offset,value,be))
                or not 0<=address<=0xffffffff or not 0<=offset<self._window or offset%4
                or not 0<=value<=0xffffffff or not write and value!=0 or be!=15 or self._storage_active_context is not None
                or self.process is None or self.process.poll() is not None):
            raise ValueError('storage-routed-access-context-invalid')
        expected=dict(source_transaction=asdict(source_transaction),address=address,offset=offset,
            write=write,value=value,be=be)
        keys=set(expected)|{'device_id','window_base','window_size'}
        if (type(delivery_context) is not dict or set(delivery_context)!=keys
                or type(delivery_context['device_id']) is not str or not delivery_context['device_id']
                or type(delivery_context['window_base']) is not int or not 0<=delivery_context['window_base']<=0xffffffff
                or type(delivery_context['window_size']) is not int or delivery_context['window_size']!=self._window
                or address!=delivery_context['window_base']+offset
                or delivery_context['window_base']+self._window>1<<32
                or json.dumps({k:delivery_context[k] for k in expected},sort_keys=True,allow_nan=False)!=json.dumps(expected,sort_keys=True,allow_nan=False)):
            raise ValueError('storage-routed-delivery-mismatch')
        self._storage_active_context=deepcopy({**delivery_context,
            'execution':self._execution,'reset_epoch':self.reset_epoch,'command_sequence':self._sequence+1,
            'schema_version':'apb_storage_routed_context.v1','source_authenticated':False})
        try:
            from myfuzz.scenario.apb_storage_register_version import validate_routed_context
            validate_routed_context(self._storage_active_context,operation=self.access_operation,
                fields=(int(write),offset,value,be),sequence=self._sequence+1,execution=self._execution,epoch=self.reset_epoch,window=self._window)
            reply=self.command(self.access_operation,(int(write),offset,value if write else 0,be))
            result=self._take(reply)
            if result['error']:raise RuntimeError('actual storage APB error')
            access_id=f'apb-storage:{self._execution}:{reply.sequence}'
            self._storage_last_access=(source_transaction,access_id)
            return dict(rdata=result['rdata'],target_access_id=access_id,
                target_context_schema_version='apb_storage_routed_context.v1',source_authenticated=False)
        except BaseException:
            from .session import _revoke_storage_versions
            _revoke_storage_versions(self)
            raise
        finally:
            self._storage_active_context=None

    def routed_delivery_failed(self, source_transaction, access_id):
        from .session import _revoke_storage_versions
        # A source delivery failure cannot preserve an issuer scope. Context
        # remains correlation only; this hook never certifies a successful source.
        _revoke_storage_versions(self)
        if self._storage_last_access != (source_transaction,access_id):
            raise ValueError('storage-routed-terminal-context-mismatch')
        self._storage_last_access=None

    def identity_document(self):
        return {**super().identity_document(),
                'apb3_register_service_schema_version': 'generated_apb3_register_observe.v1',
                'setup_writes': [list(row) for row in self.setup_writes],
                'probe_offsets': list(self.probe_offsets),
                'dynamic_input_initial_policy': 'zero_until_first_source_event',
                'bound_input_initial_policy': 'zero_until_first_real_output'}

    def validate_scenario_ownership(self, component_id, ownership):
        """Require the ScenarioRunner's bit owners to match this physical ABI."""
        document = ownership.document()
        fields = {row['port']: row['width'] for row in document['fields']
                  if row['component_id'] == component_id}
        expected = {row['input_name']: row for row in
                    self.artifact.runtime_document['dynamic_physical_inputs']}
        bound = {row['input_name']: row for row in
                 self.artifact.runtime_document['bound_physical_inputs']}
        fixed = {row['endpoint_id'] + '.' + row['role'] for row in
                 self.artifact.runtime_document['fixed_physical_inputs']}
        if set(fields) != set(expected) | set(bound) | fixed:
            raise ValueError(f'{self.transport_error_label} scenario ownership fields mismatch physical inputs')
        for name, width in fields.items():
            expected_width = (expected[name]['width'] if name in expected else
                              bound[name]['width'] if name in bound else next(
                row['width'] for row in self.artifact.runtime_document['fixed_physical_inputs']
                if row['endpoint_id'] + '.' + row['role'] == name))
            if width != expected_width:
                raise ValueError(f'{self.transport_error_label} scenario ownership width mismatch')
            bits = [None] * width
            for owner in document['owners']:
                if owner['component_id'] != component_id or owner['port'] != name:
                    continue
                kind = 'source' if name in expected else 'bound' if name in bound else 'fixed'
                identity = (expected[name]['source_id'] if name in expected else
                            bound[name]['producer_ref'] if name in bound else
                            'profile_constant')
                if owner['kind'] != kind or owner['producer_ref'] != identity:
                    raise ValueError(f'{self.transport_error_label} source identity or fixed ownership mismatch')
                for bit in range(owner['bit_offset'], owner['bit_offset'] + owner['width']):
                    if bit >= width or bits[bit] is not None:
                        raise ValueError(f'{self.transport_error_label} overlapping scenario input ownership')
                    bits[bit] = owner['producer_ref']
            if any(bit is None for bit in bits):
                raise ValueError(f'{self.transport_error_label} incomplete scenario input ownership')

    def validate_scenario_bindings(self, component_id, bindings):
        """A declared bound field needs one whole-field real output route."""
        for row in bindings:
            if row.source_component == component_id:
                observed = self._outputs.get(row.source_port)
                if observed is None or row.source_bit_offset + row.width > observed[1]:
                    raise ValueError(f'{self.transport_error_label} route source is not an observed RTL output')
        for name, (_, width, producer_ref) in self._bound.items():
            routes = [row for row in bindings if row.target_component == component_id
                      and row.target_port == name]
            if (len(routes) != 1 or routes[0].target_bit_offset != 0 or
                    routes[0].width != width or
                    f'{routes[0].source_component}.{routes[0].source_port}' != producer_ref):
                raise ValueError(f'{self.transport_error_label} bound input lacks exact real output route')

    def begin_case(self, testcase_id):
        if self._storage_startup_failure is not None:
            # A lost or malformed startup page is permanently uncertain: never
            # retry it on a fresh execution or a later sequence.
            raise ValueError('storage startup scope is permanently poisoned')
        self._storage_startup_complete = False
        self._storage_startup_receipts.clear()
        self._storage_startup_last_receipt = None
        self._storage_startup_bytes = 0
        retrieval_started = False
        try:
            super().begin_case(testcase_id)
            self._started = False
            self._samples.clear()
            self.local_transactions.clear()
            self._dynamic_values = {name: 0 for name in self._dynamic}
            self._bound_values = {name: 0 for name in self._bound}
            if self._storage_startup_required:
                retrieval_started = True
                self._read_storage_startup_pages()
        except BaseException as primary:
            if retrieval_started:
                self._record_storage_startup_failure(primary)
                try:
                    self._abort()
                except BaseException as cleanup:
                    primary.add_note('storage startup cleanup failure: ' + repr(cleanup))
            raise

    def command(self, operation, fields):
        if operation == 'READ_APB_STORAGE_STARTUP':
            if (not self._storage_startup_required
                    or not self._storage_startup_retrieving
                    or self._storage_startup_complete
                    or self._storage_startup_failure is not None):
                raise ValueError('storage startup retrieval is not active')
        elif self._storage_startup_required and not self._storage_startup_complete:
            raise ValueError('storage startup pages are incomplete')
        return super().command(operation, fields)

    def _read_storage_startup_pages(self):
        contract = self._storage_startup_contract
        self._storage_startup_retrieving = True
        try:
            for page_index in range(contract['page_count']):
                sequence = self._sequence + 1
                receipt = self.command('READ_APB_STORAGE_STARTUP', (page_index,))
                raw = self._last_wire_reply
                self._storage_startup_last_receipt = receipt
                self._storage_startup_receipts.append(dict(
                    page_index=page_index, sequence=sequence, receipt=receipt, raw=raw))
                self._validate_storage_startup_page(receipt, page_index, sequence)
                page = receipt.payload['observations']['storage_startup']
                self._storage_startup_bytes += len((raw or '').encode()) + len(
                    json.dumps(page, sort_keys=True, separators=(',', ':'),
                               allow_nan=False).encode())
                if (self._storage_startup_bytes >
                        self._storage_startup_contract['receipt_storage_bound_bytes']):
                    raise ValueError('storage startup capture budget exceeded')
        finally:
            self._storage_startup_retrieving = False
        self._storage_startup_complete = True

    def _validate_storage_startup_page(self, receipt, page_index, sequence):
        from .apb_storage_startup import validate_startup_page
        if (receipt.status != 'result' or receipt.payload is None
                or receipt.execution != self._execution or receipt.sequence != sequence
                or receipt.tick_before != 0 or receipt.tick_after != 0
                or receipt.new_ticks != 0):
            raise ValueError('storage startup receipt identity or tick mismatch')
        payload = receipt.payload
        if (payload['samples'] != [] or payload['kind'] != self.artifact_kind
                or set(payload['observations']) != {'storage_startup'}
                or payload['rdata'] != 0 or payload['error'] != 0):
            raise ValueError('storage startup payload mismatch')
        validate_startup_page(payload['observations']['storage_startup'],
                              self._storage_startup_contract,
                              expected_page=page_index,
                              ports=self._storage_startup_ports)

    def _record_storage_startup_failure(self, error):
        if self._storage_startup_failure is not None:
            return
        last = self._storage_startup_receipts[-1] if self._storage_startup_receipts else None
        self._storage_startup_failure = dict(
            schema_version='apb_storage_startup_host_failure.v1',
            stage='retrieval', possible_effects=True, effect_certainty='unknown',
            error=type(error).__name__ + ': ' + str(error),
            raw_reply=self._last_wire_reply,
            last_page_index=None if last is None else last['page_index'],
            last_sequence=None if last is None else last['sequence'],
            retained_receipts=list(self._storage_startup_receipts),
            authority='observation_only', reset_authority=False,
            version_authority=False, source_authority=False,
            grants_reset_prerequisite=False)

    @property
    def pending_responses(self):
        return 0

    @property
    def routed_input_names(self):
        return frozenset(self._bound)

    @property
    def pending_events(self):
        return 0

    def begin_quiesce(self):
        if self.process is None or self.process.poll() is not None:
            raise RuntimeError(f'{self.transport_error_label} process is not running')

    def max_transaction_events_for_step(self, inputs):
        return 0 if self._started else len(self.setup_writes) + len(self.probe_offsets)

    def _take(self, reply, *, step=False):
        try:
            return self._take_impl(reply, step=step)
        except BaseException:
            if self._native_reset_observation is not None:
                self._native_reset_observation._consumer_failed(self, 'apb_take_failed_after_parse')
            raise

    def _take_impl(self, reply, *, step=False):
        if reply.status != 'result' or reply.payload is None:
            raise RuntimeError(f'{self.transport_error_label} transport error: ' + str(reply.error_code))
        payload = reply.payload
        samples = payload['samples']
        if (not 1 <= len(samples) <= self.max_local_ticks_per_register_access or
                step and len(samples) != 1 or len(self._samples) + len(samples) > 65536):
            raise ValueError(f'invalid {self.transport_error_label} tick evidence')
        for sample in samples:
            phases = {}
            for phase in ('pre', 'post'):
                observed = dict(sample[phase])
                physical_sample = observed['physical']
                for name, (runtime_name, width) in self._outputs.items():
                    value = physical_sample[runtime_name]
                    if width > 64 and type(value) is str:
                        value = int(value, 16)
                    if type(value) is not int or not 0 <= value < 1 << width:
                        raise ValueError(f'invalid {self.transport_error_label} tick output: ' + name)
                    observed[name] = value
                phases[phase] = observed
            self._samples.append({**sample, **phases,
                                  'local_tick': self._tick_base + sample['local_tick']})
        physical = payload['observations']['physical']
        observations = {}
        for name, (runtime_name, width) in self._outputs.items():
            value = physical[runtime_name]
            if width > 64 and type(value) is str:
                value = int(value, 16)
            if type(value) is not int or not 0 <= value < 1 << width:
                raise ValueError(f'invalid {self.transport_error_label} physical observation: ' + name)
            observations[name] = value
        observations['rdata'] = payload['rdata']
        observations['error'] = payload['error']
        return observations

    def drain_tick_samples(self):
        samples = list(self._samples)
        self._samples.clear()
        return samples

    def _access(self, write, offset, value=0, be=15):
        if (type(offset) is not int or offset % 4 or not 0 <= offset < self._window or
                type(value) is not int or not 0 <= value <= 0xffffffff or
                type(be) is not int or be != 15):
            raise ValueError(f'invalid {self.transport_error_label} access')
        result = self._take(self.command(self.access_operation,
                                         (int(write), offset, value, be)))
        if result['error']:
            raise RuntimeError(f'{self.error_response_label} error at offset {offset:#x}')
        return result['rdata']

    def write_register(self, offset, value, *, be=15):
        self._access(True, offset, value, be)

    def read_register(self, offset):
        return self._access(False, offset)

    def step_local(self, inputs: Mapping[str, int]):
        return self._step_with_inputs(inputs, {})

    def step_local_routed(self, source_inputs: Mapping[str, int],
                          bound_inputs: Mapping[str, int]):
        """ScenarioRunner supplies only values captured from declared real bindings."""
        return self._step_with_inputs(source_inputs, bound_inputs)

    def _step_with_inputs(self, inputs: Mapping[str, int], bound_inputs: Mapping[str, int]):
        if not isinstance(inputs, Mapping) or set(inputs) - set(self._dynamic):
            raise ValueError(f'{self.transport_error_label} undeclared or fixed input cannot be overwritten')
        if not isinstance(bound_inputs, Mapping) or set(bound_inputs) - set(self._bound):
            raise ValueError(f'{self.transport_error_label} undeclared routed bound input')
        for name, value in inputs.items():
            _, width, _ = self._dynamic[name]
            if type(value) is not int or not 0 <= value < 1 << width:
                raise ValueError(f'{self.transport_error_label} dynamic source value exceeds physical width')
        for name, value in bound_inputs.items():
            _, width, _ = self._bound[name]
            if type(value) is not int or not 0 <= value < 1 << width:
                raise ValueError(f'{self.transport_error_label} routed bound value exceeds physical width')
        probes = {}
        if not self._started:
            self._started = True
            for offset, value in self.setup_writes:
                self.write_register(offset, value)
                self.local_transactions.append(dict(offset=offset, write=True,
                    write_value=value, byte_enable=15))
            for offset in self.probe_offsets:
                read_value = self.read_register(offset)
                self.local_transactions.append(dict(offset=offset, write=False,
                    read_value=read_value))
                probes[f'reg_{offset:03x}'] = read_value
        for name in sorted(inputs):
            value = inputs[name]
            if self._dynamic_values[name] != value:
                index, _, _ = self._dynamic[name]
                self._take(self.command(self.source_operation, (index, value)))
                self._dynamic_values[name] = value
        for name in sorted(bound_inputs):
            value = bound_inputs[name]
            if self._bound_values[name] != value:
                index, _, _ = self._bound[name]
                self._take(self.command(self.bind_operation, (index, value)))
                self._bound_values[name] = value
        return {**self._take(self.command(self.step_operation, ()), step=True), **probes}

    def reset_local(self):
        result = super().reset_local()
        self._started = False
        self._samples.clear()
        self.local_transactions.clear()
        self._dynamic_values = {name: 0 for name in self._dynamic}
        self._bound_values = {name: 0 for name in self._bound}
        return result

# Exact declaration/resolved code baseline established at class definition time.
from types import MappingProxyType as _ResetMappingProxyType
_NATIVE_RESET_APB_CLASS = GeneratedApb3RegisterSession
_NATIVE_RESET_APB_DECLARATIONS = _ResetMappingProxyType(dict(vars(GeneratedApb3RegisterSession)))
_NATIVE_RESET_APB_DECLARATIONS_PIN = _NATIVE_RESET_APB_DECLARATIONS
_NATIVE_RESET_APB_RESOLVED = _ResetMappingProxyType({name: (getattr(GeneratedApb3RegisterSession,name), getattr(GeneratedApb3RegisterSession,name).__code__)
    for name in dir(GeneratedApb3RegisterSession) if hasattr(getattr(GeneratedApb3RegisterSession,name), '__code__')})
_NATIVE_RESET_APB_RESOLVED_PIN = _NATIVE_RESET_APB_RESOLVED

from .native_reset_producer_contract import _seal_code_owned_producer
_seal_code_owned_producer(GeneratedApb3RegisterSession)
