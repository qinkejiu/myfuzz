module local_runtime_uart (
  input logic [0:0] clk,
  input logic [0:0] reset,
  output logic [1:0] rt_lh_p_10_1_0,
  input logic [0:0] rt_lh_p_11_0_0,
  output logic [0:0] rt_lh_p_12_0_0,
  output logic [0:0] rt_lh_p_13_0_0,
  output logic [0:0] rt_lh_p_25_0_0,
  output logic [0:0] rt_lh_p_26_0_0,
  output logic [0:0] rt_lh_p_27_0_0,
  output logic [0:0] rt_lh_p_28_0_0,
  output logic [0:0] rt_lh_p_29_0_0,
  output logic [0:0] rt_lh_p_30_0_0,
  output logic [0:0] rt_lh_p_31_0_0,
  output logic [0:0] rt_lh_p_32_0_0,
  output logic [0:0] rt_lh_p_33_0_0,
  output logic [0:0] rt_lh_p_34_0_0,
  output logic [36:0] rt_lh_p_35_36_0,
  input logic [0:0] uart_req_valid,
  output logic [0:0] uart_req_ready,
  input logic [0:0] uart_req_write,
  input logic [31:0] uart_req_addr,
  input logic [31:0] uart_req_wdata,
  input logic [3:0] uart_req_be,
  output logic [0:0] uart_rsp_valid,
  input logic [0:0] uart_rsp_ready,
  output logic [31:0] uart_rsp_rdata,
  output logic [0:0] uart_rsp_error
);
  logic [31:0] link_lh_p_0_31_0;
  logic [31:0] link_lh_p_1_31_0;
  logic [3:0] link_lh_p_2_3_0;
  logic [2:0] link_lh_p_3_2_0;
  logic [2:0] link_lh_p_4_2_0;
  logic [0:0] link_lh_p_5_0_0;
  logic [1:0] link_lh_p_6_1_0;
  logic [7:0] link_lh_p_7_7_0;
  logic [22:0] link_lh_p_8_22_0;
  logic [0:0] link_lh_p_9_0_0;
  logic [31:0] link_lh_p_15_31_0;
  logic [0:0] link_lh_p_16_0_0;
  logic [2:0] link_lh_p_17_2_0;
  logic [2:0] link_lh_p_18_2_0;
  logic [0:0] link_lh_p_19_0_0;
  logic [0:0] link_lh_p_20_0_0;
  logic [1:0] link_lh_p_21_1_0;
  logic [7:0] link_lh_p_22_7_0;
  logic [13:0] link_lh_p_23_13_0;
  logic [0:0] link_lh_p_24_0_0;
  local_uart u_component (
    .clk(clk),
    .reset(reset),
    .lh_p_0_31_0(link_lh_p_0_31_0),
    .lh_p_1_31_0(link_lh_p_1_31_0),
    .lh_p_2_3_0(link_lh_p_2_3_0),
    .lh_p_3_2_0(link_lh_p_3_2_0),
    .lh_p_4_2_0(link_lh_p_4_2_0),
    .lh_p_5_0_0(link_lh_p_5_0_0),
    .lh_p_6_1_0(link_lh_p_6_1_0),
    .lh_p_7_7_0(link_lh_p_7_7_0),
    .lh_p_8_22_0(link_lh_p_8_22_0),
    .lh_p_9_0_0(link_lh_p_9_0_0),
    .lh_p_10_1_0(rt_lh_p_10_1_0),
    .lh_p_11_0_0(rt_lh_p_11_0_0),
    .lh_p_12_0_0(rt_lh_p_12_0_0),
    .lh_p_13_0_0(rt_lh_p_13_0_0),
    .lh_p_15_31_0(link_lh_p_15_31_0),
    .lh_p_16_0_0(link_lh_p_16_0_0),
    .lh_p_17_2_0(link_lh_p_17_2_0),
    .lh_p_18_2_0(link_lh_p_18_2_0),
    .lh_p_19_0_0(link_lh_p_19_0_0),
    .lh_p_20_0_0(link_lh_p_20_0_0),
    .lh_p_21_1_0(link_lh_p_21_1_0),
    .lh_p_22_7_0(link_lh_p_22_7_0),
    .lh_p_23_13_0(link_lh_p_23_13_0),
    .lh_p_24_0_0(link_lh_p_24_0_0),
    .lh_p_25_0_0(rt_lh_p_25_0_0),
    .lh_p_26_0_0(rt_lh_p_26_0_0),
    .lh_p_27_0_0(rt_lh_p_27_0_0),
    .lh_p_28_0_0(rt_lh_p_28_0_0),
    .lh_p_29_0_0(rt_lh_p_29_0_0),
    .lh_p_30_0_0(rt_lh_p_30_0_0),
    .lh_p_31_0_0(rt_lh_p_31_0_0),
    .lh_p_32_0_0(rt_lh_p_32_0_0),
    .lh_p_33_0_0(rt_lh_p_33_0_0),
    .lh_p_34_0_0(rt_lh_p_34_0_0),
    .lh_p_35_36_0(rt_lh_p_35_36_0)
  );
  beat_to_tlul #(
    .ADDRESS_WIDTH(32), .DATA_WIDTH(32), .SIZE_WIDTH(2),
    .SOURCE_WIDTH(8), .SINK_WIDTH(1), .USER_WIDTH(23),
    .DUSER_WIDTH(14), .GEN_INTEGRITY(1), .SOURCE_ID(0),
    .MAX_WAIT_CYCLES(16), .WINDOW_BASE(32'd0), .WINDOW_SIZE(4096)
  ) u_adapter_uart (
    .clk(clk),
    .reset(reset),
    .req_valid(uart_req_valid),
    .req_ready(uart_req_ready),
    .write(uart_req_write),
    .addr(uart_req_addr),
    .wdata(uart_req_wdata),
    .be(uart_req_be),
    .rsp_valid(uart_rsp_valid),
    .rsp_ready(uart_rsp_ready),
    .rdata(uart_rsp_rdata),
    .error(uart_rsp_error),
    .a_address(link_lh_p_0_31_0),
    .a_data(link_lh_p_1_31_0),
    .a_mask(link_lh_p_2_3_0),
    .a_opcode(link_lh_p_3_2_0),
    .a_param(link_lh_p_4_2_0),
    .a_ready(link_lh_p_5_0_0),
    .a_size(link_lh_p_6_1_0),
    .a_source(link_lh_p_7_7_0),
    .a_user(link_lh_p_8_22_0),
    .a_valid(link_lh_p_9_0_0),
    .d_data(link_lh_p_15_31_0),
    .d_error(link_lh_p_16_0_0),
    .d_opcode(link_lh_p_17_2_0),
    .d_param(link_lh_p_18_2_0),
    .d_ready(link_lh_p_19_0_0),
    .d_sink(link_lh_p_20_0_0),
    .d_size(link_lh_p_21_1_0),
    .d_source(link_lh_p_22_7_0),
    .d_user(link_lh_p_23_13_0),
    .d_valid(link_lh_p_24_0_0)
  );
endmodule
