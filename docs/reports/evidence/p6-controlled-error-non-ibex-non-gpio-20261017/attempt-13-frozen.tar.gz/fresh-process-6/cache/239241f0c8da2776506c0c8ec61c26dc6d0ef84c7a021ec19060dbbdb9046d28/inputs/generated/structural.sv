module local_uart (
  input logic clk,
  input logic reset,
  input logic [31:0] lh_p_0_31_0,
  input logic [31:0] lh_p_1_31_0,
  input logic [3:0] lh_p_2_3_0,
  input logic [2:0] lh_p_3_2_0,
  input logic [2:0] lh_p_4_2_0,
  output logic [0:0] lh_p_5_0_0,
  input logic [1:0] lh_p_6_1_0,
  input logic [7:0] lh_p_7_7_0,
  input logic [22:0] lh_p_8_22_0,
  input logic [0:0] lh_p_9_0_0,
  output logic [1:0] lh_p_10_1_0,
  input logic [0:0] lh_p_11_0_0,
  output logic [0:0] lh_p_12_0_0,
  output logic [0:0] lh_p_13_0_0,
  output logic [31:0] lh_p_15_31_0,
  output logic [0:0] lh_p_16_0_0,
  output logic [2:0] lh_p_17_2_0,
  output logic [2:0] lh_p_18_2_0,
  input logic [0:0] lh_p_19_0_0,
  output logic [0:0] lh_p_20_0_0,
  output logic [1:0] lh_p_21_1_0,
  output logic [7:0] lh_p_22_7_0,
  output logic [13:0] lh_p_23_13_0,
  output logic [0:0] lh_p_24_0_0,
  output logic [0:0] lh_p_25_0_0,
  output logic [0:0] lh_p_26_0_0,
  output logic [0:0] lh_p_27_0_0,
  output logic [0:0] lh_p_28_0_0,
  output logic [0:0] lh_p_29_0_0,
  output logic [0:0] lh_p_30_0_0,
  output logic [0:0] lh_p_31_0_0,
  output logic [0:0] lh_p_32_0_0,
  output logic [0:0] lh_p_33_0_0,
  output logic [0:0] lh_p_34_0_0,
  output logic [36:0] lh_p_35_36_0
);
  logic [31:0] dut_p_0;
  assign dut_p_0[31:0] = lh_p_0_31_0;
  logic [31:0] dut_p_1;
  assign dut_p_1[31:0] = lh_p_1_31_0;
  logic [3:0] dut_p_2;
  assign dut_p_2[3:0] = lh_p_2_3_0;
  logic [2:0] dut_p_3;
  assign dut_p_3[2:0] = lh_p_3_2_0;
  logic [2:0] dut_p_4;
  assign dut_p_4[2:0] = lh_p_4_2_0;
  logic [0:0] dut_p_5;
  assign lh_p_5_0_0 = dut_p_5[0:0];
  logic [1:0] dut_p_6;
  assign dut_p_6[1:0] = lh_p_6_1_0;
  logic [7:0] dut_p_7;
  assign dut_p_7[7:0] = lh_p_7_7_0;
  logic [22:0] dut_p_8;
  assign dut_p_8[22:0] = lh_p_8_22_0;
  logic [0:0] dut_p_9;
  assign dut_p_9[0:0] = lh_p_9_0_0;
  logic [1:0] dut_p_10;
  assign lh_p_10_1_0 = dut_p_10[1:0];
  logic [0:0] dut_p_11;
  assign dut_p_11[0:0] = lh_p_11_0_0;
  logic [0:0] dut_p_12;
  assign lh_p_12_0_0 = dut_p_12[0:0];
  logic [0:0] dut_p_13;
  assign lh_p_13_0_0 = dut_p_13[0:0];
  logic [0:0] dut_p_14;
  assign dut_p_14[0:0] = clk;
  logic [31:0] dut_p_15;
  assign lh_p_15_31_0 = dut_p_15[31:0];
  logic [0:0] dut_p_16;
  assign lh_p_16_0_0 = dut_p_16[0:0];
  logic [2:0] dut_p_17;
  assign lh_p_17_2_0 = dut_p_17[2:0];
  logic [2:0] dut_p_18;
  assign lh_p_18_2_0 = dut_p_18[2:0];
  logic [0:0] dut_p_19;
  assign dut_p_19[0:0] = lh_p_19_0_0;
  logic [0:0] dut_p_20;
  assign lh_p_20_0_0 = dut_p_20[0:0];
  logic [1:0] dut_p_21;
  assign lh_p_21_1_0 = dut_p_21[1:0];
  logic [7:0] dut_p_22;
  assign lh_p_22_7_0 = dut_p_22[7:0];
  logic [13:0] dut_p_23;
  assign lh_p_23_13_0 = dut_p_23[13:0];
  logic [0:0] dut_p_24;
  assign lh_p_24_0_0 = dut_p_24[0:0];
  logic [0:0] dut_p_25;
  assign lh_p_25_0_0 = dut_p_25[0:0];
  logic [0:0] dut_p_26;
  assign lh_p_26_0_0 = dut_p_26[0:0];
  logic [0:0] dut_p_27;
  assign lh_p_27_0_0 = dut_p_27[0:0];
  logic [0:0] dut_p_28;
  assign lh_p_28_0_0 = dut_p_28[0:0];
  logic [0:0] dut_p_29;
  assign lh_p_29_0_0 = dut_p_29[0:0];
  logic [0:0] dut_p_30;
  assign lh_p_30_0_0 = dut_p_30[0:0];
  logic [0:0] dut_p_31;
  assign lh_p_31_0_0 = dut_p_31[0:0];
  logic [0:0] dut_p_32;
  assign lh_p_32_0_0 = dut_p_32[0:0];
  logic [0:0] dut_p_33;
  assign lh_p_33_0_0 = dut_p_33[0:0];
  logic [0:0] dut_p_34;
  assign lh_p_34_0_0 = dut_p_34[0:0];
  logic [36:0] dut_p_35;
  assign lh_p_35_36_0 = dut_p_35[36:0];
  logic [0:0] dut_p_36;
  assign dut_p_36[0:0] = ~reset;
  soc_opentitan_uart_local_target u_dut (
    .a_address_i(dut_p_0),
    .a_data_i(dut_p_1),
    .a_mask_i(dut_p_2),
    .a_opcode_i(dut_p_3),
    .a_param_i(dut_p_4),
    .a_ready_o(dut_p_5),
    .a_size_i(dut_p_6),
    .a_source_i(dut_p_7),
    .a_user_i(dut_p_8),
    .a_valid_i(dut_p_9),
    .alert_tx_o(dut_p_10),
    .cio_rx_i(dut_p_11),
    .cio_tx_en_o(dut_p_12),
    .cio_tx_o(dut_p_13),
    .clk_i(dut_p_14),
    .d_data_o(dut_p_15),
    .d_error_o(dut_p_16),
    .d_opcode_o(dut_p_17),
    .d_param_o(dut_p_18),
    .d_ready_i(dut_p_19),
    .d_sink_o(dut_p_20),
    .d_size_o(dut_p_21),
    .d_source_o(dut_p_22),
    .d_user_o(dut_p_23),
    .d_valid_o(dut_p_24),
    .intr_rx_break_err_o(dut_p_25),
    .intr_rx_frame_err_o(dut_p_26),
    .intr_rx_overflow_o(dut_p_27),
    .intr_rx_parity_err_o(dut_p_28),
    .intr_rx_timeout_o(dut_p_29),
    .intr_rx_watermark_o(dut_p_30),
    .intr_tx_done_o(dut_p_31),
    .intr_tx_empty_o(dut_p_32),
    .intr_tx_watermark_o(dut_p_33),
    .lsio_trigger_o(dut_p_34),
    .racl_error_o(dut_p_35),
    .rst_ni(dut_p_36)
  );
endmodule
