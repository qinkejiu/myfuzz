"""Generate bounded C++ transport around an admitted, complete runtime top."""
from __future__ import annotations

import copy
from dataclasses import replace
import hashlib
import json
from pathlib import Path

from .renderer import _sha
from .runtime_artifact import LocalRuntimeArtifact
from .session import registered_operations
from .runtime_renderer import render_local_runtime
from .wishbone_dma_fields import DMA_CONTROL_SHAPE, DMA_MASTER_SHAPE, DMA_STEP_PORTS
from .axi4_fields import AXI_STEP_PORTS
from .cva6_axi4_fields import CVA6_AXI_STEP_PORTS
from .vexii_axi_fields import STEP_PORTS as REDUCED_AXI_STEP_PORTS

_HEADERS = ('src/myfuzz/local_harness/rtl/local_driver_v1.h',
            'src/myfuzz/scenario/rtl/local_command_replay.h')
_DMA_HEADER = 'src/myfuzz/local_harness/rtl/wishbone_dma_edge.h'
_SPI_HEADER = 'src/myfuzz/local_harness/rtl/pulp_spi_mode0_peer.h'
_I2C_HEADER = 'src/myfuzz/local_harness/rtl/pulp_i2c_single_slave_peer.h'
_OT_I2C_HEADER = 'src/myfuzz/local_harness/rtl/opentitan_i2c_single_slave_peer.h'


def _literal(value: str) -> str:
    return json.dumps(value, ensure_ascii=True)


def render_local_driver(artifact: LocalRuntimeArtifact, *, base_dir: Path) -> LocalRuntimeArtifact:
    """Return new driver bytes/identity without changing the admitted runtime top.

    The final digest is injected as the bare lowercase-hex compile definition
    MYFUZZ_ARTIFACT_DIGEST and stringified by C++; embedding it in these bytes
    would create a circular digest. Builder admission must refresh header hashes.
    """
    if not isinstance(artifact, LocalRuntimeArtifact):
        raise ValueError('driver-artifact-required')
    if artifact.runtime_document.get('status') != 'top_only' or artifact.cpp_text:
        raise ValueError('driver-top-only-required')
    root = Path(base_dir).resolve()
    refreshed = render_local_runtime(artifact.plan, artifact.structural,
                                    artifact.source_verification, base_dir=root)
    if refreshed != artifact:
        raise ValueError('driver-runtime-identity-mismatch')
    document = copy.deepcopy(artifact.runtime_document)
    kind = document['kind']
    exports = document['physical_exports']
    backend = document['backend_ports']
    protocol_taps = document.get('protocol_tap_ports', [])
    storage_ports = document.get('storage_probe_ports', [])
    fields = {}
    if kind in ('tlul_register_observe', 'apb3_register_observe', 'wishbone_register_observe', 'axi4lite_register_observe', 'ahb_lite_register_observe'):
        fixed = document['fixed_physical_inputs']
        dynamic = document.get('dynamic_physical_inputs', [])
        bound = document.get('bound_physical_inputs', [])
        allowed_inputs = {row['runtime_name'] for row in fixed + dynamic + bound}
        if (len(allowed_inputs) != len(fixed) + len(dynamic) + len(bound) or
                len(dynamic) > 64 or len(bound) > 64 or
                any(row['value'] >= 1 << row['width'] for row in fixed) or
                any(not 1 <= row['width'] <= 64 for row in dynamic + bound)):
            raise ValueError('driver-register-input-ownership')
    elif kind == 'apb_gpio':
        for role, alias in [('in', 'gpio_in'), ('out', 'gpio_out'), ('dir', 'gpio_dir'),
                            ('in_sync', 'gpio_in_sync'), ('padcfg', 'gpio_padcfg')]:
            rows = [row for row in exports if row['role'] == role]
            if len(rows) != 1:
                raise ValueError('driver-gpio-field:' + role)
            fields[alias] = rows[0]['runtime_name']
        # Select the original official IRQ port; passive one-bit internal
        # probes remain ordinary exports and are never IRQ aliases.
        pulses = [row for row in exports if row['physical_port'] == 'interrupt'
                  and row['endpoint_id'] is None and row['disposition'] == 'observe'
                  and row['direction'] == 'output' and row['width'] == 1
                  and row['bit_lo'] == 0 and row['bit_hi'] == 0]
        if len(pulses) != 1:
            raise ValueError('driver-gpio-pulse-observation-required')
        fields['interrupt'] = pulses[0]['runtime_name']
        allowed_inputs = {fields['gpio_in']}
    elif kind == 'tlul_gpio':
        for role, alias in [('in', 'gpio_in'), ('out', 'gpio_out'),
                            ('en', 'gpio_dir'), ('strap_en', 'strap_en')]:
            rows = [row for row in exports if row['endpoint_id'] == 'gpio.pins' and row['role'] == role]
            if len(rows) != 1:
                raise ValueError('driver-tlul-pin-field:' + role)
            fields[alias] = rows[0]['runtime_name']
        irq = [row for row in exports if row['endpoint_id'] == 'gpio.interrupts'
               and row['role'] == 'irq' and row['width'] == 32 and row['direction'] == 'output']
        if len(irq) != 1:
            raise ValueError('driver-tlul-irq-field')
        fields['interrupt'] = irq[0]['runtime_name']
        allowed_inputs = {fields['gpio_in'], fields['strap_en']}
    elif kind == 'tlul_timer':
        irq = [row for row in exports if row['endpoint_id'] == 'timer.interrupts'
               and row['role'] == 'irq' and row['width'] == 1 and row['direction'] == 'output']
        if len(irq) != 1:
            raise ValueError('driver-tlul-timer-irq-field')
        fields['irq'] = irq[0]['runtime_name']
        allowed_inputs = set()
    elif kind == 'tlul_spi_host':
        for role, width in (('sd_i', 4), ('sck', 1), ('csb', 1),
                            ('sd_o', 4), ('sd_en', 4)):
            rows = [row for row in exports if row['endpoint_id'] == 'spi_host.pins'
                    and row['role'] == role and row['width'] == width]
            if len(rows) != 1:
                raise ValueError('driver-tlul-spi-host-pin:' + role)
            fields[role] = rows[0]['runtime_name']
        for role in ('event', 'error'):
            rows = [row for row in exports if row['endpoint_id'] == 'spi_host.interrupts'
                    and row['role'] == role and row['width'] == 1]
            if len(rows) != 1:
                raise ValueError('driver-tlul-spi-host-irq:' + role)
            fields['irq_' + role] = rows[0]['runtime_name']
        allowed_inputs = {fields['sd_i']}
    elif kind == 'tlul_uart':
        for role in ('rx', 'tx', 'tx_en'):
            rows = [row for row in exports if row['endpoint_id'] == 'uart.pins'
                    and row['role'] == role and row['width'] == 1]
            if len(rows) != 1:
                raise ValueError('driver-tlul-uart-pin-field:' + role)
            fields['uart_' + role] = rows[0]['runtime_name']
        for role in ('tx_watermark', 'tx_empty', 'rx_watermark', 'tx_done',
                     'rx_overflow', 'rx_frame_err', 'rx_break_err',
                     'rx_timeout', 'rx_parity_err'):
            rows = [row for row in exports if row['endpoint_id'] == 'uart.interrupts'
                    and row['role'] == role and row['width'] == 1]
            if len(rows) != 1:
                raise ValueError('driver-tlul-uart-irq-field:' + role)
            fields['uart_' + role] = rows[0]['runtime_name']
        allowed_inputs = {fields['uart_rx']}
    elif kind == 'wishbone_timer':
        irq = [row for row in exports if row['physical_port'] == 'o_int'
               and row['width'] == 1 and row['direction'] == 'output'
               and row['disposition'] == 'observe']
        if len(irq) != 1:
            raise ValueError('driver-timer-native-irq-required')
        fields['interrupt'] = irq[0]['runtime_name']
        allowed_inputs = set()
    elif kind == 'apb_spi':
        for role in ('sck', 'mode', *(f'csn{i}' for i in range(4)),
                     *(f'sdo{i}' for i in range(4)), *(f'sdi{i}' for i in range(4))):
            rows = [row for row in exports if row['endpoint_id'] == 'spi.pins' and row['role'] == role]
            if len(rows) != 1:
                raise ValueError('driver-spi-pin-field:' + role)
            fields['spi_' + ('clk' if role == 'sck' else role)] = rows[0]['runtime_name']
        events = [row for row in exports if row['physical_port'] == 'events_o'
                  and row['disposition'] == 'observe' and row['width'] == 2]
        if len(events) != 1:
            raise ValueError('driver-spi-native-events-required')
        fields['events_o'] = events[0]['runtime_name']
        allowed_inputs = {fields[f'spi_sdi{i}'] for i in range(4)}
    elif kind == 'apb_timer':
        events = [row for row in exports if row['physical_port'] == 'irq_o'
                  and row['disposition'] == 'observe' and row['direction'] == 'output'
                  and row['width'] == 4]
        if len(events) != 1:
            raise ValueError('driver-timer-native-events-required')
        fields['irq_o'] = events[0]['runtime_name']
        allowed_inputs = set()
    elif kind in ('axi4_lite_uart', 'wishbone_uart'):
        for role in ('rx', 'tx', 'cts_n', 'rts_n'):
            rows = [row for row in exports if row['endpoint_id'] == 'uart.pins'
                    and row['role'] == role and row['width'] == 1]
            if len(rows) != 1:
                raise ValueError('driver-axi-lite-uart-pin:' + role)
            fields['uart_' + role] = rows[0]['runtime_name']
        for role in ('rx', 'tx', 'rxfifo', 'txfifo'):
            rows = [row for row in exports if row['endpoint_id'] == 'uart.interrupts'
                    and row['role'] == role and row['width'] == 1]
            if len(rows) != 1:
                raise ValueError('driver-axi-lite-uart-interrupt:' + role)
            fields['uart_' + role + '_int'] = rows[0]['runtime_name']
        allowed_inputs = {fields['uart_rx'], fields['uart_cts_n']}
    elif kind == 'apb_i2c':
        for role in ('scl_pad_i', 'scl_pad_o', 'scl_padoen_o',
                     'sda_pad_i', 'sda_pad_o', 'sda_padoen_o'):
            rows = [row for row in exports if row['role'] == role]
            if len(rows) != 1 or rows[0]['width'] != 1:
                raise ValueError('driver-i2c-pin-field:' + role)
            fields[role] = rows[0]['runtime_name']
        irq = [row for row in exports if row['endpoint_id'] is None
               and row['disposition'] == 'observe' and row['direction'] == 'output'
               and row['width'] == 1]
        if len(irq) != 1:
            raise ValueError('driver-i2c-native-irq-required')
        fields['interrupt_o'] = irq[0]['runtime_name']
        allowed_inputs = {fields['scl_pad_i'], fields['sda_pad_i']}
    elif kind == 'tlul_i2c':
        for role in ('scl_i', 'scl_o', 'scl_en_o', 'sda_i', 'sda_o', 'sda_en_o'):
            rows = [row for row in exports if row['endpoint_id'] == 'i2c.pins'
                    and row['role'] == role and row['width'] == 1]
            if len(rows) != 1:
                raise ValueError('driver-tlul-i2c-pin:' + role)
            fields[role] = rows[0]['runtime_name']
        irq = [row for row in exports if row['endpoint_id'] == 'i2c.interrupts'
               and row['role'] == 'irq' and row['direction'] == 'output'
               and row['width'] == 15]
        if len(irq) != 1:
            raise ValueError('driver-tlul-i2c-native-irq-required')
        fields['irq_o'] = irq[0]['runtime_name']
        allowed_inputs = {fields['scl_i'], fields['sda_i']}
    elif kind == 'tlul_spi_device':
        for role, width in (('sck_i', 1), ('csb_i', 1), ('tpm_csb_i', 1),
                            ('sd_i', 4), ('sd_o', 4), ('sd_en_o', 4)):
            rows = [row for row in exports if row['endpoint_id'] == 'spi_device.pins'
                    and row['role'] == role and row['width'] == width]
            if len(rows) != 1:
                raise ValueError('driver-tlul-spi-device-pin:' + role)
            fields[role] = rows[0]['runtime_name']
        irq = [row for row in exports if row['endpoint_id'] == 'spi_device.interrupts'
               and row['role'] == 'irq' and row['direction'] == 'output'
               and row['width'] == 8]
        if len(irq) != 1:
            raise ValueError('driver-tlul-spi-device-irq')
        fields['irq_o'] = irq[0]['runtime_name']
        allowed_inputs = {fields[name] for name in ('sck_i', 'csb_i', 'tpm_csb_i', 'sd_i')}
    elif kind == 'wishbone_dma':
        expected = {prefix+'_'+role:(direction,width)
                    for prefix,shape in (('swb',DMA_CONTROL_SHAPE),('mwb',DMA_MASTER_SHAPE))
                    for role,(direction,width) in shape.items()}
        if (len(backend) != len(expected) or
                {row['name']:(row['direction'],row['width']) for row in backend} != expected):
            raise ValueError('driver-dma-backend-shape')
        irqs = [row for row in exports if row['role']=='irq'
                and row['direction']=='output' and row['width']==1]
        if len(irqs)!=1 or len(exports)!=1:
            raise ValueError('driver-dma-native-irq-required')
        fields['dma_irq'] = irqs[0]['runtime_name']
        allowed_inputs = set()
    elif kind == 'wishbone_cpu':
        cpu = artifact.plan.profile.cpu
        allowed_inputs = set()
        if cpu.irq_entry_endpoint is not None:
            irq = [row for row in exports if row['endpoint_id'] == cpu.irq_entry_endpoint
                   and row['role'] == cpu.irq_entry_role and row['direction'] == 'input'
                   and row['width'] == 32]
            if len(irq) != 1:
                raise ValueError('driver-wishbone-irq-field')
            fields['irq_custom'] = irq[0]['runtime_name']
            allowed_inputs = {fields['irq_custom']}
    elif kind == 'rvx_memory_cpu':
        expected = {'addr': ('output', 32), 'read_request': ('output', 1),
                    'read_response': ('input', 1), 'read_data': ('input', 32),
                    'write_request': ('output', 1), 'write_response': ('input', 1),
                    'write_data': ('output', 32), 'write_strobe': ('output', 4)}
        rows = {row['role']: row for row in backend if row['channel'] == 'rvx_memory'}
        if (len(rows) != len(backend) or set(rows) != set(expected) or
                any((row['direction'], row['width']) != expected[role]
                    or row['name'] != 'rvx_' + role
                    for role, row in rows.items())):
            raise ValueError('driver-rvx-memory-backend-shape')
        fields.update({role: row['name'] for role, row in rows.items()})
        allowed_inputs = set()
    elif kind in ('native_memory_cpu', 'axi4_lite_cpu', 'axi4_cpu', 'reduced_dual_axi_cpu', 'ahb_lite_cpu'):
        # AHB-Lite CPU (CVW) declares no interrupt entry, so nothing outside the
        # harness drives it; the program it runs comes from the beat memory face.
        allowed_inputs = set()
    elif kind == 'cva6_packed_axi4_cpu':
        cpu = artifact.plan.profile.cpu
        irq = [row for row in exports if row['endpoint_id'] == cpu.irq_entry_endpoint
               and row['role'] == cpu.irq_entry_role and row['direction'] == 'input'
               and row['width'] == 1]
        if len(irq) != 1:
            raise ValueError('driver-cva6-irq-field')
        fields['irq_external'] = irq[0]['runtime_name']
        timer_irq = [row for row in exports if row['physical_port'] == 'time_irq_i'
                     and row['direction'] == 'input' and row['width'] == 1
                     and row['disposition'] == 'fuzz']
        if len(timer_irq) != 1:
            raise ValueError('driver-cva6-timer-irq-field')
        fields['irq_timer'] = timer_irq[0]['runtime_name']
        allowed_inputs = {fields['irq_external'], fields['irq_timer']}
    elif kind == 'obi_cpu':
        cpu = artifact.plan.profile.cpu
        irq = [row for row in exports if row['endpoint_id'] == cpu.irq_entry_endpoint and
               row['role'] == cpu.irq_entry_role and row['direction'] == 'input' and row['width'] == 1]
        if len(irq) != 1:
            raise ValueError('driver-cpu-irq-field')
        fields['irq_external'] = irq[0]['runtime_name']
        allowed_inputs = {fields['irq_external']}
    else:
        raise ValueError('driver-runtime-kind')
    if {row['runtime_name'] for row in exports if row['direction'] == 'input'} != allowed_inputs:
        raise ValueError('driver-unmapped-physical-input')
    ports = document['runtime_ports']
    fixed_at_reset = ({row['runtime_name']: row['value']
                       for row in document['fixed_physical_inputs']}
                      if kind in ('tlul_register_observe', 'apb3_register_observe', 'wishbone_register_observe', 'axi4lite_register_observe', 'ahb_lite_register_observe') else {})
    initializers = '\n'.join(
        f'  dut.{row["name"]} = {fixed_at_reset.get(row["name"], 0)};'
        for row in ports if row['direction'] == 'input')
    if kind == 'wishbone_dma':
        initializers += '\n  dut.mwb_stall = 1;'
    if kind == 'tlul_uart':
        initializers += f'\n  dut.{fields["uart_rx"]} = 1;'
    if kind == 'tlul_spi_device':
        initializers += (f'\n  dut.{fields["csb_i"]} = 1;'
                         f'\n  dut.{fields["tpm_csb_i"]} = 1;')

    def signal(row, name_key='runtime_name'):
        name, width = row[name_key], row['width']
        return (f'quote(wide_hex(dut.{name}, {width}))' if width > 64
                else f'std::to_string(static_cast<std::uint64_t>(dut.{name}))')

    backend_items = ',\n'.join('    {' + _literal(row['name']) + ', ' + signal(row, 'name') + '}' for row in backend)
    physical_items = ',\n'.join('    {' + _literal(row['runtime_name']) + ', ' + signal(row) + '}' for row in exports)
    protocol_tap_entry = ('    {\"protocol_taps\", object({\n' + ',\n'.join(
        '      {' + _literal(row['name']) + ', ' + signal(row, 'name') + '}'
        for row in protocol_taps) + '\n    })},\n') if protocol_taps else ''
    if storage_ports:
        protocol_tap_entry += ('    {"storage_probes", object({\n' + ',\n'.join(
            '      {' + _literal(row['name']) + ', ' + signal(row, 'name') + '}'
            for row in storage_ports) + '\n    })},\n')
    aliases = ''
    if kind in ('apb_gpio', 'apb_spi', 'apb_timer', 'tlul_gpio', 'tlul_timer', 'tlul_spi_host',
                'tlul_uart', 'tlul_i2c', 'tlul_spi_device', 'wishbone_timer', 'wishbone_uart', 'axi4_lite_uart', 'apb_i2c'):
        by_name = {row['runtime_name']: row for row in exports}
        aliases = ''.join(f'  values[{_literal(alias)}] = {signal(by_name[name])};\n'
                          for alias, name in fields.items()
                          if (kind in ('apb_gpio', 'tlul_gpio') and alias not in ('gpio_in', 'strap_en'))
                          or kind == 'wishbone_timer'
                          or kind == 'apb_timer'
                          or kind == 'tlul_timer'
                          or (kind == 'tlul_spi_host' and alias != 'sd_i')
                          or (kind == 'tlul_uart' and alias != 'uart_rx')
                          or (kind == 'tlul_spi_host' and alias != 'sd_i')
                          or (kind == 'apb_spi' and (alias == 'events_o' or not alias.startswith('spi_sdi')))
                          or (kind in ('axi4_lite_uart', 'wishbone_uart')
                              and alias not in ('uart_rx', 'uart_cts_n'))
                          or kind in ('apb_i2c', 'tlul_i2c', 'tlul_spi_device'))

    max_wait = document['effective_max_wait_cycles']
    max_samples = (1 if kind in ('obi_cpu', 'native_memory_cpu', 'rvx_memory_cpu',
                                'wishbone_cpu', 'wishbone_dma', 'axi4_lite_cpu', 'axi4_cpu', 'reduced_dual_axi_cpu', 'ahb_lite_cpu',
                                'cva6_packed_axi4_cpu')
                   else 2 * max_wait + 5)
    # Conservative serialized upper bound, before issuing any command effects.
    maxima_backend = {row['name']: (1 << row['width']) - 1 for row in backend}
    maxima_physical = {row['runtime_name']: ('f' * row['hex_digits'] if row['width'] > 64
                                            else (1 << row['width']) - 1) for row in exports}
    maximum_snapshot = dict(backend=maxima_backend, physical=maxima_physical)
    if storage_ports:
        maximum_snapshot['storage_probes'] = {row['name']: (1 << row['width']) - 1 for row in storage_ports}
    if protocol_taps:
        maximum_snapshot['protocol_taps'] = {row['name']: (1 << row['width']) - 1
                                             for row in protocol_taps}
    for alias, name in fields.items():
        if ((kind in ('apb_gpio', 'tlul_gpio') and alias not in ('gpio_in', 'strap_en'))
                or kind == 'wishbone_timer'
                or kind == 'apb_timer'
                or kind == 'tlul_timer'
                or (kind == 'tlul_spi_host' and alias != 'sd_i')
                or (kind == 'tlul_uart' and alias != 'uart_rx')
                or (kind == 'tlul_spi_host' and alias != 'sd_i')
                or (kind == 'apb_spi' and (alias == 'events_o' or not alias.startswith('spi_sdi')))
                or (kind in ('axi4_lite_uart', 'wishbone_uart')
                    and alias not in ('uart_rx', 'uart_cts_n'))
                or kind in ('apb_i2c', 'tlul_i2c', 'tlul_spi_device')):
            maximum_snapshot[alias] = maxima_physical[name]
    snapshot_size = len(json.dumps(maximum_snapshot, sort_keys=True, separators=(',', ':')))
    # 128 bytes per sample exceeds its numeric tick and object delimiters;
    # 1024 covers root keys, pre_backend, RESULT identity, and terminal ERROR.
    reservation = 2 * (max_samples * (2 * snapshot_size + 128) +
                       snapshot_size + len(json.dumps(maxima_backend)) + 1024) + 512
    ahb_startup = None
    if kind == 'ahb_lite_cpu':
        from .ahb_startup import startup_contract
        ahb_startup = startup_contract(assert_ticks=artifact.plan.request.reset_assert_ticks,
            release_ticks=artifact.plan.request.reset_release_ticks,
            snapshot_max=maximum_snapshot)
        reservation = max(reservation, 2 * ahb_startup['page_json_bound_bytes'] + 512)
    storage_startup = None
    if 'storage_startup_selection' in document:
        from .apb_storage_startup import contract_for_snapshot
        storage_startup=contract_for_snapshot(document,maximum_snapshot,
            artifact.plan.request.reset_assert_ticks,artifact.plan.request.reset_release_ticks)
        reservation=max(reservation,2*storage_startup['page_json_bound_bytes']+512)
    if reservation > 2 * 1024 * 1024 + 512:
        raise ValueError('driver-result-reservation-too-large')

    if kind == 'axi4_lite_uart':
        dispatch = f'''      dut.{fields['uart_rx']} = command.fields[0];
      dut.{fields['uart_cts_n']} = command.fields[1];
      dut.eval();
      pre_backend = backend_snapshot(dut);
      if (command.operation == "STEP_AXIL_UART") {{
        tick(dut, &samples);
      }} else {{
        const bool write = command.fields[2] != 0;
        const unsigned address = command.fields[3];
        if (write) {{
          dut.axil_awaddr = address; dut.axil_awprot = 0; dut.axil_awvalid = 1;
          dut.axil_wdata = command.fields[4]; dut.axil_wstrb = command.fields[5];
          dut.axil_wvalid = 1; dut.axil_bready = 1;
          bool aw_done = false, w_done = false, b_done = false;
          for (unsigned waits = 0; waits < {2 * max_wait + 5}; ++waits) {{
            dut.eval();
            const bool aw = !aw_done && dut.axil_awvalid && dut.axil_awready;
            const bool w = !w_done && dut.axil_wvalid && dut.axil_wready;
            const bool b = aw_done && w_done && dut.axil_bvalid && dut.axil_bready;
            if (b) {{ error = dut.axil_bresp; b_done = true; }}
            tick(dut, &samples);
            if (aw) {{ aw_done = true; dut.axil_awvalid = 0; }}
            if (w) {{ w_done = true; dut.axil_wvalid = 0; }}
            if (b_done) break;
          }}
          dut.axil_bready = 0;
          if (!aw_done || !w_done || !b_done) throw std::runtime_error("axil_write_timeout");
        }} else {{
          dut.axil_araddr = address; dut.axil_arprot = 0; dut.axil_arvalid = 1;
          dut.axil_rready = 1;
          bool ar_done = false, r_done = false;
          for (unsigned waits = 0; waits < {2 * max_wait + 5}; ++waits) {{
            dut.eval();
            const bool ar = !ar_done && dut.axil_arvalid && dut.axil_arready;
            const bool r = ar_done && dut.axil_rvalid && dut.axil_rready;
            if (r) {{ rdata = dut.axil_rdata; error = dut.axil_rresp; r_done = true; }}
            tick(dut, &samples);
            if (ar) {{ ar_done = true; dut.axil_arvalid = 0; }}
            if (r_done) break;
          }}
          dut.axil_rready = 0;
          if (!ar_done || !r_done) throw std::runtime_error("axil_read_timeout");
        }}
        dut.eval();
      }}
'''
        operation_check = ('command.operation != "STEP_AXIL_UART" && '
                           'command.operation != "ACCESS_AXIL_UART"')
    elif kind == 'reduced_dual_axi_cpu':
        assignments = '\n'.join(f'      dut.{name} = command.fields[{index}];'
                                for index, name in enumerate(REDUCED_AXI_STEP_PORTS))
        dispatch = assignments + '''
      dut.eval();
      pre_backend = backend_snapshot(dut);
      tick(dut, &samples);
'''
        operation_check = 'command.operation != "STEP_REDUCED_AXI"'
    elif kind == 'axi4_cpu':
        assignments = '\n'.join(f'      dut.{name} = command.fields[{index}];'
                                for index, name in enumerate(AXI_STEP_PORTS))
        dispatch = assignments + '''
      dut.eval();
      pre_backend = backend_snapshot(dut);
      tick(dut, &samples);
'''
        operation_check = 'command.operation != "STEP_AXI4"'
    elif kind == 'cva6_packed_axi4_cpu':
        names = (fields['irq_external'], fields['irq_timer'], *CVA6_AXI_STEP_PORTS[2:])
        assignments = '\n'.join(f'      dut.{name} = command.fields[{index}];'
                                for index, name in enumerate(names))
        dispatch = assignments + '''
      dut.eval();
      pre_backend = backend_snapshot(dut);
      tick(dut, &samples);
'''
        operation_check = 'command.operation != "STEP_CVA6_AXI4"'
    elif kind == 'wishbone_dma':
        assignments = '\n'.join(f'      dut.{name} = command.fields[{index}];'
                                for index,name in enumerate(DMA_STEP_PORTS))
        dispatch = assignments + r'''
      dut.eval();
      pre_backend = backend_snapshot(dut);
      const char *dma_error = dma_edge_state.check(
          dut.mwb_cyc, dut.mwb_stb, dut.mwb_stall, dut.mwb_ack, dut.mwb_err,
          dut.swb_cyc, dut.swb_stb);
      if (dma_error) {
        terminal = error_reply(command.execution, command.sequence, local_ticks,
                               "protocol_environment", dma_error);
      } else {
        const bool accepted = dut.mwb_cyc && dut.mwb_stb && !dut.mwb_stall;
        const bool completed = dut.mwb_cyc && (dut.mwb_ack || dut.mwb_err);
        tick(dut, &samples);
        dma_edge_state.commit(accepted, completed);
      }
'''
        operation_check = 'command.operation != "STEP_WB_DMA"'
    elif kind == 'wishbone_cpu':
        dispatch = r'''      dut.wb_ack = command.fields[0];
      dut.wb_dat_r = command.fields[1];
      dut.eval();
      pre_backend = backend_snapshot(dut);
      if (dut.wb_ack && !(dut.wb_cyc && dut.wb_stb)) {
        terminal = error_reply(command.execution, command.sequence, local_ticks,
                               "protocol_environment", "wishbone_unsolicited_ack");
      } else {
        tick(dut, &samples);
      }
'''
        operation_check = 'command.operation != "STEP_WISHBONE"'
        if 'irq_custom' in fields:
            dispatch = f'      dut.{fields["irq_custom"]} = command.fields[2];\n' + dispatch
            operation_check = 'command.operation != "STEP_WISHBONE_IRQ"'
    elif kind == 'rvx_memory_cpu':
        expected = {'addr': ('output', 32), 'read_request': ('output', 1),
                    'read_response': ('input', 1), 'read_data': ('input', 32),
                    'write_request': ('output', 1), 'write_response': ('input', 1),
                    'write_data': ('output', 32), 'write_strobe': ('output', 4)}
        rows = {row['role']: row for row in backend if row['channel'] == 'rvx_memory'}
        if (len(rows) != len(backend) or set(rows) != set(expected) or
                any((row['direction'], row['width']) != expected[role]
                    or row['name'] != 'rvx_' + role
                    for role, row in rows.items())):
            raise ValueError('driver-rvx-memory-backend-shape')
        fields.update({role: row['name'] for role, row in rows.items()})
        allowed_inputs = set()
        dispatch = f'''      dut.{fields['read_response']} = command.fields[0];
      dut.{fields['write_response']} = command.fields[1];
      dut.{fields['read_data']} = command.fields[2];
      dut.eval();
      pre_backend = backend_snapshot(dut);
      tick(dut, &samples);
'''
        operation_check = 'command.operation != "STEP_RVX_MEMORY"'
    elif kind in ('native_memory_cpu', 'axi4_lite_cpu', 'ahb_lite_cpu'):
        # ahb_lite_cpu shares this template exactly: its adapter is instantiated
        # with the same 'm' beat channel as the other memory CPUs.
        beat = 'm_'
        dispatch = "\n".join(f'      dut.{name} = command.fields[{index}];' for index, name in enumerate([
            beat + 'req_ready', beat + 'rsp_valid', beat + 'rsp_rdata',
            beat + 'rsp_error'])) + r'''
      dut.eval();
      pre_backend = backend_snapshot(dut);
      if (@FAULT_CHECK@ || (dut.@BEAT@rsp_valid && !dut.@BEAT@rsp_ready)) {
        terminal = error_reply(command.execution, command.sequence, local_ticks,
                               "protocol_environment", "native_unsolicited_or_fault");
      } else {
        tick(dut, &samples);
        if (@FAULT_CHECK@) {
          terminal = error_reply(command.execution, command.sequence, local_ticks,
                                 "protocol_environment", "native_completion_fault");
        }
      }
'''
        dispatch = dispatch.replace('@BEAT@', beat)
        dispatch = dispatch.replace('@FAULT_CHECK@', 'dut.m_fault' if kind == 'native_memory_cpu' else 'false')
        operation_check = 'command.operation != "STEP_MEMORY"'
        if kind == 'ahb_lite_cpu':
            operation_check = '(command.operation != "STEP_MEMORY" && command.operation != "READ_AHB_STARTUP")'
            dispatch = (r'''      if (command.operation == "READ_AHB_STARTUP") {
        pre_backend = backend_snapshot(dut);
        if (local_ticks != 0 || command.fields[0] != ahb_startup_next_page) {
          terminal = error_reply(command.execution, command.sequence, local_ticks,
                                 "protocol_environment", "ahb_startup_page_order");
        } else {
          observations_override = object({{"ahb_startup", ahb_startup_page(command.fields[0])}});
        }
      } else if (ahb_startup_next_page != @PAGES@) {
        terminal = error_reply(command.execution, command.sequence, local_ticks,
                               "protocol_environment", "ahb_startup_incomplete");
      } else {
''' + dispatch + '\n      }').replace('@PAGES@', str(ahb_startup['page_count']))
    elif kind == 'obi_cpu':
        assignments = '\n'.join(f'      dut.{name} = command.fields[{index}];' for index, name in enumerate([
            fields['irq_external'], 'i_req_ready', 'i_rsp_valid', 'i_rsp_rdata', 'i_rsp_error',
            'd_req_ready', 'd_rsp_valid', 'd_rsp_rdata', 'd_rsp_error']))
        dispatch = assignments + '''
      dut.eval();
      pre_backend = backend_snapshot(dut);
      if ((dut.i_rsp_valid && !dut.i_rsp_ready) || (dut.d_rsp_valid && !dut.d_rsp_ready)) {
        terminal = error_reply(command.execution, command.sequence, local_ticks,
                               "protocol_environment", "unsolicited_response");
      } else {
        tick(dut, &samples);
      }
'''
        operation_check = 'command.operation != "STEP_CPU"'
    else:
        spi = kind == 'apb_spi'
        timer = kind in ('apb_timer', 'wishbone_timer', 'tlul_timer')
        channel = ('reg' if kind in ('tlul_register_observe', 'apb3_register_observe', 'wishbone_register_observe', 'axi4lite_register_observe', 'ahb_lite_register_observe') else
                   'spi' if spi else 'timer' if timer else
                   'uart' if kind == 'wishbone_uart' else
                   'spi_host' if kind == 'tlul_spi_host' else
                   'uart' if kind == 'tlul_uart' else
                   'i2c' if kind in ('apb_i2c', 'tlul_i2c') else
                   'spi_device' if kind == 'tlul_spi_device' else 'gpio')
        command_channel = ('WB_REG' if kind == 'wishbone_register_observe' else
                           'TLUL_REG' if kind == 'tlul_register_observe' else
                           'APB3_REG' if kind == 'apb3_register_observe' else
                           'AHB_REG' if kind == 'ahb_lite_register_observe' else
                           'AXIL_REG' if kind == 'axi4lite_register_observe' else
                           'TLUL_GPIO' if kind == 'tlul_gpio' else
                           'TLUL_TIMER' if kind == 'tlul_timer' else
                           'WB_UART' if kind == 'wishbone_uart' else
                           'TLUL_SPI_HOST' if kind == 'tlul_spi_host' else
                           'TLUL_UART' if kind == 'tlul_uart' else
                           'TLUL_I2C' if kind == 'tlul_i2c' else
                           'TLUL_SPI_DEVICE' if kind == 'tlul_spi_device' else
                           'WB_TIMER' if kind == 'wishbone_timer' else channel.upper())
        input_assignment = (f'      dut.{fields["gpio_in"]} = command.fields[0];\n'
                            if kind in ('apb_gpio', 'tlul_gpio') else '')
        if kind == 'tlul_gpio':
            input_assignment += f'      dut.{fields["strap_en"]} = command.fields[1];\n'
        if kind == 'wishbone_uart':
            input_assignment += (f'      dut.{fields["uart_rx"]} = command.fields[0];\n'
                                 f'      dut.{fields["uart_cts_n"]} = command.fields[1];\n')
        if kind == 'tlul_spi_host':
            input_assignment = f'      dut.{fields["sd_i"]} = command.fields[0];\n'
        if kind == 'tlul_uart':
            input_assignment += f'      dut.{fields["uart_rx"]} = command.fields[0];\n'
        if kind in ('tlul_register_observe', 'apb3_register_observe', 'wishbone_register_observe', 'axi4lite_register_observe', 'ahb_lite_register_observe'):
            input_assignment = ''.join(
                f'      dut.{row["runtime_name"]} = {row["value"]};\n'
                for row in document['fixed_physical_inputs'])
        if kind == 'tlul_spi_device':
            input_assignment += ''.join(
                f'      dut.{fields[name]} = command.fields[{i}];\n'
                for i, name in enumerate(('sck_i', 'csb_i', 'tpm_csb_i', 'sd_i')))

        index = (4 if kind == 'tlul_spi_device' else
                 2 if kind in ('tlul_gpio', 'wishbone_uart') else
                 1 if kind in ('apb_gpio', 'tlul_spi_host', 'tlul_uart') else 0)
        source_branch = '''      if (command.operation == "SOURCE_SPI") {
        peer.append(command.fields[0], command.fields[1], command.fields[2]);
        dut.eval();
        pre_backend = backend_snapshot(dut);
      } else {
''' if spi else '''      if (command.operation == "SOURCE_I2C") {
        pre_backend = backend_snapshot(dut);
        if (!peer.set_response(static_cast<std::uint8_t>(command.fields[0]))) {
          terminal = error_reply(command.execution, command.sequence, local_ticks,
                                 "invalid_source", "peer_response_already_bound");
        }
      } else {
''' if kind in ('apb_i2c', 'tlul_i2c') else ''
        if kind == 'tlul_i2c':
            source_branch = source_branch.replace('SOURCE_I2C', 'SOURCE_TLUL_I2C')
        if kind in ('tlul_register_observe', 'apb3_register_observe',
                    'axi4lite_register_observe', 'ahb_lite_register_observe'):
            register_command = ('TLUL_REG' if kind == 'tlul_register_observe' else
                                'AHB_REG' if kind == 'ahb_lite_register_observe' else
                                'APB3_REG' if kind == 'apb3_register_observe'
                                else 'AXIL_REG')
            source_cases = ''.join(
                f'        case {index}:\n'
                + (f'          if (command.fields[1] > {(1 << row["width"]) - 1}ULL) '\
                   f'throw std::runtime_error("source_width");\n' if row['width'] < 64 else '')
                + f'          dut.{row["runtime_name"]} = command.fields[1]; break;\n'
                for index, row in enumerate(document['dynamic_physical_inputs']))
            bound_cases = ''.join(
                f'        case {index}:\n'
                + (f'          if (command.fields[1] > {(1 << row["width"]) - 1}ULL) '
                   f'throw std::runtime_error("bound_width");\n' if row['width'] < 64 else '')
                + f'          dut.{row["runtime_name"]} = command.fields[1]; break;\n'
                for index, row in enumerate(document['bound_physical_inputs']))
            source_branch = '''      if (command.operation == "SOURCE_''' + register_command + '''") {
        pre_backend = backend_snapshot(dut);
        switch (command.fields[0]) {
''' + source_cases + '''        default: throw std::runtime_error("source_index");
        }
        tick(dut, &samples);
      } else if (command.operation == "BIND_''' + register_command + '''") {
        pre_backend = backend_snapshot(dut);
        switch (command.fields[0]) {
''' + bound_cases + '''        default: throw std::runtime_error("bound_index");
        }
        tick(dut, &samples);
      } else {
'''
        dispatch = input_assignment + source_branch + f'''      dut.eval();
      if (command.operation == "STEP_{command_channel}") {{
        pre_backend = backend_snapshot(dut);
        tick(dut, &samples);
      }} else {{
        dut.{channel}_req_valid = 1;
        dut.{channel}_req_write = command.fields[{index}];
        dut.{channel}_req_addr = command.fields[{index+1}];
        dut.{channel}_req_wdata = command.fields[{index+2}];
        dut.{channel}_req_be = command.fields[{index+3}];
        dut.{channel}_rsp_ready = 0;
        dut.eval();
        pre_backend = backend_snapshot(dut);
        unsigned waits = 0;
        while (!dut.{channel}_req_ready) {{
          if (waits++ >= {max_wait}) throw std::runtime_error("request_timeout");
          tick(dut, &samples);
        }}
        tick(dut, &samples);
        dut.{channel}_req_valid = 0;
        dut.eval();
        waits = 0;
        while (!dut.{channel}_rsp_valid) {{
          if (waits++ >= {max_wait + 3}) throw std::runtime_error("response_timeout");
          tick(dut, &samples);
        }}
        rdata = dut.{channel}_rsp_rdata;
        error = dut.{channel}_rsp_error;
        dut.{channel}_rsp_ready = 1;
        tick(dut, &samples);
        dut.{channel}_rsp_ready = 0;
        dut.eval();
      }}
''' + ('      }\n' if spi or kind in ('apb_i2c', 'tlul_i2c', 'tlul_register_observe', 'apb3_register_observe', 'axi4lite_register_observe', 'ahb_lite_register_observe') else '')
        # The accepted command set comes from the session registry, so a kind
        # that does not offer SOURCE_/BIND_ is refused because it truly has no
        # such operation, not because a second hand-kept list forgot it.
        extra_operations = frozenset(
            name for name in registered_operations(kind)
            if name.startswith(('SOURCE_', 'BIND_')))
        operation_check = (f'command.operation != "STEP_{command_channel}" && '
                           f'command.operation != "ACCESS_{command_channel}"' +
                           ''.join(f' && command.operation != "{name}"'
                                   for name in sorted(extra_operations)) +
                           (' && command.operation != "SOURCE_SPI"' if spi else
                            ' && command.operation != "SOURCE_I2C"'
                            if kind == 'apb_i2c' else
                            ' && command.operation != "SOURCE_TLUL_I2C"'
                            if kind == 'tlul_i2c' else ''))

    spi_active_cs = ' | '.join(f'((!dut.{fields[f"spi_csn{i}"]}) << {i})' for i in range(4)) if kind == 'apb_spi' else ''
    spi_observe = (f'peer.observe(dut.{fields["spi_clk"]}, {spi_active_cs}, '
                   f'dut.{fields["spi_mode"]}, dut.{fields["spi_sdo0"]});') if kind == 'apb_spi' else ''
    spi_drive = ('  ' + '\n  '.join(f'dut.{fields[f"spi_sdi{i}"]} = '
                                      + ('peer.drive_bit();' if i == 1 else '0;')
                                      for i in range(4)) + '\n') if kind == 'apb_spi' else ''
    i2c_resolve = (f'  dut.{fields["scl_pad_i"]} = dut.{fields["scl_padoen_o"]} ? 1 : 0;\n'
                   f'  dut.{fields["sda_pad_i"]} = '
                   f'(dut.{fields["sda_padoen_o"]} && !peer.sda_low()) ? 1 : 0;\n'
                   '  dut.eval();') if kind == 'apb_i2c' else ''
    if kind == 'tlul_i2c':
        i2c_resolve = (f'  dut.{fields["scl_i"]} = dut.{fields["scl_en_o"]} ? 0 : 1;\n'
                       f'  dut.{fields["sda_i"]} = '
                       f'(dut.{fields["sda_en_o"]} || peer.sda_low()) ? 0 : 1;\n'
                       '  dut.eval();')
    i2c_observe = (f'  peer.observe(dut.{fields["scl_pad_i"]}, dut.{fields["sda_pad_i"]}, '
                   f'dut.{fields["scl_pad_o"]}, dut.{fields["sda_pad_o"]}, '
                   f'dut.{fields["scl_padoen_o"]}, dut.{fields["sda_padoen_o"]});') if kind == 'apb_i2c' else ''
    if kind == 'tlul_i2c':
        i2c_observe = (f'  peer.observe(dut.{fields["scl_i"]}, dut.{fields["sda_i"]}, '
                       f'dut.{fields["scl_o"]}, dut.{fields["sda_o"]}, '
                       f'dut.{fields["scl_en_o"]}, dut.{fields["sda_en_o"]});')

    schedule = document.get('clock_schedule')
    if (not isinstance(schedule, dict)
            or schedule.get('schema_version') != 'local_clock_schedule.v1'
            or not isinstance(schedule.get('clocks'), list)
            or not isinstance(schedule.get('resets'), list)
            or not schedule['clocks'] or not schedule['resets']):
        raise ValueError('driver-clock-schedule-required')
    clock_rows = schedule['clocks']
    reset_rows = schedule['resets']
    if any(not isinstance(row, dict) for row in clock_rows + reset_rows):
        raise ValueError('driver-clock-schedule-shape')
    multiclock = len(clock_rows) > 1
    reset_signal_values = [row.get('signal') for row in reset_rows]
    if any(not isinstance(name, str) or not name for name in reset_signal_values):
        raise ValueError('driver-clock-schedule-shape')
    reset_signals = sorted(set(reset_signal_values))
    reset_inactive = ''.join(f'  dut.{name} = 0;\n' for name in reset_signals)
    reset_assert = ''.join(f'  dut.{name} = 1;\n' for name in reset_signals)
    reset_release = reset_inactive
    clock_state_declarations = ''
    clock_counter_reset = ''
    clock_counter_inc = ''
    clock_toggle = ''
    clock_fast_extra_low = ''
    clock_fast_extra_high = ''
    clock_edge_snapshot = ''
    clock_edge_sample_entry = ''
    clock_schedule_next = ''
    clock_schedule_increment = ''
    if multiclock:
        primary_domain = schedule.get('primary_clock_domain')
        rows_by_domain = {row.get('domain'): row for row in clock_rows}
        if (len(rows_by_domain) != len(clock_rows)
                or primary_domain not in rows_by_domain
                or rows_by_domain[primary_domain].get('signal') != 'clk'):
            raise ValueError('driver-clock-schedule-shape')
        counter_names = {domain: f'clock_edge_count_{index}'
                         for index, domain in enumerate(sorted(rows_by_domain))}
        clock_state_declarations = 'static std::uint64_t fast_schedule_ticks = 0;\n' + '\n'.join(
            f'static std::uint64_t {counter_names[domain]} = 0;'
            for domain in sorted(counter_names))
        clock_counter_reset = '\n'.join(
            f'  {counter_names[domain]} = 0;' for domain in sorted(counter_names))
        clock_schedule_next = '  const std::uint64_t next_fast_tick = fast_schedule_ticks + 1;\n'
        clock_schedule_increment = '  ++fast_schedule_ticks;\n'
        clock_counter_inc = f'  ++{counter_names[primary_domain]};\n'
        for domain, row in sorted(rows_by_domain.items()):
            ratio = row.get('ratio')
            signal_name = row.get('signal')
            half_period = row.get('half_period_fast_ticks')
            if (type(ratio) is not int or ratio < 1
                    or type(half_period) is not int or half_period < 1
                    or not isinstance(signal_name, str) or not signal_name):
                raise ValueError('driver-clock-schedule-shape')
            if domain == primary_domain:
                continue
            if ratio == 1:
                # Equal-frequency domains remain distinct wires and each gets
                # one full low/high cycle inside every local fastest tick.
                clock_fast_extra_low += f'  dut.{signal_name} = 0;\n'
                clock_fast_extra_high += f'  dut.{signal_name} = 1;\n'
                clock_counter_inc += f'  ++{counter_names[domain]};\n'
            else:
                clock_toggle += (
                    f'  if (next_fast_tick % {half_period}ULL == 0) {{\n'
                    f'    dut.{signal_name} = !dut.{signal_name};\n'
                    f'    if (dut.{signal_name}) ++{counter_names[domain]};\n'
                    f'  }}\n')
        edge_fields = ',\n'.join(
            f'    {{{_literal(domain)}, std::to_string({counter_names[domain]})}}'
            for domain in sorted(counter_names))
        clock_edge_snapshot = ('static std::string clock_edge_snapshot() {\n'
            '  return object({\n' + edge_fields + '\n  });\n}\n')
        clock_edge_sample_entry = '{"clock_edges", clock_edge_snapshot()}, '
    if storage_startup:
        operation_check='('+operation_check+') && command.operation != "READ_APB_STORAGE_STARTUP"'
        dispatch=(r'''      if (command.operation == "READ_APB_STORAGE_STARTUP") {
        pre_backend = backend_snapshot(dut);
        if (local_ticks != 0 || command.fields[0] != storage_startup_next_page) {
          terminal = error_reply(command.execution, command.sequence, local_ticks,
                                 "protocol_environment", "storage_startup_page_order");
        } else {
          observations_override = object({{"storage_startup", storage_startup_page(command.fields[0])}});
        }
      } else if (storage_startup_next_page != @PAGES@) {
        terminal = error_reply(command.execution, command.sequence, local_ticks,
                               "protocol_environment", "storage_startup_incomplete");
      } else {
''' + dispatch + '\n      }').replace('@PAGES@',str(storage_startup['page_count']))
    template = r'''#include "V@MODULE@.h"
#include "verilated.h"
#include "local_driver_v1.h"
@SPI_HEADER@
@I2C_HEADER@
@DMA_HEADER@
#include <iostream>
#include <map>
#include <string>
#include <vector>

#ifndef MYFUZZ_ARTIFACT_DIGEST
#error MYFUZZ_ARTIFACT_DIGEST must identify the final generated artifact
#endif
#define MYFUZZ_STRINGIFY_IMPL(value) #value
#define MYFUZZ_STRINGIFY(value) MYFUZZ_STRINGIFY_IMPL(value)

using Model = V@MODULE@;
using namespace myfuzz::local_driver_v1;
using JsonObject = std::map<std::string, std::string>;
static std::uint64_t local_ticks = 0;
@CLOCK_STATE_DECLARATIONS@
@SPI_PEER@
@DMA_STATE@

static std::string quote(const std::string &value) {
  return "\"" + value + "\"";
}
static std::string object(const JsonObject &values) {
  std::string answer = "{";
  for (const auto &entry : values) {
    if (answer.size() > 1) answer += ',';
    answer += quote(entry.first) + ':' + entry.second;
  }
  return answer + '}';
}
static std::string array(const std::vector<std::string> &values) {
  std::string answer = "[";
  for (const auto &value : values) {
    if (answer.size() > 1) answer += ',';
    answer += value;
  }
  return answer + ']';
}
template <typename Wide>
static std::string wide_hex(const Wide &value, unsigned width) {
  const char *digits = "0123456789abcdef";
  std::string answer((width + 3) / 4, '0');
  for (unsigned nibble = 0; nibble < answer.size(); ++nibble) {
    const unsigned bit = 4 * nibble;
    const unsigned remaining = width - bit;
    const unsigned mask = remaining < 4 ? (1u << remaining) - 1 : 15;
    answer[answer.size() - nibble - 1] = digits[(value[bit / 32] >> (bit % 32)) & mask];
  }
  return answer;
}
static std::string backend_snapshot(const Model &dut) {
  return object({
@BACKEND@
  });
}
static std::string snapshot(const Model &dut) {
  JsonObject values = {
@PROTOCOL_TAPS@    {"backend", backend_snapshot(dut)},
    {"physical", object({
@PHYSICAL@
    })}
  };
@ALIASES@  return object(values);
}
@CLOCK_EDGE_SNAPSHOT@
static void tick(Model &dut, std::vector<std::string> *samples) {
@SPI_DRIVE@
  dut.clk = 0;
@CLOCK_FAST_EXTRA_LOW@  dut.eval();
@I2C_RESOLVE@
@SPI_OBSERVE@
@I2C_OBSERVE@
  const auto pre = samples ? snapshot(dut) : "";
@CLOCK_SCHEDULE_NEXT@  dut.clk = 1;
@CLOCK_FAST_EXTRA_HIGH@@CLOCK_EDGE_COUNT_INC@@CLOCK_SLOW_TOGGLE@  dut.eval();
@I2C_RESOLVE@
@CLOCK_SCHEDULE_INCREMENT@
  ++local_ticks;
@SPI_OBSERVE@
@I2C_OBSERVE@
  const auto post = samples ? snapshot(dut) : "";
  dut.clk = 0;
@CLOCK_FAST_EXTRA_LOW@  dut.eval();
  if (samples) samples->push_back(object({@CLOCK_EDGE_SAMPLE_ENTRY@{"local_tick", std::to_string(local_ticks)},
                                       {"pre", pre}, {"post", post}}));
}
@AHB_STARTUP_HELPERS@static std::string encode_hex(const std::string &value) {
  if (value.size() > kMaxPayloadJsonBytes) throw std::length_error("payload_bound");
  const char *digits = "0123456789abcdef";
  std::string answer;
  answer.reserve(2 * value.size());
  for (const unsigned char byte : value) {
    answer += digits[byte >> 4];
    answer += digits[byte & 15];
  }
  return answer;
}
// A bounded reader never materializes an arbitrarily long input line. Oversize
// input is drained through newline, then rejected before replay admission.
static bool read_command(std::string &line, bool &oversize) {
  line.clear(); oversize = false;
  char byte;
  while (std::cin.get(byte)) {
    if (byte == '\n') return true;
    if (line.size() < kMaxCommandBytes) line += byte;
    else oversize = true;
  }
  return !line.empty() || oversize;
}
int main(int argc, char **argv) {
  Verilated::commandArgs(argc, argv);
  Model dut;
@INITIALIZERS@
  // Evaluate inactive reset first to create a real asynchronous assertion edge.
@RESET_INACTIVE@  dut.eval();
@RESET_ASSERT@  dut.eval();
  std::uint64_t asserted_ticks = 0, released_ticks = 0;
  for (unsigned i = 0; i < @ASSERT@; ++i) {
    @STARTUP_TICK@
    ++asserted_ticks;
  }
@RESET_RELEASE@  dut.eval();
  for (unsigned i = 0; i < @RELEASE@; ++i) {
    @STARTUP_TICK@
    ++released_ticks;
  }
@SPI_DEVICE_BOOT@
@CLOCK_COUNTER_RESET@
  local_ticks = 0;
  std::cout << "READY local_driver.v1 " << MYFUZZ_STRINGIFY(MYFUZZ_ARTIFACT_DIGEST)
            << " " << hex_integer(asserted_ticks) << " " << hex_integer(released_ticks) << std::endl;
  BoundedReplay replay(@CACHE@, kMaxReplyBytes@COMMAND_SET@);
  std::string line;
  bool oversize;
  while (read_command(line, oversize)) {
    if (!oversize && line == "END") break;
    if (oversize) {
      std::cout << error_reply("-", 0, local_ticks, "command_too_long", "wire_bound") << std::endl;
      continue;
    }
    if (line.rfind("ACK ", 0) == 0) {
      const auto ack = parse_ack(line);
      if (!ack.ok) {
        std::cout << error_reply(ack.execution, ack.sequence, local_ticks,
                                 ack.code, ack.detail) << std::endl;
      } else {
        const auto failure = replay.retire(ack.execution, ack.sequence);
        if (failure.empty())
          std::cout << "ACKED " << ack.execution << ' ' << hex_integer(ack.sequence)
                    << ' ' << hex_integer(local_ticks) << std::endl;
        else
          std::cout << error_reply(ack.execution, ack.sequence, local_ticks,
                                   failure, "ack_rejected") << std::endl;
      }
      continue;
    }
    const auto parsed = parse_command(line@COMMAND_SET@);
    if (!parsed.ok) {
      std::cout << error_reply(parsed.command.execution, parsed.command.sequence,
          local_ticks, parsed.code, parsed.detail) << std::endl;
      continue;
    }
    const auto &command = parsed.command;
    if (@OPERATION_CHECK@) {
      std::cout << error_reply(command.execution, command.sequence, local_ticks,
                              "invalid_operation", "wrong_runtime_kind") << std::endl;
      continue;
    }
    const auto admission = replay.accept(command, local_ticks, @RESERVATION@);
    if (admission.decision != Decision::Fresh) {
      std::cout << admission.reply << std::endl;
      continue;
    }
    const auto before = local_ticks;
    std::vector<std::string> samples;
    std::string pre_backend, terminal;
@AHB_STARTUP_VARIABLE@    std::uint32_t rdata = 0, error = 0;
    try {
@DISPATCH@
      if (terminal.empty()) {
        const auto payload = object({
          {"schema_version", quote("local_driver_result.v1")}, {"kind", quote("@KIND@")},
          {"samples", array(samples)}, {"observations", @OBSERVATIONS_EXPRESSION@},
          {"pre_backend", pre_backend}, {"rdata", std::to_string(rdata)},
          {"error", std::to_string(error)}
        });
        terminal = "RESULT " + command.execution + ' ' + hex_integer(command.sequence) + ' ' +
            hex_integer(before) + ' ' + hex_integer(local_ticks) + ' ' + encode_hex(payload);
      }
      replay.finish(command.sequence, terminal);
@AHB_STARTUP_FINISH@      std::cout << terminal << std::endl;
    } catch (const std::exception &) {
      const auto failure = error_reply(command.execution, command.sequence, local_ticks,
                                       "uncertain_effect", "driver_execution_failed");
      // Best effort receipt; incomplete replay still prevents another execution.
      try { replay.finish(command.sequence, failure); } catch (const std::exception &) {}
      std::cout << failure << std::endl;
      break;
    }
  }
  dut.final();
  return 0;
}
'''
    values = dict(MODULE=document['module_name'], BACKEND=backend_items, PHYSICAL=physical_items,
                  PROTOCOL_TAPS=protocol_tap_entry,
                  ALIASES=aliases, INITIALIZERS=initializers,
                  CLOCK_STATE_DECLARATIONS=clock_state_declarations,
                  CLOCK_EDGE_SNAPSHOT=clock_edge_snapshot,
                  CLOCK_FAST_EXTRA_LOW=clock_fast_extra_low,
                  CLOCK_SCHEDULE_NEXT=clock_schedule_next,
                  CLOCK_FAST_EXTRA_HIGH=clock_fast_extra_high,
                  CLOCK_EDGE_COUNT_INC=clock_counter_inc,
                  CLOCK_SLOW_TOGGLE=clock_toggle,
                  CLOCK_SCHEDULE_INCREMENT=clock_schedule_increment,
                  CLOCK_EDGE_SAMPLE_ENTRY=clock_edge_sample_entry,
                  CLOCK_COUNTER_RESET=clock_counter_reset,
                  RESET_INACTIVE=reset_inactive, RESET_ASSERT=reset_assert,
                  RESET_RELEASE=reset_release,
                  DMA_HEADER='#include "wishbone_dma_edge.h"' if kind == 'wishbone_dma' else '',
                  DMA_STATE='static WishboneDmaEdgeState dma_edge_state;' if kind == 'wishbone_dma' else '',
                  SPI_HEADER='#include "pulp_spi_mode0_peer.h"' if kind == 'apb_spi' else '',
                  I2C_HEADER=('#include "pulp_i2c_single_slave_peer.h"' if kind == 'apb_i2c'
                              else '#include "opentitan_i2c_single_slave_peer.h"'
                              if kind == 'tlul_i2c' else ''),
                  SPI_PEER=('static PulpSpiMode0Peer peer;' if kind == 'apb_spi' else
                            'static PulpI2cSingleSlavePeer peer;' if kind == 'apb_i2c' else
                            'static OpenTitanI2cSingleSlavePeer peer;' if kind == 'tlul_i2c' else ''),
                  SPI_DRIVE=spi_drive, SPI_OBSERVE=spi_observe,
                  I2C_RESOLVE=i2c_resolve, I2C_OBSERVE=i2c_observe,
                  SPI_DEVICE_BOOT=(
                      f'  for (unsigned i = 0; i < 2; ++i) {{\n'
                      f'    dut.{fields["sck_i"]} = 1; tick(dut, nullptr);\n'
                      f'    dut.{fields["sck_i"]} = 0; tick(dut, nullptr);\n'
                      f'  }}' if kind == 'tlul_spi_device' else ''),
                  ASSERT=str(artifact.plan.request.reset_assert_ticks),
                  RELEASE=str(artifact.plan.request.reset_release_ticks), CACHE=str(64 * 1024 * 1024),
                  RESERVATION=str(reservation), OPERATION_CHECK=operation_check,
                  DISPATCH=dispatch, KIND=kind)
    from .ahb_startup import render_startup_helpers
    values.update(AHB_STARTUP_HELPERS=render_startup_helpers(ahb_startup) if ahb_startup else '',
        STARTUP_TICK='capture_ahb_startup(dut);' if ahb_startup else 'tick(dut, nullptr);',
        COMMAND_SET=', CommandSet::AhbStartup' if ahb_startup else '',
        AHB_STARTUP_FINISH=('      if (command.operation == \"READ_AHB_STARTUP\" && terminal.rfind(\"RESULT \", 0) == 0) ++ahb_startup_next_page;\n' if ahb_startup else ''),
        AHB_STARTUP_VARIABLE='    std::string observations_override;\n' if ahb_startup else '',
        OBSERVATIONS_EXPRESSION='(observations_override.empty() ? snapshot(dut) : observations_override)' if ahb_startup else 'snapshot(dut)')
    if storage_startup:
        from .apb_storage_startup import render_startup_helpers as render_storage_helpers
        values.update(AHB_STARTUP_HELPERS=render_storage_helpers(storage_startup),
            STARTUP_TICK='capture_storage_startup(dut);',COMMAND_SET=', CommandSet::ApbStorageStartup',
            AHB_STARTUP_FINISH='      if (command.operation == "READ_APB_STORAGE_STARTUP" && terminal.rfind("RESULT ", 0) == 0) ++storage_startup_next_page;\n',
            AHB_STARTUP_VARIABLE='    std::string observations_override;\n',
            OBSERVATIONS_EXPRESSION='(observations_override.empty() ? snapshot(dut) : observations_override)')
    cpp = template
    for key, value in values.items():
        cpp = cpp.replace('@' + key + '@', value)
    headers = [{'path': name, 'sha256': hashlib.sha256((root / name).read_bytes()).hexdigest()}
               for name in (*_HEADERS, *([_DMA_HEADER] if kind == 'wishbone_dma' else []), *([_SPI_HEADER] if kind == 'apb_spi' else []),
                            *([_I2C_HEADER] if kind == 'apb_i2c' else
                              [_OT_I2C_HEADER] if kind == 'tlul_i2c' else []))]
    document.update(driver_schema_version='local_driver_generation.v1', status='driver_generated',
                    driver_status='generated', driver_header_sources=headers,
                    cpp_sha256=hashlib.sha256(cpp.encode()).hexdigest(),
                    driver_field_map=fields,
                    driver_reset=dict(schema_version='generated_local_reset.v1',
                        reset_assert_ticks=artifact.plan.request.reset_assert_ticks,
                        reset_release_ticks=artifact.plan.request.reset_release_ticks),
                    driver_limits=dict(max_command_bytes=1024, max_payload_json_bytes=1024 * 1024,
                        max_reply_line_bytes=2 * 1024 * 1024 + 512,
                        max_cached_bytes=64 * 1024 * 1024,
                        reply_reservation_bytes=reservation, max_samples_per_command=max_samples))
    if ahb_startup:
        document['ahb_startup_contract'] = ahb_startup
        document['driver_schema_version'] = 'local_driver_generation.ahb_startup.v2'
    if storage_startup:
        document['storage_startup_capture']=storage_startup
        document['driver_schema_version']='local_driver_generation.apb_storage_startup.v2'
    document.pop('artifact_digest')
    document['artifact_digest'] = _sha(document)
    return replace(copy.deepcopy(artifact), cpp_text=cpp, runtime_document=document)
