from pathlib import Path,PurePosixPath
import hashlib,json,tarfile,stat,os,sys
sys.dont_write_bytecode=True
base=Path('/root/fanzehui/myfuzz/operations/p7-i5-independent-6b40ef4-20261018-attempt1')
archive=base/'source-transfer.tar.gz'
(base/'extraction-operation.json').write_text(json.dumps({'status':'started','pid':os.getpid(),'scope':'hash/unpack only; no source imports/tools'}))
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert archive.stat().st_size==615937717
assert sha(archive)=='a3b5ba65700049ad73e47ccf239ddb6626d1c4777cb4b5018abbe91be9032b1f'
assert not any((base/n).exists() for n in ('project','control','client','.copy-ready'))
with tarfile.open(archive) as t:
 members=t.getmembers();names=[m.name for m in members]
 assert len(names)==len(set(names))
 assert all(m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts for m in members)
 freeze_raw=t.extractfile('control/ready-freeze.json').read()
 assert hashlib.sha256(freeze_raw).hexdigest()=='b6372fcdb7ca1e93c289f850b0d53bc421c571204a65b86bd828815eb1f13dd2'
 freeze=json.loads(freeze_raw)
 control={'ready-freeze.json','selection-review.json','transport-manifest.json','ibex-materialization-receipt.json','gpio-materialization-receipt.json','runner-overlay.json','native-boundary-overlay.json'}
 assert set(names)=={'project/'+n for n in freeze}|{'control/'+n for n in control}|{'client/kfuzz'}
 t.extractall(base,filter='data')
root=base/'project'
for name,pin in freeze.items():
 p=root/name;p.chmod(pin['mode']);s=p.stat()
 assert p.resolve().is_relative_to(root) and stat.S_ISREG(s.st_mode) and s.st_nlink==1
 assert s.st_size==pin['bytes'] and stat.S_IMODE(s.st_mode)==pin['mode'] and sha(p)==pin['sha256'],name
actual=set()
for d,dirs,files in os.walk(root,followlinks=False):
 assert not any((Path(d)/n).is_symlink() for n in dirs)
 for n in files:actual.add((Path(d)/n).relative_to(root).as_posix())
assert actual==set(freeze)
assert sha(base/'client/kfuzz')=='16434544a4a0712fa7716f6f3e3ff8e0dd949139f6a047780f4d08694ff31dcc'
(base/'client/kfuzz').chmod(0o755)
head=(root/'.git/HEAD').read_text().strip()
assert head.startswith('ref: refs/heads/')
commit=(root/'.git'/head[5:]).read_text().strip()
assert len(commit)==40 and commit.startswith('6b40ef4')
receipt={'status':'source_copy_verified_only','project':str(root),'files':len(freeze),'bytes':sum(x['bytes'] for x in freeze.values()),'full_file_mode_hash_map_verified':True,'freeze_sha256':sha(base/'control/ready-freeze.json'),'archive_sha256':sha(archive),'git_base_commit':commit,'explicit_overlays':{'runner':'4b6fc42','native_boundary':'52de02c'},'native_tests_frontend_build_executed':False,'tool_transitive_closure_approved':False,'formal_p7_complete':False}
(base/'control/copy-ready.json').write_text(json.dumps(receipt,indent=2)+'\n')
(base/'.copy-ready').write_text(json.dumps(receipt)+'\n')
print(json.dumps(receipt))

(base/'extraction-operation.json').write_text(json.dumps({'status':'terminal0','pid':os.getpid(),'scope':'hash/unpack only; no source imports/tools'}))
