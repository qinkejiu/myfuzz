from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
root=Path('/root/fanzehui/myfuzz')
base=root/'operations/environment-20261018-attempt1'
base.mkdir(parents=True,exist_ok=False)
(base/'bin').mkdir(); (base/'tmp').mkdir()
(base/'empty.gitconfig').write_text('')
for command in ('c++','g++','cc','gcc','ar','make'):
 p=base/'bin'/command
 p.write_text('#!/bin/sh\nexport TMPDIR='+str(base/'tmp')+'\nexec /usr/bin/'+command+' "$@"\n')
 p.chmod(0o755)
p=base/'bin/verilator'
p.write_text('#!/bin/sh\nexport TMPDIR='+str(base/'tmp')+'\nexport VERILATOR_ROOT='+str(root/'tools/verilator-5.051/share/verilator')+'\nexport VERILATOR_BIN='+str(root/'tools/verilator-5.051/bin/verilator_bin')+'\nexec '+str(root/'tools/verilator-5.051/bin/verilator')+' "$@"\n')
p.chmod(0o755)
env='''# Preparation only: wrappers and dependency closure are not execution-verified.
# Source only after setting an independently frozen MYFUZZ_SOURCE_ROOT.
case "${MYFUZZ_SOURCE_ROOT:-}" in
  /root/fanzehui/myfuzz/operations/*/project) ;;
  *) echo 'MYFUZZ_SOURCE_ROOT must name an independent operations project' >&2; return 2 ;;
esac
export TMPDIR=BASE/tmp
export PATH=BASE/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export PYTHONPATH="$MYFUZZ_SOURCE_ROOT/src:$MYFUZZ_SOURCE_ROOT:/root/fanzehui/myfuzz/pythonlib"
export PYTHONNOUSERSITE=1
export PYTHONDONTWRITEBYTECODE=1
export PYTHONOPTIMIZE=0
export PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
export GIT_CONFIG_NOSYSTEM=1
export GIT_CONFIG_GLOBAL=BASE/empty.gitconfig
export GIT_OPTIONAL_LOCKS=0
export GIT_NO_LAZY_FETCH=1
export VERILATOR_ROOT=/root/fanzehui/myfuzz/tools/verilator-5.051/share/verilator
export VERILATOR_BIN=/root/fanzehui/myfuzz/tools/verilator-5.051/bin/verilator_bin
'''.replace('BASE',str(base))
(base/'environment.sh').write_text(env)
files={str(p.relative_to(base)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in base.rglob('*') if p.is_file()}
receipt={'status':'prepared_not_executed','base':str(base),'files':files,'old_workspace_modified':False,'tool_queries_build_tests_models_executed':False,'tool_transitive_closure_verified':False}
(base/'preparation-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
