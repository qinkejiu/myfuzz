from pathlib import Path
import json,hashlib,stat,gzip,tarfile,os,shutil,time
control=Path('/tmp/myfuzz-independent-preparation-20261018');root=Path('/tmp/myfuzz-p7-i5-source-6b40ef4')
freeze=json.loads((control/'ready-freeze.json').read_text())
assert len(freeze)==15333
for name,pin in freeze.items():
 p=root/name;s=p.stat()
 assert s.st_nlink==1 and s.st_size==pin['bytes'] and stat.S_IMODE(s.st_mode)==pin['mode'] and hashlib.sha256(p.read_bytes()).hexdigest()==pin['sha256'],name
client=Path('/home/qinkejiu/myfuzz/runs/rfuzz_client_native_build/target/debug/kfuzz')
client_sha=hashlib.sha256(client.read_bytes()).hexdigest()
shutil.copyfile(client,control/'kfuzz');(control/'kfuzz').chmod(0o755)
assert hashlib.sha256((control/'kfuzz').read_bytes()).hexdigest()==client_sha
receipt={'scope':'source+client transport only, no native operation','files':len(freeze),'bytes':sum(p['bytes'] for p in freeze.values()),'freeze_sha256':hashlib.sha256((control/'ready-freeze.json').read_bytes()).hexdigest(),'git_base_commit':'6b40ef4','explicit_overlays':{'runner':'4b6fc42','native_boundary':'52de02c'},'client_sha256':client_sha,'independent_full_map_verified':True}
(control/'transport-manifest.json').write_text(json.dumps(receipt,indent=2)+'\n')
archive=control/'source-transfer.tar.gz'
with archive.open('xb') as out,gzip.GzipFile(fileobj=out,mode='wb',compresslevel=3,mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w|') as t:
 for name in freeze:t.add(root/name,arcname='project/'+name,recursive=False)
 for name in ['ready-freeze.json','selection-review.json','transport-manifest.json','ibex-materialization-receipt.json','gpio-materialization-receipt.json','runner-overlay.json','native-boundary-overlay.json']:
  t.add(control/name,arcname='control/'+name,recursive=False)
 t.add(control/'kfuzz',arcname='client/kfuzz',recursive=False)
receipt.update(archive_bytes=archive.stat().st_size,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),status='packaged_only_not_executed')
(control/'source-transfer-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
