from pathlib import Path
import os,stat,hashlib,json,time
control=Path('/tmp/myfuzz-independent-preparation-20261018')
source=Path('/home/qinkejiu/myfuzz');target=Path('/tmp/myfuzz-p7-i5-staging-6b40ef4')
include=(control/'explicit-includes.txt').read_text().splitlines();exclude=(control/'explicit-exclusions.txt').read_text().splitlines()
def selected(n,roots):return any(n==r or n.startswith(r+'/') for r in roots)
def pin(p):
 s=p.lstat()
 if not stat.S_ISREG(s.st_mode):raise ValueError('not ordinary file:'+str(p))
 return {'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':s.st_size,'mode':stat.S_IMODE(s.st_mode)}
def inventory(root):
 files={}
 for prefix in include:
  p=root/prefix
  if p.is_symlink():raise ValueError('prefix symlink')
  if p.is_file():files[prefix]=pin(p);continue
  for d,dirs,names in os.walk(p,followlinks=False):
   for n in dirs:
    q=Path(d)/n
    if q.is_symlink():raise ValueError('directory symlink:'+str(q))
   dirs[:]=[n for n in dirs if not selected((Path(d)/n).relative_to(root).as_posix(),exclude)]
   for n in names:
    q=Path(d)/n;k=q.relative_to(root).as_posix()
    if not selected(k,exclude):files[k]=pin(q)
 return dict(sorted(files.items()))
def copy_one(original,dest,expected):
 dest.parent.mkdir(parents=True,exist_ok=True)
 with original.open('rb') as src,dest.open('xb') as dst:
  while block:=src.read(1024*1024):dst.write(block)
  dst.flush();os.fsync(dst.fileno())
 dest.chmod(expected['mode'])
 if dest.stat().st_nlink!=1 or pin(dest)!=expected or pin(original)!=expected:raise ValueError('copy mismatch')
started=time.time();target.mkdir(exist_ok=False)
receipt={'status':'started','pid':os.getpid(),'source':str(source),'target':str(target),'source_hardlinks_read_only':[]}
(control/'staging-operation.json').write_text(json.dumps(receipt))
try:
 before=inventory(source)
 for i,(name,p) in enumerate(before.items()):
  original=source/name
  if original.stat().st_nlink>1:receipt['source_hardlinks_read_only'].append(name)
  copy_one(original,target/name,p)
  if i%1000==0:(control/'staging-progress.json').write_text(json.dumps({'pid':os.getpid(),'copied':i,'total':len(before)}))
 if inventory(source)!=before:raise ValueError('source changed during staging')
 (control/'original-selected-files.json').write_text(json.dumps(before,sort_keys=True))
 overlay=control/'ibex-materialized/.git'
 metadata={}
 for p in overlay.rglob('*'):
  if p.is_file():
   name=p.relative_to(overlay).as_posix();expected=pin(p)
   copy_one(p,target/'third_party/rfuzz/upstream/ibex/.git'/name,expected);metadata[name]=expected
 (control/'ibex-materialized-files.json').write_text(json.dumps(metadata,sort_keys=True))
 receipt.update(status='staged_pending_snapshot_tool_validation',files=len(before),bytes=sum(p['bytes'] for p in before.values()),source_unchanged=True,independent_ibex_metadata_files=len(metadata),ibex_head='34b0705760ef3dfa00e99637432473d2be8f22f3',duration_seconds=time.time()-started)
except BaseException as e:
 receipt.update(status='failed',error=repr(e));raise
finally:
 (control/'staging-operation.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='source_hardlinks_read_only'}))
