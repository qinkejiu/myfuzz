#!/bin/bash
set -euo pipefail
export MYFUZZ_SOURCE_ROOT=/root/fanzehui/myfuzz/operations/p6-native-online-c924aac-20261018-attempt1/project
. /root/fanzehui/myfuzz/operations/environment-20261018-attempt3/environment.sh
cd "$MYFUZZ_SOURCE_ROOT"
exec python3 /root/fanzehui/myfuzz/operations/p6-native-inputs-20261018/run_p6_attempt2.py --freeze-sha256 fb51329ff1bb749a12422a7781ce50dcdb6aae5ff31c9a72981ab64beb2f5f96 --receipt-sha256 9f50e3235001ef401f5497a66d361167b47ac622139a021e556b7a52fc686029
