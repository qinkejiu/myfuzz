# P6 selected independent copy controller — not executed

Script: `prepare_p6_copy.py`. Root review/upload only. No subprocess, Git,
frontend, tests, native or remote execution is performed by the script itself.

After upload, all input/output paths must be under `/root/fanzehui`.

```text
python3 prepare_p6_copy.py \
  --source IMMUTABLE_ATTEMPT1/project \
  --source-freeze ORIGINAL_FULL_FILE_FREEZE \
  --source-freeze-sha256 b6372fcdb7ca1e93c289f850b0d53bc421c571204a65b86bd828815eb1f13dd2 \
  --new-operation /root/fanzehui/myfuzz/operations/p6-native-online-c924aac-20261018-attempt1 \
  --overlay-archive UPLOADED/pico-native-gate-inputs.tar.gz \
  --overlay-archive-sha256 d33a208f5808800b9d9686f250a3a5de8937998126e66635aaf102b72aa7a077 \
  --overlay-map UPLOADED/unpacked-map.json \
  --overlay-map-sha256 3bc59b0720d7a32393a7bfb4b808dcc8ad0afd18223c799c14f3a35013fb29d3
```

Selection is exactly src, configs, root .git/.gitmodules/.gitignore/README.md,
scripts/verify_soc_sources.py and third_party/soc-pulp-apb-gpio, preserving empty
directories and permission modes. No Ibex working directory is selected and no
Ibex refs directories are repaired. Original root metadata identity is retained;
subsets may show intentional tracked-file deletions when later inspected.

Overlay is restricted to the new scripts/verify_picorv32_native_online.py and
third_party/picorv32_upstream_reference tree, with only scripts/third_party parent
directory reuse. Full tar member set, types, canonical paths, sizes and modes
must match the reviewed map; regular file hashes are checked in final readback.
No link, overwrite, unknown ancestor or source/config overlay is admitted.

No per-file fsync is performed. All closed output files undergo full readback
hash/size/mode and single-link verification. Original source whole files and
directory modes are mapped before/after. Final file freeze, directory map and
directory SHA are external in newoperation/control; only final receipt is
fsynced. Failures preserve original exception and the new partial operation.
Root's verify_layout.py can consume final-file-freeze.json and copy-receipt.json
directories/directory_manifest_sha256/freeze_sha256. No execution capability or
P6 completion follows from a successful copy.
