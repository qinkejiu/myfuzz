import sys
sys.dont_write_bytecode=True
from pathlib import Path
import json,os
b=Path('/root/fanzehui/myfuzz/operations/p6-native-online-c924aac-20261018-attempt2');c=b/'gate-attempt3-control';r={'control_exists':c.exists(),'children':[],'operation_result':None,'run_files':[]}
if c.exists():
 for p in sorted(c.glob('*.launch.json')):
  x=json.loads(p.read_bytes());terminal=c/(p.name.removesuffix('.launch.json')+'.terminal.json');x={'name':p.name,'pid':x['pid'],'terminal':terminal.exists()}
  if terminal.exists():x['returncode']=json.loads(terminal.read_bytes()).get('returncode')
  else:
   q=Path('/proc')/str(x['pid'])/'status';x['live']=q.exists()
   if q.exists():x['state']=q.read_text().split('State:',1)[1].splitlines()[0].strip()
  r['children'].append(x)
 if (c/'native-operation-result.json').exists():r['operation_result']=json.loads((c/'native-operation-result.json').read_bytes())
run=b/'run-attempt3'
if run.exists():r['run_files']=[str(p.relative_to(run)) for p in run.rglob('*') if p.is_file() and (p.name.endswith('.json.gz') or p.name.endswith('.json'))]
print(json.dumps(r))
